import logging
from contextlib import contextmanager
from threading import Lock

import psycopg2
from psycopg2 import pool as pg_pool

from config import DB_POOL_MIN, DB_POOL_MAX, DB_URI, DB_URI_DEFAULT

log = logging.getLogger(__name__)

_pool: pg_pool.ThreadedConnectionPool | None = None
_pool_lock = Lock()


def _get_pool() -> pg_pool.ThreadedConnectionPool:
    global _pool
    with _pool_lock:
        if _pool is None:
            _pool = pg_pool.ThreadedConnectionPool(DB_POOL_MIN, DB_POOL_MAX, DB_URI)
            log.info("Pool PostgreSQL criado.")
    return _pool


@contextmanager
def get_conn():
    pool = _get_pool()
    conn = None
    try:
        conn = pool.getconn()
        yield conn
        conn.commit()
    except Exception:
        if conn is not None:
            conn.rollback()
        raise
    finally:
        if conn is not None:
            pool.putconn(conn)


def init_db() -> None:
    log.info("Inicializando schema do banco de dados...")

    try:
        conn = psycopg2.connect(DB_URI_DEFAULT)
        conn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
        with conn.cursor() as c:
            c.execute("SELECT 1 FROM pg_catalog.pg_database WHERE datname = 'telemetria'")
            if not c.fetchone():
                c.execute("CREATE DATABASE telemetria")
                log.info("Banco 'telemetria' criado.")
        conn.close()
    except Exception as e:
        log.error("Erro ao criar banco: %s", e)
        return

    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                # Tabela principal de máquinas
                c.execute("""
                    CREATE TABLE IF NOT EXISTS maquinas_v6 (
                        hostname       TEXT PRIMARY KEY,
                        modelo         TEXT,
                        cpu_modelo     TEXT,
                        cpu            REAL,
                        ram            REAL,
                        ram_total      INTEGER,
                        disco_c        REAL,
                        disco_c_total  INTEGER,
                        disco_d        REAL,
                        disco_d_total  INTEGER,
                        rede           TEXT,
                        viloes         TEXT,
                        battery_status INTEGER,
                        carregador     TEXT,
                        uptime         TEXT,
                        localidade     TEXT,
                        ultima_atualizacao TIMESTAMP
                    )
                """)

                # Colunas novas (migração idempotente)
                for col, typ in [
                    ("os_version",   "TEXT"),
                    ("usuario",      "TEXT"),
                    ("ip_address",   "TEXT"),
                    ("departamento", "TEXT DEFAULT 'Geral'"),
                    ("ativo_fisico", "TEXT"),
                    ("centro_custo", "TEXT"),
                    ("meta_manual",  "BOOLEAN DEFAULT FALSE"),
                    ("boot_time",    "TEXT"),
                ]:
                    c.execute(
                        f"ALTER TABLE maquinas_v6 ADD COLUMN IF NOT EXISTS {col} {typ}"
                    )

                # Tabela de histórico
                c.execute("""
                    CREATE TABLE IF NOT EXISTS historico_v6 (
                        id        SERIAL PRIMARY KEY,
                        hostname  TEXT,
                        cpu       REAL,
                        ram       REAL,
                        timestamp TIMESTAMP
                    )
                """)
                for col, typ in [("disco_c", "REAL"), ("disco_d", "REAL")]:
                    c.execute(
                        f"ALTER TABLE historico_v6 ADD COLUMN IF NOT EXISTS {col} {typ}"
                    )

                # Tabela de log de alertas
                c.execute("""
                    CREATE TABLE IF NOT EXISTS alertas (
                        id        SERIAL PRIMARY KEY,
                        hostname  TEXT NOT NULL,
                        tipo      TEXT NOT NULL,
                        mensagem  TEXT NOT NULL,
                        timestamp TIMESTAMP DEFAULT NOW()
                    )
                """)

                # Novas colunas de observabilidade em maquinas_v6
                for col, typ in [
                    ("health_score",          "REAL"),
                    ("defender_ativo",        "BOOLEAN"),
                    ("defender_produto",      "TEXT"),
                    ("updates_pendentes",     "INTEGER"),
                    ("ultimo_windows_update", "TIMESTAMP"),
                    ("net_kbps_up",           "REAL"),
                    ("net_kbps_down",         "REAL"),
                    ("servicos_parados",      "TEXT"),
                    ("temperatura_cpu",       "INTEGER"),
                    ("reboot_pendente",       "BOOLEAN"),
                    ("bitlocker_ativo",       "BOOLEAN"),
                    ("latencia_gateway_ms",   "INTEGER"),
                    ("latencia_internet_ms",  "INTEGER"),
                    ("disco_latencia_ms",     "REAL"),
                    ("monitores_count",       "INTEGER"),
                    ("resolucao_principal",   "TEXT"),
                    ("pasta_uso",             "JSONB"),
                    ("portas_abertas",        "JSONB"),
                    # v3 — segurança
                    ("firewall_domain",       "BOOLEAN"),
                    ("firewall_private",      "BOOLEAN"),
                    ("firewall_public",       "BOOLEAN"),
                    ("admins_locais",         "JSONB"),
                    ("defender_ultima_def",   "TEXT"),
                    ("defender_scan_dias",    "INTEGER"),
                    ("smart_ok",              "BOOLEAN"),
                    ("tela_bloqueada",        "BOOLEAN"),
                    ("idle_minutos",          "INTEGER"),
                    # v3 — hardware
                    ("gpu_modelo",            "TEXT"),
                    ("gpu_memoria_mb",        "INTEGER"),
                    ("discos_fisicos",        "JSONB"),
                    ("bios_versao",           "TEXT"),
                    # v3 — rede expandida
                    ("conexoes_externas",     "JSONB"),
                    ("dns_servidores",        "JSONB"),
                    # v4 — RDP, UAC, rede, reboot, bateria, usuários locais
                    ("rdp_habilitado",        "BOOLEAN"),
                    ("uac_habilitado",        "BOOLEAN"),
                    ("rede_tipo",             "TEXT"),
                    ("reboot_inesperado",     "BOOLEAN"),
                    ("tem_bateria",           "BOOLEAN"),
                    ("bateria_descricao",     "TEXT"),
                    ("usuarios_locais",       "JSONB"),
                ]:
                    c.execute(
                        f"ALTER TABLE maquinas_v6 ADD COLUMN IF NOT EXISTS {col} {typ}"
                    )

                # Eventos do Windows Event Log
                c.execute("""
                    CREATE TABLE IF NOT EXISTS eventos_windows (
                        id        SERIAL PRIMARY KEY,
                        hostname  TEXT NOT NULL,
                        timestamp TIMESTAMP NOT NULL,
                        nivel     TEXT,
                        fonte     TEXT,
                        event_id  INTEGER,
                        mensagem  TEXT,
                        log_name  TEXT
                    )
                """)

                # Top processos por máquina
                c.execute("""
                    CREATE TABLE IF NOT EXISTS processos_top (
                        id        SERIAL PRIMARY KEY,
                        hostname  TEXT NOT NULL,
                        timestamp TIMESTAMP NOT NULL,
                        nome      TEXT,
                        ram_mb    INTEGER,
                        pid       INTEGER
                    )
                """)
                c.execute(
                    "ALTER TABLE processos_top ADD COLUMN IF NOT EXISTS cpu_pct REAL"
                )

                # Histórico de login/logoff (Security EventLog)
                c.execute("""
                    CREATE TABLE IF NOT EXISTS login_historico (
                        id               SERIAL PRIMARY KEY,
                        hostname         TEXT NOT NULL,
                        timestamp_evento TIMESTAMP,
                        tipo             TEXT,
                        usuario          TEXT,
                        event_id         INTEGER
                    )
                """)

                # Inventário de software instalado
                c.execute("""
                    CREATE TABLE IF NOT EXISTS software_instalado (
                        id                 SERIAL PRIMARY KEY,
                        hostname           TEXT NOT NULL,
                        nome               TEXT,
                        versao             TEXT,
                        publisher          TEXT,
                        instalado          TEXT,
                        timestamp_coletado TIMESTAMP DEFAULT NOW()
                    )
                """)

                # Índices de performance
                for idx in [
                    "CREATE INDEX IF NOT EXISTS idx_hist_host    ON historico_v6(hostname)",
                    "CREATE INDEX IF NOT EXISTS idx_hist_ts      ON historico_v6(timestamp)",
                    "CREATE INDEX IF NOT EXISTS idx_hist_host_ts ON historico_v6(hostname, timestamp)",
                    "CREATE INDEX IF NOT EXISTS idx_alert_host   ON alertas(hostname)",
                    "CREATE INDEX IF NOT EXISTS idx_alert_ts     ON alertas(timestamp)",
                    "CREATE INDEX IF NOT EXISTS idx_maq_updated  ON maquinas_v6(ultima_atualizacao)",
                    "CREATE INDEX IF NOT EXISTS idx_ev_host_ts   ON eventos_windows(hostname, timestamp)",
                    "CREATE INDEX IF NOT EXISTS idx_ev_ts        ON eventos_windows(timestamp)",
                    "CREATE INDEX IF NOT EXISTS idx_proc_host_ts ON processos_top(hostname, timestamp)",
                    "CREATE INDEX IF NOT EXISTS idx_login_host   ON login_historico(hostname)",
                    "CREATE INDEX IF NOT EXISTS idx_login_ts     ON login_historico(timestamp_evento)",
                    "CREATE INDEX IF NOT EXISTS idx_sw_host      ON software_instalado(hostname)",
                ]:
                    c.execute(idx)

        log.info("Schema inicializado com sucesso.")
    except Exception as e:
        log.error("Erro ao inicializar schema: %s", e)
