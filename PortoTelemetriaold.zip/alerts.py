import logging
import smtplib
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from email.mime.text import MIMEText
from threading import Lock

import requests

from config import (
    ALERT_COOLDOWN,
    EMAIL_FROM, EMAIL_HOST, EMAIL_PASS, EMAIL_PORT, EMAIL_TO, EMAIL_USER,
    GOOGLE_CHAT_WEBHOOK,
)

log = logging.getLogger(__name__)

_cooldown: dict[str, float] = {}
_cooldown_lock = Lock()
_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="alert")


def _check_cooldown(key: str) -> bool:
    agora = time.time()
    with _cooldown_lock:
        if (agora - _cooldown.get(key, 0)) < ALERT_COOLDOWN:
            return False
        _cooldown[key] = agora
        return True


def _persistir(hostname: str, tipo: str, mensagem: str) -> None:
    try:
        from database import get_conn
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute(
                    "INSERT INTO alertas (hostname, tipo, mensagem) VALUES (%s, %s, %s)",
                    (hostname, tipo, mensagem),
                )
    except Exception as e:
        log.error("Erro ao persistir alerta: %s", e)


def _disparar(hostname: str, tipo: str, mensagem: str) -> None:
    _persistir(hostname, tipo, mensagem)
    _google_chat(hostname, tipo, mensagem)
    _email(hostname, tipo, mensagem)


def alertar(hostname: str, tipo: str, mensagem: str) -> None:
    if not _check_cooldown(f"{hostname}:{tipo}"):
        return

    log.warning("[ALERTA] %s — %s: %s", hostname, tipo, mensagem)
    _executor.submit(_disparar, hostname, tipo, mensagem)


def _google_chat(hostname: str, tipo: str, mensagem: str) -> None:
    if not GOOGLE_CHAT_WEBHOOK:
        return
    payload = {"text": (
        f"*ALERTA — {tipo}*\n"
        f"Maquina: {hostname}\n"
        f"{mensagem}\n"
        f"Horario: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}"
    )}
    try:
        res = requests.post(GOOGLE_CHAT_WEBHOOK, json=payload, timeout=10)
        if res.status_code != 200:
            log.warning("Google Chat retornou %s", res.status_code)
    except requests.RequestException as e:
        log.error("Falha no Google Chat: %s", e)


def _email(hostname: str, tipo: str, mensagem: str) -> None:
    if not all([EMAIL_HOST, EMAIL_TO, EMAIL_USER]):
        return
    msg = MIMEText(
        f"Maquina : {hostname}\n"
        f"Tipo    : {tipo}\n"
        f"Detalhe : {mensagem}\n"
        f"Horario : {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}",
        "plain", "utf-8",
    )
    msg["Subject"] = f"[TELEMETRIA] ALERTA {tipo} — {hostname}"
    msg["From"]    = EMAIL_FROM or EMAIL_USER
    msg["To"]      = EMAIL_TO
    try:
        with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT, timeout=15) as s:
            s.starttls()
            s.login(EMAIL_USER, EMAIL_PASS)
            s.sendmail(msg["From"], [EMAIL_TO], msg.as_string())
        log.info("Email de alerta enviado para %s", EMAIL_TO)
    except Exception as e:
        log.error("Falha ao enviar email: %s", e)
