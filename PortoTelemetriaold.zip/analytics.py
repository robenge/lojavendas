from __future__ import annotations

import logging
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

log = logging.getLogger(__name__)


def calcular_health_score(row: dict) -> float:
    """Calcula score de saúde 0-100. 100 = perfeito, 0 = crítico."""
    diff = float(row.get("diff") or 9999)
    if diff > 720:
        return 0.0

    score = 100.0

    cpu = float(row.get("cpu") or 0)
    if cpu > 95:    score -= 30
    elif cpu > 85:  score -= 20
    elif cpu > 70:  score -= 10
    elif cpu > 55:  score -= 5

    ram = float(row.get("ram") or 0)
    if ram > 95:    score -= 25
    elif ram > 90:  score -= 18
    elif ram > 80:  score -= 10
    elif ram > 70:  score -= 5

    disco = float(row.get("disco_c") or 0)
    if disco > 95:   score -= 25
    elif disco > 90: score -= 20
    elif disco > 80: score -= 10
    elif disco > 70: score -= 5

    if row.get("defender_ativo") is False:
        score -= 15

    if 120 < diff <= 720:
        score -= 5

    updates = int(row.get("updates_pendentes") or 0)
    if updates > 20:    score -= 5
    elif updates > 10:  score -= 3
    elif updates > 5:   score -= 1

    return max(0.0, min(100.0, round(score, 1)))


def health_cor(score: float) -> str:
    if score >= 80: return "#10b981"
    if score >= 60: return "#f59e0b"
    if score >= 40: return "#ef4444"
    return "#7f1d1d"


def prever_disco_cheio(hostname: str, conn) -> dict | None:
    """Regressão linear no histórico de disco_c. Retorna dict ou None."""
    try:
        with conn.cursor() as c:
            c.execute("""
                SELECT timestamp, disco_c FROM historico_v6
                WHERE hostname = %s
                  AND disco_c IS NOT NULL
                  AND timestamp > NOW() - INTERVAL '30 days'
                ORDER BY timestamp
            """, (hostname,))
            rows = c.fetchall()

        if len(rows) < 10:
            return None

        df = pd.DataFrame(rows, columns=["ts", "disco_c"])
        df["h"] = (df["ts"] - df["ts"].min()).dt.total_seconds() / 3600
        x, y = df["h"].values, df["disco_c"].values
        coeffs = np.polyfit(x, y, 1)
        slope  = coeffs[0]

        if slope <= 0.001:
            return None

        taxa_dia = slope * 24
        if taxa_dia < 0.05:
            return None

        atual = float(y[-1])
        dias  = (100.0 - atual) / taxa_dia
        if dias > 365:
            return None

        return {"dias": max(1, int(dias)), "taxa_dia": round(taxa_dia, 2), "atual": round(atual, 1)}
    except Exception as e:
        log.debug("prever_disco [%s]: %s", hostname, e)
        return None


def detectar_anomalias(hostname: str, conn) -> list[dict]:
    """Z-score: detecta métricas acima de 2.5 desvios padrão vs mesma hora histórica."""
    try:
        with conn.cursor() as c:
            c.execute("""
                SELECT cpu, ram, disco_c, timestamp
                FROM historico_v6
                WHERE hostname = %s ORDER BY id DESC LIMIT 1
            """, (hostname,))
            row = c.fetchone()
            if not row:
                return []
            cpu_a, ram_a, disco_a, ts = row
            hora = ts.hour

            c.execute("""
                SELECT cpu, ram, disco_c FROM historico_v6
                WHERE hostname = %s
                  AND EXTRACT(HOUR FROM timestamp) = %s
                  AND timestamp > NOW() - INTERVAL '30 days'
                  AND timestamp < NOW() - INTERVAL '30 minutes'
            """, (hostname, hora))
            hist = c.fetchall()

        if len(hist) < 5:
            return []

        df = pd.DataFrame(hist, columns=["cpu", "ram", "disco_c"])
        anomalias = []
        for metrica, val in [("cpu", cpu_a), ("ram", ram_a)]:
            if val is None:
                continue
            s = df[metrica].dropna()
            if len(s) < 5 or s.std() < 1:
                continue
            z = (float(val) - s.mean()) / s.std()
            if z > 2.5:
                anomalias.append({
                    "metrica":  metrica.upper(),
                    "valor":    round(float(val), 1),
                    "media":    round(s.mean(), 1),
                    "desvio":   round(s.std(), 1),
                    "z_score":  round(z, 1),
                })
        return anomalias
    except Exception as e:
        log.debug("anomalia [%s]: %s", hostname, e)
        return []


def calcular_sla(hostname: str, conn, dias: int = 7) -> float:
    """% disponibilidade nos últimos N dias (gap > 15 min = offline)."""
    try:
        with conn.cursor() as c:
            c.execute(
                "SELECT timestamp FROM historico_v6 "
                "WHERE hostname = %s AND timestamp > NOW() - %s * INTERVAL '1 day' "
                "ORDER BY timestamp",
                (hostname, dias),
            )
            rows = c.fetchall()

        if not rows:
            return 0.0

        total_min  = dias * 24 * 60
        offline_min = 0.0
        tss = [r[0] for r in rows]

        inicio = datetime.now() - timedelta(days=dias)
        if tss[0] > inicio:
            gap = (tss[0] - inicio).total_seconds() / 60
            if gap > 15:
                offline_min += gap

        for i in range(1, len(tss)):
            gap = (tss[i] - tss[i - 1]).total_seconds() / 60
            if gap > 15:
                offline_min += gap - 5

        return max(0.0, min(100.0, round((1 - offline_min / total_min) * 100, 1)))
    except Exception as e:
        log.debug("sla [%s]: %s", hostname, e)
        return 0.0


def reconstruir_timeline(hostname: str, conn, dias: int = 7) -> list[dict]:
    """Reconstrói períodos online/offline para gráfico Gantt."""
    try:
        with conn.cursor() as c:
            c.execute(
                "SELECT timestamp FROM historico_v6 "
                "WHERE hostname = %s AND timestamp > NOW() - %s * INTERVAL '1 day' "
                "ORDER BY timestamp",
                (hostname, dias),
            )
            rows = c.fetchall()

        if not rows:
            return []

        tss = [r[0] for r in rows]
        segmentos: list[dict] = []
        inicio_online = tss[0]

        for i in range(1, len(tss)):
            gap = (tss[i] - tss[i - 1]).total_seconds() / 60
            if gap > 15:
                segmentos.append({
                    "hostname": hostname, "status": "Online",
                    "inicio": inicio_online, "fim": tss[i - 1],
                })
                segmentos.append({
                    "hostname": hostname, "status": "Offline",
                    "inicio": tss[i - 1], "fim": tss[i],
                })
                inicio_online = tss[i]

        segmentos.append({
            "hostname": hostname, "status": "Online",
            "inicio": inicio_online, "fim": tss[-1],
        })
        return segmentos
    except Exception as e:
        log.debug("timeline [%s]: %s", hostname, e)
        return []
