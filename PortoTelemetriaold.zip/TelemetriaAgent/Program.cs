using TelemetriaAgent;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;

// Ponto de entrada: monta o host que roda como console OU como Windows Service
IHost host = Host.CreateDefaultBuilder(args)
    .UseWindowsService(options => options.ServiceName = "TelemetriaAgent")
    .ConfigureServices(services =>
    {
        services.AddHostedService<Worker>();
    })
    .Build();

await host.RunAsync();
