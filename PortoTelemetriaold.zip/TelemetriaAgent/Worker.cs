using System.Diagnostics;
using System.Management;
using System.Net;
using System.Net.Http.Json;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Win32;

namespace TelemetriaAgent;

public sealed class Worker : BackgroundService
{
    private static readonly string ServerUrl =
        Environment.GetEnvironmentVariable("TELEMETRIA_SERVER_URL")
        ?? "http://192.168.3.52:8090/api/telemetry";

    private static readonly string Token =
        Environment.GetEnvironmentVariable("TELEMETRIA_TOKEN")
        ?? "Tk8_mQ9!zP2#vX7_wK5@jL3$mR9*fB2!xY8_dE4%qZ1#vW6_sN3";

    private static readonly Random _rng = new();

    // Caches com renovação periódica
    private static List<object> _swCache       = new();
    private static DateTime     _swCacheTs     = DateTime.MinValue;
    private static DateTime     _loginLastRead = DateTime.MinValue;
    private static int          _upCache       = -1;
    private static DateTime     _upCacheTs     = DateTime.MinValue;

    private readonly ILogger<Worker> _logger;
    private readonly HttpClient      _http;

    public Worker(ILogger<Worker> logger)
    {
        _logger = logger;
        _http   = new HttpClient(new HttpClientHandler { UseProxy = false, Proxy = null })
        {
            Timeout = TimeSpan.FromSeconds(30)
        };
        _http.DefaultRequestHeaders.Add("Authorization", $"Bearer {Token}");
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Agente iniciado. Servidor: {Url}", ServerUrl);
        while (!stoppingToken.IsCancellationRequested)
        {
            await EnviarTelemetria(stoppingToken);
            int jitter = _rng.Next(0, 20_000);
            try { await Task.Delay(300_000 + jitter, stoppingToken); }
            catch (OperationCanceledException) { break; }
        }
        _logger.LogInformation("Agente encerrado.");
    }

    // ── Envio de telemetria ────────────────────────────────────────────────────

    private async Task EnviarTelemetria(CancellationToken ct)
    {
        // Snapshot de processos ANTES do delay de 1 s (calcula CPU% por processo)
        var snapProc = TirarSnapshotProcessos();

        // Coletas paralelas que precisam de amostragem temporal (~1 s cada)
        double cpu = 0, netUp = 0, netDown = 0, discoLatMs = -1;
        int    latGw = -1, latInet = -1;
        List<object> pastasUso = new(), software = new(), discosFisicos = new(), conexoesExt = new();
        List<string> adminsLocais = new(), dnsServidores = new();
        bool   smartOk = true, fwDomain = true, fwPrivate = true, fwPublic = true, telaBloq = false;
        string gpuModelo = "Desconhecido", biosVersao = "Desconhecido";
        int    gpuMemMb = 0, idleMin = -1, updatesPend = -1;
        bool   rdpHabilitado = false, uacHabilitado = true, rebootInesperado = false, temBateria = false;
        string redeTipo = "Desconhecido", bateriaDescricao = "";
        List<string> usuariosLocais = new();

        await Task.WhenAll(
            Task.Run(() => cpu           = GetCpuUsage()),
            Task.Run(() => { var (u, d)  = GetNetworkThroughput(); netUp = u; netDown = d; }),
            Task.Run(() => discoLatMs    = GetDiskLatencia()),
            Task.Run(() => { var (g, i)  = GetLatenciaRede(); latGw = g; latInet = i; }),
            Task.Run(() => pastasUso     = GetDiskUsagePorPasta()),
            Task.Run(() => software      = GetSoftwareInstalado()),
            Task.Run(() => { var (fd, fp, fpb) = GetFirewallStatus(); fwDomain = fd; fwPrivate = fp; fwPublic = fpb; }),
            Task.Run(() => adminsLocais  = GetAdministradoresLocais()),
            Task.Run(() => smartOk       = GetSmartStatus()),
            Task.Run(() => { var (gm, gm2) = GetGpuInfo(); gpuModelo = gm; gpuMemMb = gm2; }),
            Task.Run(() => discosFisicos = GetDiscosFisicos()),
            Task.Run(() => conexoesExt   = GetConexoesExternas()),
            Task.Run(() => dnsServidores = GetDnsServidores()),
            Task.Run(() => { var (im, tb) = GetIdleInfo(); idleMin = im; telaBloq = tb; }),
            Task.Run(() => updatesPend   = GetUpdatesPendentes()),
            Task.Run(() => biosVersao    = GetBiosVersao()),
            Task.Run(() => rdpHabilitado    = GetRdpHabilitado()),
            Task.Run(() => uacHabilitado    = GetUacHabilitado()),
            Task.Run(() => redeTipo         = GetTipoRede()),
            Task.Run(() => rebootInesperado = GetRebootInesperado()),
            Task.Run(() => { var (tb, bd)   = GetBateriaDetalhada(); temBateria = tb; bateriaDescricao = bd; }),
            Task.Run(() => usuariosLocais   = GetUsuariosLocaisHabilitados())
        );

        double ram = GetRamUsage();
        GetBattery(out int batPercent, out bool carregador);
        GetDisk("C", out double discoCUso, out int discoCTotal);
        GetDisk("D", out double discoDUso, out int discoDTotal);

        var (defAtivo, defProduto, defUltimaDef, defScanDias) = GetDefenderStatus();
        var (monitCount, monitRes)  = GetMonitoresInfo();
        var processos  = GetTopProcessosDetalhado(snapProc);
        var eventos    = GetWindowsEvents();
        var logins     = GetLoginRecente();
        var portas     = GetPortasAbertas();
        int  tempCpu    = GetTemperaturaCpu();
        bool rebootPend = GetRebootPendente();
        bool bitlocker  = GetBitLockerStatus();
        string ultimoWU = GetUltimoWindowsUpdate();

        if (cpu > 85 || ram > 90 || discoCUso > 90)
            _logger.LogWarning("RECURSO CRÍTICO — CPU:{Cpu}% RAM:{Ram}% DiscoC:{Disco}%",
                               cpu, ram, discoCUso);

        var dados = new
        {
            hostname       = Environment.MachineName,
            modelo         = GetModel(),
            cpu_modelo     = GetCpuModel(),
            cpu,
            ram,
            ram_total      = GetRamTotalGb(),
            disco_c        = discoCUso,
            disco_c_total  = discoCTotal,
            disco_d        = discoDUso,
            disco_d_total  = discoDTotal,
            rede           = GetNetwork(),
            viloes         = cpu > 80 ? GetTopProcesses() : "Normal",
            bateria_status = batPercent,
            carregador,
            uptime         = GetUptime(),
            boot_time      = GetBootTime(),
            os_version     = GetOsVersion(),
            usuario        = GetLoggedUser(),
            ip_address     = GetLocalIp(),
            departamento   = Environment.GetEnvironmentVariable("TELEMETRIA_DEPARTAMENTO") ?? "Geral",
            // Observabilidade v1
            defender_ativo        = defAtivo,
            defender_produto      = defProduto,
            defender_ultima_def   = defUltimaDef,
            defender_scan_dias    = defScanDias,
            ultimo_windows_update = ultimoWU,
            net_kbps_up           = netUp,
            net_kbps_down         = netDown,
            processos,
            eventos,
            // Campos v2
            temperatura_cpu      = tempCpu,
            reboot_pendente      = rebootPend,
            bitlocker_ativo      = bitlocker,
            latencia_gateway_ms  = latGw,
            latencia_internet_ms = latInet,
            disco_latencia_ms    = discoLatMs,
            monitores_count      = monitCount,
            resolucao_principal  = monitRes,
            pasta_uso            = pastasUso,
            portas_abertas       = portas,
            logins,
            software,
            // Campos v3 — segurança / hardware / rede expandida
            firewall_domain      = fwDomain,
            firewall_private     = fwPrivate,
            firewall_public      = fwPublic,
            admins_locais        = adminsLocais,
            smart_ok             = smartOk,
            gpu_modelo           = gpuModelo,
            gpu_memoria_mb       = gpuMemMb,
            discos_fisicos       = discosFisicos,
            bios_versao          = biosVersao,
            conexoes_externas    = conexoesExt,
            dns_servidores       = dnsServidores,
            idle_minutos         = idleMin,
            tela_bloqueada       = telaBloq,
            updates_pendentes    = updatesPend,
            // Campos v4 — RDP, UAC, rede, reboot, bateria, usuários locais
            rdp_habilitado    = rdpHabilitado,
            uac_habilitado    = uacHabilitado,
            rede_tipo         = redeTipo,
            reboot_inesperado = rebootInesperado,
            tem_bateria       = temBateria,
            bateria_descricao = bateriaDescricao,
            usuarios_locais   = usuariosLocais,
        };

        int[] delays = { 5, 15, 30 };
        for (int attempt = 0; attempt <= delays.Length; attempt++)
        {
            try
            {
                var resp = await _http.PostAsJsonAsync(ServerUrl, dados, ct);
                if (resp.IsSuccessStatusCode)
                {
                    _logger.LogInformation("Telemetria enviada.");
                    return;
                }
                _logger.LogWarning("Servidor retornou {Code} {Reason}",
                    (int)resp.StatusCode, resp.ReasonPhrase);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                _logger.LogError("Falha ao enviar (tentativa {N}/{Total}): {Msg}",
                    attempt + 1, delays.Length + 1, ex.Message);
            }
            if (attempt < delays.Length)
            {
                _logger.LogInformation("Reenviando em {Delay}s...", delays[attempt]);
                try { await Task.Delay(delays[attempt] * 1_000, ct); }
                catch (OperationCanceledException) { throw; }
            }
        }
        _logger.LogError("Telemetria descartada após {N} tentativas.", delays.Length + 1);
    }

    // ── Helpers básicos ────────────────────────────────────────────────────────

    private static string GetUptime()
    {
        TimeSpan ts = TimeSpan.FromMilliseconds(Environment.TickCount64);
        return ts.Days > 0
            ? $"{ts.Days}d {ts.Hours}h {ts.Minutes}m"
            : $"{ts.Hours}h {ts.Minutes}m";
    }

    private static string GetBootTime()
    {
        var boot = DateTime.Now - TimeSpan.FromMilliseconds(Environment.TickCount64);
        return boot.ToString("dd/MM/yyyy HH:mm");
    }

    private static string GetLoggedUser()
    {
        try
        {
            using var p = new Process
            {
                StartInfo = new()
                {
                    FileName               = "query",
                    Arguments              = "user",
                    RedirectStandardOutput = true,
                    UseShellExecute        = false,
                    CreateNoWindow         = true
                }
            };
            p.Start();
            string out_ = p.StandardOutput.ReadToEnd();
            p.WaitForExit();
            foreach (var raw in out_.Split('\n').Skip(1))
            {
                var line = raw.TrimEnd();
                if (string.IsNullOrWhiteSpace(line)) continue;
                bool ativo = (line.Length > 0 && line[0] == '>')
                          || line.Contains("Ativo",  StringComparison.OrdinalIgnoreCase)
                          || line.Contains("Active", StringComparison.OrdinalIgnoreCase);
                if (!ativo) continue;
                var parts = line.TrimStart('>', ' ')
                                .Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length > 0) return parts[0];
            }
        }
        catch { }
        return Environment.UserName;
    }

    private static string GetOsVersion()
    {
        try
        {
            using var key = Registry.LocalMachine
                .OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
            var product = key?.GetValue("ProductName")?.ToString() ?? "";
            var build   = key?.GetValue("CurrentBuildNumber")?.ToString() ?? "";
            return $"{product} (Build {build})";
        }
        catch { return Environment.OSVersion.VersionString; }
    }

    private static string GetLocalIp()
    {
        try
        {
            return NetworkInterface.GetAllNetworkInterfaces()
                .Where(n => n.OperationalStatus == OperationalStatus.Up
                         && n.NetworkInterfaceType != NetworkInterfaceType.Loopback
                         && !n.Description.Contains("virtual", StringComparison.OrdinalIgnoreCase))
                .SelectMany(n => n.GetIPProperties().UnicastAddresses)
                .Where(a => a.Address.AddressFamily == AddressFamily.InterNetwork)
                .Select(a => a.Address.ToString())
                .FirstOrDefault() ?? "Desconhecido";
        }
        catch { return "Desconhecido"; }
    }

    private static string GetModel()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\BIOS");
            return key?.GetValue("SystemProductName")?.ToString()?.Trim() ?? "Desconhecido";
        }
        catch { return "Desconhecido"; }
    }

    private static string GetCpuModel()
    {
        try
        {
            using var key = Registry.LocalMachine
                .OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0");
            return key?.GetValue("ProcessorNameString")?.ToString()?.Trim() ?? "Desconhecido";
        }
        catch { return "Desconhecido"; }
    }

    private static double GetCpuUsage()
    {
        try
        {
            GetSystemTimes(out var idle1, out var k1, out var u1);
            Thread.Sleep(1000);
            GetSystemTimes(out var idle2, out var k2, out var u2);
            ulong ToU(FILETIME ft) => ((ulong)ft.dwHighDateTime << 32) | ft.dwLowDateTime;
            ulong sys  = (ToU(k2) - ToU(k1)) + (ToU(u2) - ToU(u1));
            ulong idle = ToU(idle2) - ToU(idle1);
            return sys == 0 ? 0.0 : Math.Round((double)(sys - idle) * 100.0 / sys, 1);
        }
        catch { return 0.0; }
    }

    private static double GetRamUsage()
    {
        var mem = new MEMORYSTATUSEX { dwLength = (uint)Marshal.SizeOf<MEMORYSTATUSEX>() };
        return GlobalMemoryStatusEx(ref mem) ? mem.dwMemoryLoad : 0.0;
    }

    private static int GetRamTotalGb()
    {
        var mem = new MEMORYSTATUSEX { dwLength = (uint)Marshal.SizeOf<MEMORYSTATUSEX>() };
        return GlobalMemoryStatusEx(ref mem)
            ? (int)Math.Round((double)mem.ullTotalPhys / 1024 / 1024 / 1024)
            : 0;
    }

    private static void GetDisk(string letra, out double usoPercent, out int totalGb)
    {
        usoPercent = 0.0; totalGb = 0;
        try
        {
            var d = new DriveInfo(letra);
            if (!d.IsReady) return;
            usoPercent = Math.Round(((d.TotalSize - d.AvailableFreeSpace) / (double)d.TotalSize) * 100, 1);
            totalGb    = (int)(d.TotalSize / 1024 / 1024 / 1024);
        }
        catch { }
    }

    private static void GetBattery(out int percent, out bool charging)
    {
        percent = 100; charging = true;
        if (GetSystemPowerStatus(out SystemPowerStatus sps))
        {
            percent  = sps.BatteryLifePercent == 255 ? 100 : sps.BatteryLifePercent;
            charging = sps.ACLineStatus == 1;
        }
    }

    private static string GetNetwork()
    {
        try
        {
            using var p = new Process
            {
                StartInfo = new() { FileName = "netsh", Arguments = "wlan show interfaces",
                    RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true }
            };
            p.Start();
            string out_ = p.StandardOutput.ReadToEnd();
            p.WaitForExit();
            if (out_.Contains("conectado", StringComparison.OrdinalIgnoreCase) ||
                out_.Contains("connected",  StringComparison.OrdinalIgnoreCase))
            {
                var ssid   = Regex.Match(out_, @"\bSSID\s*:\s*([^\r\n]+)");
                var signal = Regex.Match(out_, @"(?:Sinal|Signal)\s*:\s*(\d+)%");
                return $"Wi-Fi: {(ssid.Success ? ssid.Groups[1].Value.Trim() : "Oculta")} " +
                       $"({(signal.Success ? signal.Groups[1].Value + "%" : "100%")})";
            }
        }
        catch { }
        try
        {
            foreach (var ni in NetworkInterface.GetAllNetworkInterfaces()
                .Where(n => n.OperationalStatus == OperationalStatus.Up
                         && n.NetworkInterfaceType != NetworkInterfaceType.Loopback
                         && !n.Description.Contains("virtual", StringComparison.OrdinalIgnoreCase)
                         && !n.Description.Contains("vpn",     StringComparison.OrdinalIgnoreCase)))
            {
                long bps = ni.Speed;
                if (bps >= 1_000_000_000) return "Cabo (Giga - 1Gbps)";
                if (bps > 0)              return $"Cabo (Fast - {bps / 1_000_000}Mbps)";
            }
        }
        catch { }
        return "Desconhecido";
    }

    private static string GetTopProcesses()
    {
        var ps = Process.GetProcesses();
        try
        {
            return string.Join(", ", ps
                .Where(p  => { try { return p.WorkingSet64 > 10 * 1024 * 1024; } catch { return false; } })
                .OrderByDescending(p => { try { return p.TotalProcessorTime.TotalMilliseconds; } catch { return 0.0; } })
                .Take(3)
                .Select(p  => { try { return $"{p.ProcessName} ({p.WorkingSet64 / 1024 / 1024}MB)"; } catch { return p.ProcessName; } }));
        }
        catch { return "Erro"; }
        finally { foreach (var p in ps) try { p.Dispose(); } catch { } }
    }

    // ── Observabilidade ────────────────────────────────────────────────────────

    private static (bool ativo, string produto, string ultimaDef, int scanDias) GetDefenderStatus()
    {
        string produto = "Windows Defender";
        bool   ativo   = true;
        try
        {
            using var s = new ManagementObjectSearcher(
                @"root\SecurityCenter2",
                "SELECT displayName, productState FROM AntiVirusProduct");
            foreach (ManagementObject o in s.Get())
            {
                produto = o["displayName"]?.ToString() ?? "";
                uint state = Convert.ToUInt32(o["productState"]);
                ativo = ((state >> 12) & 0xF) == 1;
                break;
            }
        }
        catch { }

        string ultimaDef = "Desconhecido";
        int    scanDias  = -1;
        try
        {
            using var s = new ManagementObjectSearcher(
                @"root\Microsoft\Windows\Defender",
                "SELECT AntivirusSignatureLastUpdated, QuickScanAge FROM MSFT_MpComputerStatus");
            foreach (ManagementObject o in s.Get())
            {
                var raw = o["AntivirusSignatureLastUpdated"]?.ToString();
                if (raw != null)
                {
                    var dt = ManagementDateTimeConverter.ToDateTime(raw);
                    ultimaDef = dt.ToString("dd/MM/yyyy HH:mm");
                }
                if (o["QuickScanAge"] != null)
                    scanDias = Convert.ToInt32(o["QuickScanAge"]);
                break;
            }
        }
        catch { }

        return (ativo, produto, ultimaDef, scanDias);
    }

    private static string GetUltimoWindowsUpdate()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\Results\Install");
            var raw = key?.GetValue("LastSuccessTime")?.ToString();
            if (raw != null && DateTime.TryParse(raw, out var dt))
                return dt.ToString("dd/MM/yyyy HH:mm");
        }
        catch { }
        return "Desconhecido";
    }

    private static List<object> GetWindowsEvents()
    {
        var result = new List<object>();
        try
        {
            var since = DateTime.Now.AddMinutes(-12);
            foreach (string logName in new[] { "System", "Application" })
            {
                var log = new EventLog(logName);
                foreach (EventLogEntry e in log.Entries)
                {
                    if (e.TimeGenerated < since) continue;
                    if (e.EntryType != EventLogEntryType.Error &&
                        e.EntryType != EventLogEntryType.Warning) continue;
                    result.Add(new
                    {
                        nivel    = e.EntryType.ToString(),
                        fonte    = e.Source,
                        event_id = (int)(e.InstanceId & 0xFFFF),
                        mensagem = e.Message?.Length > 300 ? e.Message[..300] : e.Message ?? "",
                        log_name = logName,
                    });
                    if (result.Count >= 20) break;
                }
                if (result.Count >= 20) break;
            }
        }
        catch { }
        return result;
    }

    private static (double kbpsUp, double kbpsDown) GetNetworkThroughput()
    {
        try
        {
            var ifaces = NetworkInterface.GetAllNetworkInterfaces()
                .Where(n => n.OperationalStatus == OperationalStatus.Up
                         && n.NetworkInterfaceType != NetworkInterfaceType.Loopback
                         && !n.Description.Contains("virtual", StringComparison.OrdinalIgnoreCase))
                .ToList();
            var before = ifaces.Select(n => n.GetIPv4Statistics()).ToList();
            Thread.Sleep(1000);
            var after  = ifaces.Select(n => n.GetIPv4Statistics()).ToList();
            long sent = 0, recv = 0;
            for (int i = 0; i < ifaces.Count; i++)
            {
                sent += after[i].BytesSent     - before[i].BytesSent;
                recv += after[i].BytesReceived - before[i].BytesReceived;
            }
            return (Math.Round(sent * 8.0 / 1000, 1), Math.Round(recv * 8.0 / 1000, 1));
        }
        catch { return (0, 0); }
    }

    // ── Processos com CPU% ─────────────────────────────────────────────────────

    private static IReadOnlyList<(int Id, string Nome, TimeSpan CpuTime)> TirarSnapshotProcessos()
    {
        var result = new List<(int, string, TimeSpan)>();
        var ps = Process.GetProcesses();
        foreach (var p in ps)
        {
            try { result.Add((p.Id, p.ProcessName, p.TotalProcessorTime)); }
            catch { }
            finally { try { p.Dispose(); } catch { } }
        }
        return result;
    }

    private static List<object> GetTopProcessosDetalhado(
        IReadOnlyList<(int Id, string Nome, TimeSpan CpuTime)> snap)
    {
        var snapDict  = snap.ToDictionary(x => x.Id, x => x.CpuTime);
        double cores  = Environment.ProcessorCount;
        var ps = Process.GetProcesses();
        try
        {
            var items = new List<(string nome, long ramMb, int pid, double cpuPct)>();
            foreach (var p in ps)
            {
                try
                {
                    long ram = p.WorkingSet64;
                    if (ram < 5 * 1024 * 1024) continue;
                    double cpuPct = 0;
                    if (snapDict.TryGetValue(p.Id, out var prev))
                    {
                        double delta = (p.TotalProcessorTime - prev).TotalSeconds;
                        cpuPct = Math.Round(Math.Max(0, delta) / cores * 100, 1);
                    }
                    items.Add((p.ProcessName, ram / 1024 / 1024, p.Id, cpuPct));
                }
                catch { }
            }
            return items
                .OrderByDescending(x => x.ramMb)
                .Take(10)
                .Select(x => (object)new
                {
                    nome    = x.nome,
                    ram_mb  = x.ramMb,
                    pid     = x.pid,
                    cpu_pct = x.cpuPct,
                })
                .ToList();
        }
        catch { return new List<object>(); }
        finally { foreach (var p in ps) try { p.Dispose(); } catch { } }
    }

    // ── Novos helpers ──────────────────────────────────────────────────────────

    private static int GetTemperaturaCpu()
    {
        try
        {
            using var s = new ManagementObjectSearcher(
                @"root\WMI", "SELECT CurrentTemperature FROM MSAcpi_ThermalZoneTemperature");
            int maxC = 0;
            foreach (ManagementObject o in s.Get())
            {
                int c = (int)(Convert.ToDouble(o["CurrentTemperature"]) / 10.0 - 273.15);
                if (c > maxC) maxC = c;
            }
            return maxC > 0 ? maxC : -1;
        }
        catch { return -1; }
    }

    private static bool GetRebootPendente()
    {
        foreach (var k in new[]
        {
            @"SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired",
            @"SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending",
        })
        {
            try { using var r = Registry.LocalMachine.OpenSubKey(k); if (r != null) return true; }
            catch { }
        }
        try
        {
            using var r = Registry.LocalMachine
                .OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager");
            if (r?.GetValue("PendingFileRenameOperations") is string[] arr && arr.Length > 0)
                return true;
        }
        catch { }
        return false;
    }

    private static bool GetBitLockerStatus()
    {
        try
        {
            using var s = new ManagementObjectSearcher(
                @"root\CIMV2\Security\MicrosoftVolumeEncryption",
                "SELECT ProtectionStatus FROM Win32_EncryptableVolume WHERE DriveLetter='C:'");
            foreach (ManagementObject o in s.Get())
                return Convert.ToInt32(o["ProtectionStatus"]) == 1;
        }
        catch { }
        return false;
    }

    private static (int gw, int inet) GetLatenciaRede()
    {
        static int PingMs(string host)
        {
            try
            {
                using var ping  = new Ping();
                var       reply = ping.Send(host, 2000);
                return reply.Status == IPStatus.Success ? (int)reply.RoundtripTime : -1;
            }
            catch { return -1; }
        }
        string gateway = "";
        try
        {
            gateway = NetworkInterface.GetAllNetworkInterfaces()
                .Where(n => n.OperationalStatus == OperationalStatus.Up
                         && n.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                .SelectMany(n => n.GetIPProperties().GatewayAddresses)
                .Where(g => g.Address.AddressFamily == AddressFamily.InterNetwork)
                .Select(g => g.Address.ToString())
                .FirstOrDefault() ?? "";
        }
        catch { }
        return (string.IsNullOrEmpty(gateway) ? -1 : PingMs(gateway), PingMs("8.8.8.8"));
    }

    private static double GetDiskLatencia()
    {
        try
        {
            using var pc = new PerformanceCounter(
                "PhysicalDisk", "Avg. Disk sec/Transfer", "_Total");
            pc.NextValue();
            Thread.Sleep(500);
            float val = pc.NextValue();
            return val > 0 ? Math.Round(val * 1000.0, 2) : -1;
        }
        catch { return -1; }
    }

    private static (int count, string resolucao) GetMonitoresInfo()
    {
        try
        {
            int count = 0; string res = "Desconhecido";
            using var s = new ManagementObjectSearcher(
                "SELECT ScreenWidth, ScreenHeight FROM Win32_DesktopMonitor " +
                "WHERE ScreenWidth IS NOT NULL");
            foreach (ManagementObject o in s.Get())
            {
                count++;
                if (count == 1) res = $"{o["ScreenWidth"]}x{o["ScreenHeight"]}";
            }
            return count > 0 ? (count, res) : (1, "Desconhecido");
        }
        catch { return (1, "Desconhecido"); }
    }

    private static List<object> GetDiskUsagePorPasta()
    {
        var items = new List<(string nome, long mb)>();
        var dirs = new[]
        {
            (Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads"), "Downloads"),
            (Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Desktop"),   "Desktop"),
            (Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Documents"), "Documentos"),
            (Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Videos"),    "Videos"),
            (Path.GetTempPath(), "Temp"),
        };
        foreach (var (path, nome) in dirs)
        {
            if (!Directory.Exists(path)) continue;
            try
            {
                long size = 0; int count = 0;
                foreach (var f in new DirectoryInfo(path)
                    .EnumerateFiles("*", SearchOption.AllDirectories))
                {
                    try { size += f.Length; } catch { }
                    if (++count >= 10_000) break;
                }
                items.Add((nome, size / 1024 / 1024));
            }
            catch { }
        }
        return items
            .OrderByDescending(x => x.mb)
            .Select(x => (object)new { pasta = x.nome, tamanho_mb = x.mb })
            .ToList();
    }

    private static List<object> GetSoftwareInstalado()
    {
        if (_swCache.Count > 0 && (DateTime.Now - _swCacheTs).TotalHours < 6)
            return new List<object>(); // API pula atualização quando lista vazia

        var lista = new List<object>();
        foreach (var path in new[]
        {
            @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
            @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
        })
        {
            try
            {
                using var key = Registry.LocalMachine.OpenSubKey(path);
                if (key == null) continue;
                foreach (var sub in key.GetSubKeyNames())
                {
                    try
                    {
                        using var app  = key.OpenSubKey(sub);
                        var       nome = app?.GetValue("DisplayName")?.ToString();
                        if (string.IsNullOrWhiteSpace(nome)) continue;
                        lista.Add(new
                        {
                            nome,
                            versao    = app?.GetValue("DisplayVersion")?.ToString() ?? "",
                            publisher = app?.GetValue("Publisher")?.ToString()      ?? "",
                            instalado = app?.GetValue("InstallDate")?.ToString()    ?? "",
                        });
                    }
                    catch { }
                }
            }
            catch { }
        }
        _swCache   = lista.Take(150).ToList();
        _swCacheTs = DateTime.Now;
        return _swCache;
    }

    private static List<object> GetLoginRecente()
    {
        var    result = new List<object>();
        DateTime since = _loginLastRead == DateTime.MinValue
            ? DateTime.Now.AddHours(-24)
            : _loginLastRead.AddSeconds(-30);
        _loginLastRead = DateTime.Now;
        try
        {
            var log = new EventLog("Security");
            foreach (EventLogEntry e in log.Entries)
            {
                if (e.TimeGenerated < since) continue;
                long id = e.InstanceId;
                if (id != 4624 && id != 4634 && id != 4647 && id != 4625) continue;
                string tipo = id switch
                {
                    4624            => "Logon",
                    4634 or 4647    => "Logoff",
                    4625            => "Falha_Logon",
                    _               => "Desconhecido",
                };
                result.Add(new
                {
                    timestamp = e.TimeGenerated.ToString("yyyy-MM-ddTHH:mm:ss"),
                    tipo,
                    event_id  = (int)(id & 0xFFFF),
                    usuario   = e.UserName ?? "",
                });
                if (result.Count >= 20) break;
            }
        }
        catch { }
        return result;
    }

    private static List<int> GetPortasAbertas()
    {
        try
        {
            return IPGlobalProperties.GetIPGlobalProperties()
                .GetActiveTcpListeners()
                .Select(ep => ep.Port)
                .Distinct()
                .OrderBy(p => p)
                .Take(50)
                .ToList();
        }
        catch { return new List<int>(); }
    }

    // ── Novos métodos v3 ──────────────────────────────────────────────────────

    // 1. Status do Firewall Windows (Domain / Private / Public)
    private static (bool domain, bool private_, bool public_) GetFirewallStatus()
    {
        static bool ReadProfile(string name)
        {
            try
            {
                using var k = Registry.LocalMachine.OpenSubKey(
                    $@"SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\{name}");
                return Convert.ToInt32(k?.GetValue("EnableFirewall") ?? 1) == 1;
            }
            catch { return true; }
        }
        return (ReadProfile("DomainProfile"), ReadProfile("StandardProfile"), ReadProfile("PublicProfile"));
    }

    // 2. Membros do grupo Administradores locais
    private static List<string> GetAdministradoresLocais()
    {
        // Tenta via WMI primeiro (independe de idioma do SO)
        try
        {
            var result = new List<string>();
            using var s = new ManagementObjectSearcher(
                $"SELECT PartComponent FROM Win32_GroupUser " +
                $"WHERE GroupComponent=\"Win32_Group.Domain='{Environment.MachineName}',Name='Administrators'\"");
            foreach (ManagementObject o in s.Get())
            {
                var part = o["PartComponent"]?.ToString() ?? "";
                // Formato: Win32_UserAccount.Domain="HOST",Name="user"
                var m = System.Text.RegularExpressions.Regex.Match(part, @"Name=""([^""]+)""");
                if (m.Success) result.Add(m.Groups[1].Value);
            }
            if (result.Count > 0) return result;
        }
        catch { }

        // Fallback: net localgroup (com parsing multilíngue)
        try
        {
            using var p = new Process
            {
                StartInfo = new()
                {
                    FileName               = "net",
                    Arguments              = "localgroup Administrators",
                    RedirectStandardOutput = true,
                    UseShellExecute        = false,
                    CreateNoWindow         = true,
                    StandardOutputEncoding = System.Text.Encoding.GetEncoding(850),
                }
            };
            p.Start();
            var output = p.StandardOutput.ReadToEnd();
            p.WaitForExit(5000);

            var result  = new List<string>();
            bool reading = false;
            foreach (var raw in output.Split('\n'))
            {
                var trim = raw.Trim('\r', ' ');
                if (trim.StartsWith("---")) { reading = true; continue; }
                if (!reading) continue;
                // Linha vazia: pula (pode haver espaço entre separador e membros)
                if (string.IsNullOrEmpty(trim)) continue;
                // Linha de encerramento em qualquer idioma (EN/PT/ES/FR)
                if (trim.StartsWith("The command") ||
                    trim.StartsWith("O comando")   ||
                    trim.StartsWith("El comando")  ||
                    trim.StartsWith("La commande")) break;
                result.Add(trim);
            }
            return result;
        }
        catch { return new List<string>(); }
    }

    // 3. S.M.A.R.T. — saúde dos discos físicos
    private static bool GetSmartStatus()
    {
        try
        {
            using var s = new ManagementObjectSearcher(
                @"root\WMI",
                "SELECT PredictFailure FROM MSStorageDriver_FailurePredictStatus");
            foreach (ManagementObject o in s.Get())
                if (Convert.ToBoolean(o["PredictFailure"])) return false;
            return true;
        }
        catch { return true; }
    }

    // 4. GPU — modelo e VRAM
    private static (string modelo, int memoriaMb) GetGpuInfo()
    {
        try
        {
            string melhorModelo = "Desconhecido";
            long   melhorMem    = 0;
            using var s = new ManagementObjectSearcher(
                "SELECT Name, AdapterRAM FROM Win32_VideoController");
            foreach (ManagementObject o in s.Get())
            {
                string nome = o["Name"]?.ToString() ?? "";
                long   mem  = o["AdapterRAM"] != null ? Convert.ToInt64(o["AdapterRAM"]) : 0;
                if (mem > melhorMem) { melhorMem = mem; melhorModelo = nome; }
            }
            return (melhorModelo, (int)(melhorMem / 1024 / 1024));
        }
        catch { return ("Desconhecido", 0); }
    }

    // 5. Discos físicos (modelo, serial, tipo, tamanho) via MSFT_PhysicalDisk
    private static List<object> GetDiscosFisicos()
    {
        var result = new List<object>();
        try
        {
            using var s = new ManagementObjectSearcher(
                @"root\Microsoft\Windows\Storage",
                "SELECT FriendlyName, SerialNumber, Size, MediaType FROM MSFT_PhysicalDisk");
            foreach (ManagementObject o in s.Get())
            {
                uint media = o["MediaType"] != null ? Convert.ToUInt32(o["MediaType"]) : 0;
                string tipo = media switch { 3 => "HDD", 4 => "SSD", 5 => "SCM", _ => "Desconhecido" };
                ulong  size = o["Size"] != null ? Convert.ToUInt64(o["Size"]) : 0;
                result.Add(new
                {
                    modelo      = o["FriendlyName"]?.ToString()?.Trim() ?? "Desconhecido",
                    serial      = o["SerialNumber"]?.ToString()?.Trim() ?? "",
                    tipo,
                    tamanho_gb  = (int)(size / 1024 / 1024 / 1024),
                });
            }
        }
        catch { }
        return result;
    }

    // 6. Conexões TCP ativas com IPs externos (exclui redes privadas)
    private static List<object> GetConexoesExternas()
    {
        try
        {
            return IPGlobalProperties.GetIPGlobalProperties()
                .GetActiveTcpConnections()
                .Where(c => c.State == TcpState.Established
                         && !_IsPrivateIp(c.RemoteEndPoint.Address))
                .GroupBy(c => new { ip = c.RemoteEndPoint.Address.ToString(),
                                    porta = c.RemoteEndPoint.Port })
                .Select(g => (object)new { ip = g.Key.ip, porta = g.Key.porta })
                .Take(20)
                .ToList();
        }
        catch { return new List<object>(); }
    }

    private static bool _IsPrivateIp(IPAddress ip)
    {
        if (ip.AddressFamily != AddressFamily.InterNetwork) return true;
        byte[] b = ip.GetAddressBytes();
        return b[0] == 10
            || (b[0] == 172 && b[1] >= 16 && b[1] <= 31)
            || (b[0] == 192 && b[1] == 168)
            || b[0] == 127;
    }

    // 7. Servidores DNS configurados nas interfaces ativas
    private static List<string> GetDnsServidores()
    {
        try
        {
            return NetworkInterface.GetAllNetworkInterfaces()
                .Where(n => n.OperationalStatus == OperationalStatus.Up
                         && n.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                .SelectMany(n => n.GetIPProperties().DnsAddresses)
                .Where(a => a.AddressFamily == AddressFamily.InterNetwork)
                .Select(a => a.ToString())
                .Distinct()
                .Take(5)
                .ToList();
        }
        catch { return new List<string>(); }
    }

    // 8. Idle time e status de bloqueio de tela (via Security Event Log)
    private static (int idleMin, bool telaBloqueada) GetIdleInfo()
    {
        DateTime? lastLock = null, lastActive = null;
        try
        {
            var log    = new EventLog("Security");
            int total  = log.Entries.Count;
            var cutoff = DateTime.Now.AddHours(-8);
            for (int i = total - 1; i >= Math.Max(0, total - 300); i--)
            {
                var e  = log.Entries[i];
                if (e.TimeGenerated < cutoff) break;
                long id = e.InstanceId & 0xFFFF;
                if (id == 4800 && lastLock   == null) lastLock   = e.TimeGenerated;
                if ((id == 4801 || id == 4624) && lastActive == null) lastActive = e.TimeGenerated;
                if (lastLock.HasValue && lastActive.HasValue) break;
            }
        }
        catch { }

        bool bloqueada = lastLock.HasValue &&
                        (!lastActive.HasValue || lastLock > lastActive);
        DateTime? refTime = bloqueada ? lastLock : lastActive;
        int idleMin = refTime.HasValue
            ? (int)(DateTime.Now - refTime.Value).TotalMinutes
            : -1;
        return (idleMin, bloqueada);
    }

    // 9. Atualizações Windows pendentes via Windows Update Agent (COM, cache 1h)
    private static int GetUpdatesPendentes()
    {
        if (_upCache >= 0 && (DateTime.Now - _upCacheTs).TotalHours < 1)
            return _upCache;
        try
        {
            var type = Type.GetTypeFromProgID("Microsoft.Update.Session");
            if (type == null) return -1;
            dynamic session  = Activator.CreateInstance(type)!;
            dynamic searcher = session.CreateUpdateSearcher();
            searcher.Online  = false;
            dynamic result   = searcher.Search("IsInstalled=0 AND IsHidden=0 AND Type='Software'");
            _upCache   = (int)result.Updates.Count;
            _upCacheTs = DateTime.Now;
            return _upCache;
        }
        catch { return -1; }
    }

    // 10. Versão do BIOS/UEFI
    private static string GetBiosVersao()
    {
        try
        {
            using var k = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\BIOS");
            string ver  = k?.GetValue("BIOSVersion")?.ToString()?.Trim() ?? "";
            string date = k?.GetValue("BIOSReleaseDate")?.ToString()?.Trim() ?? "";
            if (string.IsNullOrEmpty(ver)) return "Desconhecido";
            return string.IsNullOrEmpty(date) ? ver : $"{ver} ({date})";
        }
        catch { return "Desconhecido"; }
    }

    // ── Novos métodos v4 ──────────────────────────────────────────────────────

    private static bool GetRdpHabilitado()
    {
        try
        {
            using var k = Registry.LocalMachine.OpenSubKey(
                @"SYSTEM\CurrentControlSet\Control\Terminal Server");
            var val = k?.GetValue("fDenyTSConnections");
            return val != null && Convert.ToInt32(val) == 0;
        }
        catch { return false; }
    }

    private static bool GetUacHabilitado()
    {
        try
        {
            using var k = Registry.LocalMachine.OpenSubKey(
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System");
            var val = k?.GetValue("EnableLUA");
            // Chave ausente = UAC habilitado por padrão
            return val == null || Convert.ToInt32(val) != 0;
        }
        catch { return true; }
    }

    private static string GetTipoRede()
    {
        try
        {
            bool temWifi = NetworkInterface.GetAllNetworkInterfaces()
                .Any(n => n.OperationalStatus == OperationalStatus.Up
                       && (n.NetworkInterfaceType == NetworkInterfaceType.Wireless80211
                           || n.Description.Contains("Wi-Fi",    StringComparison.OrdinalIgnoreCase)
                           || n.Description.Contains("Wireless", StringComparison.OrdinalIgnoreCase)));
            if (temWifi) return "Wi-Fi";
            bool temEthernet = NetworkInterface.GetAllNetworkInterfaces()
                .Any(n => n.OperationalStatus == OperationalStatus.Up
                       && (n.NetworkInterfaceType == NetworkInterfaceType.Ethernet
                           || n.NetworkInterfaceType == NetworkInterfaceType.GigabitEthernet
                           || n.NetworkInterfaceType == NetworkInterfaceType.FastEthernetT
                           || n.NetworkInterfaceType == NetworkInterfaceType.FastEthernetFx)
                       && !n.Description.Contains("virtual", StringComparison.OrdinalIgnoreCase)
                       && !n.Description.Contains("vpn",     StringComparison.OrdinalIgnoreCase));
            return temEthernet ? "Ethernet" : "Desconhecido";
        }
        catch { return "Desconhecido"; }
    }

    private static bool GetRebootInesperado()
    {
        // Event 6008 = o desligamento anterior foi inesperado (queda de energia, crash, etc.)
        try
        {
            var cutoff = DateTime.Now.AddDays(-30);
            using var log = new EventLog("System");
            int total = log.Entries.Count;
            for (int i = total - 1; i >= Math.Max(0, total - 500); i--)
            {
                var e = log.Entries[i];
                if (e.TimeGenerated < cutoff) break;
                if ((e.InstanceId & 0xFFFF) == 6008) return true;
            }
            return false;
        }
        catch { return false; }
    }

    private static (bool temBateria, string descricao) GetBateriaDetalhada()
    {
        try
        {
            using var s = new ManagementObjectSearcher("SELECT BatteryStatus FROM Win32_Battery");
            foreach (ManagementObject o in s.Get())
            {
                int code = o["BatteryStatus"] != null ? Convert.ToInt32(o["BatteryStatus"]) : 0;
                string desc = code switch
                {
                    1       => "Descarregando",
                    2       => "Carregado (AC)",
                    3       => "Totalmente carregado",
                    4       => "Bateria fraca",
                    6       => "Carregando",
                    7 or 8  => "Carregando",
                    11      => "Parcialmente carregado",
                    _       => "Desconhecido"
                };
                return (true, desc);
            }
            return (false, "");
        }
        catch { return (false, ""); }
    }

    private static List<string> GetUsuariosLocaisHabilitados()
    {
        try
        {
            using var s = new ManagementObjectSearcher(
                $"SELECT Name FROM Win32_UserAccount " +
                $"WHERE LocalAccount=True AND Disabled=False AND Lockout=False " +
                $"AND Domain='{Environment.MachineName}'");
            return s.Get().Cast<ManagementObject>()
                .Select(o => o["Name"]?.ToString() ?? "")
                .Where(n => !string.IsNullOrEmpty(n))
                .ToList();
        }
        catch { return new List<string>(); }
    }

    // ── P/Invoke — kernel32.dll ────────────────────────────────────────────────

    [DllImport("kernel32.dll")] private static extern bool GetSystemPowerStatus(out SystemPowerStatus s);
    [DllImport("kernel32.dll")] private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX m);
    [DllImport("kernel32.dll")] private static extern bool GetSystemTimes(
        out FILETIME idle, out FILETIME kernel, out FILETIME user);

    private struct SystemPowerStatus
    {
        public byte ACLineStatus, BatteryFlag, BatteryLifePercent, Reserved1;
        public uint BatteryLifeTime, BatteryFullLifeTime;
    }

    private struct MEMORYSTATUSEX
    {
        public uint  dwLength, dwMemoryLoad;
        public ulong ullTotalPhys, ullAvailPhys, ullTotalPageFile,
                     ullAvailPageFile, ullTotalVirtual, ullAvailVirtual;
        public uint  dwAvailExtendedVirtual;
    }

    private struct FILETIME { public uint dwLowDateTime, dwHighDateTime; }
}
