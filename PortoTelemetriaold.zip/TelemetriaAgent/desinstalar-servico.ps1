#Requires -RunAsAdministrator

$serviceName = "TelemetriaAgent"

$svc = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if (-not $svc) {
    Write-Host "Servico '$serviceName' nao encontrado. Nada a fazer."
    exit 0
}

if ($svc.Status -ne "Stopped") {
    Write-Host "Parando servico..."
    Stop-Service -Name $serviceName -Force
    Start-Sleep -Seconds 2
}

sc.exe delete $serviceName | Out-Null
Write-Host "Servico '$serviceName' removido com sucesso."
