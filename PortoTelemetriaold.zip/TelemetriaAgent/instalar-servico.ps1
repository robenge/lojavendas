#Requires -RunAsAdministrator
param(
    [string]$Token       = "Tk8_mQ9!zP2#vX7_wK5@jL3`$mR9*fB2!xY8_dE4%qZ1#vW6_sN3",
    [string]$ServerUrl   = "http://192.168.3.52:8090/api/telemetry",
    [string]$Departamento = "Geral"
)

$serviceName = "TelemetriaAgent"
$displayName = "Agente de Telemetria Corporativo"
$description = "Coleta e envia metricas de hardware ao servidor de telemetria."
$exePath     = Join-Path $PSScriptRoot "publish\TelemetriaAgent.exe"

Write-Host ""
Write-Host "============================================"
Write-Host " INSTALADOR DO AGENTE DE TELEMETRIA"
Write-Host "============================================"
Write-Host ""

# Para o servico ANTES de compilar (o exe fica bloqueado enquanto o servico roda)
$existing = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($existing) {
    Write-Host "Parando servico existente para liberar o executavel..." -ForegroundColor Yellow
    if ($existing.Status -ne "Stopped") {
        Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 3
    }
    sc.exe delete $serviceName | Out-Null
    Start-Sleep -Seconds 2
    Write-Host "Servico removido." -ForegroundColor Yellow
}

# Compila SEMPRE para garantir que o executavel esta atualizado
Write-Host "Compilando o agente (versao mais recente)..." -ForegroundColor Cyan
Push-Location $PSScriptRoot
$buildOutput = dotnet publish --configuration Release --runtime win-x64 --self-contained true -p:PublishSingleFile=true --output publish/ 2>&1
Pop-Location

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "ERRO na compilacao:" -ForegroundColor Red
    $buildOutput | ForEach-Object { Write-Host "  $_" -ForegroundColor Red }
    Write-Host ""
    Write-Host "Verifique se o .NET 8 SDK esta instalado: dotnet --version" -ForegroundColor Yellow
    exit 1
}

if (-not (Test-Path $exePath)) {
    Write-Error "Executavel nao gerado em: $exePath"
    exit 1
}

$exeInfo = Get-Item $exePath
Write-Host "Compilado com sucesso. Data: $($exeInfo.LastWriteTime)" -ForegroundColor Green

# Cria o servico
Write-Host "Instalando servico '$serviceName'..."
sc.exe create $serviceName binPath= "`"$exePath`"" start= auto DisplayName= "$displayName" | Out-Null
sc.exe description $serviceName "$description" | Out-Null

# Reinicia automaticamente em caso de falha (3 tentativas com 60s de espera)
sc.exe failure $serviceName reset= 86400 actions= restart/60000/restart/60000/restart/60000 | Out-Null

# Define variaveis de ambiente no registro do servico
# (servicos Windows NAO herdam variaveis do usuario — por isso usamos o registro)
$regPath = "HKLM:\SYSTEM\CurrentControlSet\Services\$serviceName"
Set-ItemProperty -Path $regPath -Name "Environment" -Type MultiString -Value @(
    "TELEMETRIA_TOKEN=$Token",
    "TELEMETRIA_SERVER_URL=$ServerUrl",
    "TELEMETRIA_DEPARTAMENTO=$Departamento"
)
Write-Host "Variaveis de ambiente configuradas no registro." -ForegroundColor Green

# Inicia o servico
Write-Host "Iniciando servico..."
Start-Service -Name $serviceName -ErrorAction SilentlyContinue
Start-Sleep -Seconds 3

$svc = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
$statusColor = if ($svc.Status -eq "Running") { "Green" } else { "Red" }

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host " Servico  : $($svc.DisplayName)"             -ForegroundColor Cyan
Write-Host " Status   : $($svc.Status)"                  -ForegroundColor $statusColor
Write-Host " Exe      : $exePath"                        -ForegroundColor Cyan
Write-Host " Servidor : $ServerUrl"                      -ForegroundColor Cyan
Write-Host " Depto    : $Departamento"                   -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

if ($svc.Status -eq "Running") {
    Write-Host "Agente instalado e rodando com sucesso!" -ForegroundColor Green
} else {
    Write-Host "ATENCAO: Servico nao iniciou. Verifique os logs:" -ForegroundColor Red
    Write-Host "  Get-EventLog -LogName Application -Source TelemetriaAgent -Newest 10"
}

Write-Host ""
Write-Host "Comandos uteis (PowerShell Admin):"
Write-Host "  Ver logs    : Get-EventLog -LogName Application -Source TelemetriaAgent -Newest 20"
Write-Host "  Parar       : Stop-Service TelemetriaAgent"
Write-Host "  Iniciar     : Start-Service TelemetriaAgent"
Write-Host "  Desinstalar : .\desinstalar-servico.ps1"
Write-Host ""
