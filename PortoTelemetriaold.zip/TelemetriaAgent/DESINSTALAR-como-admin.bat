@echo off
:: Este arquivo deve ser executado com botao direito > "Executar como administrador"
powershell.exe -ExecutionPolicy Bypass -File "%~dp0desinstalar-servico.ps1"
pause
