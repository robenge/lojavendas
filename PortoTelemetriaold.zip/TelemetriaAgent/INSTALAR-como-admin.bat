@echo off
chcp 65001 > nul

:: ── Auto-elevação para Administrador ─────────────────────────────────────────
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo  Solicitando permissoes de Administrador...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs -WorkingDirectory '%~dp0'"
    exit /b
)

:: ── Já está como Admin — executar instalador ─────────────────────────────────
chcp 65001 > nul
echo.
echo  ============================================
echo   INSTALADOR DO AGENTE DE TELEMETRIA v3
echo  ============================================
echo.
echo  Parando servico, compilando e instalando...
echo  Aguarde — isso pode levar 1-2 minutos.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar-servico.ps1"

echo.
pause
