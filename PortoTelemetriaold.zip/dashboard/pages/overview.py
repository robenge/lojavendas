import dash
import logging
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Input, Output, State, callback, dash_table, dcc, html
from datetime import datetime

log = logging.getLogger(__name__)

from analytics import calcular_health_score
from config import get_limiares
from dashboard.components import kpi_card, page_header, fmt_ts
from database import get_conn

dash.register_page(__name__, path="/", name="Painel", title="Neon — Painel")


def layout(**kwargs):
    return html.Div(className="page-content", children=[
        dcc.Interval(id="ov-interval", interval=30_000, n_intervals=0),
        page_header("PAINEL GERAL", "Visao em tempo real do parque tecnologico",
                    "fa-solid fa-gauge"),

        # Filtro / Modo crise
        html.Div(className="panel neon-cyan", style={"marginBottom": "1rem"}, children=[
            html.Div(className="grid-3", children=[
                html.Div([
                    html.Label("CPU ALERTA (%)", className="login-label"),
                    dcc.Input(id="cfg-cpu", type="number", value=85,
                              className="login-input", style={"marginBottom": 0}),
                ]),
                html.Div([
                    html.Label("RAM ALERTA (%)", className="login-label"),
                    dcc.Input(id="cfg-ram", type="number", value=90,
                              className="login-input", style={"marginBottom": 0}),
                ]),
                html.Div([
                    html.Label("DISCO ALERTA (%)", className="login-label"),
                    dcc.Input(id="cfg-disco", type="number", value=90,
                              className="login-input", style={"marginBottom": 0}),
                ]),
            ]),
            html.Div(style={"display": "flex", "alignItems": "center", "gap": "1rem", "marginTop": ".75rem"}, children=[
                html.Button("APLICAR", id="btn-cfg-aplicar", n_clicks=0,
                            className="btn-login", style={"width": "auto", "padding": ".4rem 1rem"}),
                html.Span(id="cfg-feedback", style={"fontSize": ".7rem", "color": "#34d399", "fontWeight": "700"}),
                html.Div(style={"marginLeft": "auto"}, children=[
                    dcc.RadioItems(
                        id="filtro-crise",
                        options=[{"label": " TODOS", "value": "ALL"}, {"label": " APENAS CRITICOS", "value": "CRISE"}],
                        value="ALL", inline=True,
                        style={"fontSize": ".7rem", "fontWeight": "700", "color": "#94a3b8"},
                    ),
                ]),
            ]),
        ]),

        # KPI cards
        html.Div(id="kpi-container", className="kpi-grid",
                 style={"marginBottom": "1rem"}),

        # Graficos de distribuição + Top 5
        html.Div(className="grid-2", style={"marginBottom": "1rem"}, children=[
            html.Div(className="panel neon-cyan", children=[
                html.P("DISTRIBUICAO POR LOCALIDADE", className="section-title"),
                dcc.Graph(id="grafico-pizza", config={"displayModeBar": False},
                          responsive=True,
                          style={"height": "250px", "width": "100%"}),
            ]),
            html.Div(className="panel neon-purple", children=[
                html.P("TOP 5 — MAIOR USO DE CPU", className="section-title"),
                dcc.Graph(id="grafico-top5", config={"displayModeBar": False},
                          responsive=True,
                          style={"height": "250px", "width": "100%"}),
            ]),
        ]),

        # Tabela principal
        html.Div(className="panel neon-cyan", children=[
            html.Div(style={"display": "flex", "justifyContent": "space-between", "marginBottom": ".75rem"}, children=[
                html.P("INVENTARIO — DIAGNOSTICO EM TEMPO REAL", className="section-title",
                       style={"marginBottom": 0}),
                html.Span(id="ultima-atualizacao-txt",
                          style={"fontSize": ".6rem", "color": "#475569", "alignSelf": "center"}),
            ]),
            html.Div(id="tabela-overview"),
        ]),

        # Gráfico histórico
        html.Div(className="panel neon-cyan", children=[
            html.P("TENDENCIA INDIVIDUAL", className="section-title"),
            html.Div(className="grid-2", children=[
                dcc.Dropdown(id="dropdown-host", placeholder="Selecione um hostname...",
                             style={"color": "#1e293b"}),
                dcc.Dropdown(id="dropdown-metrica",
                             options=[
                                 {"label": "CPU + RAM", "value": "cpu_ram"},
                                 {"label": "Disco C + D", "value": "disco"},
                             ],
                             value="cpu_ram", clearable=False,
                             style={"color": "#1e293b"}),
            ], style={"marginBottom": ".75rem"}),
            dcc.Graph(id="grafico-historico-ov"),
        ]),
    ])


# ── Callback: aplicar config ──────────────────────────────────────────────────
@callback(
    Output("cfg-feedback", "children"),
    Input("btn-cfg-aplicar", "n_clicks"),
    [dash.dependencies.State("cfg-cpu", "value"),
     dash.dependencies.State("cfg-ram", "value"),
     dash.dependencies.State("cfg-disco", "value")],
    prevent_initial_call=True,
)
def aplicar_config(n, cpu, ram, disco):
    from config import set_limiares
    set_limiares(cpu=cpu, ram=ram, disco=disco)
    return f"Salvo: CPU {cpu}% | RAM {ram}% | Disco {disco}%"


# ── Callback: painel principal ────────────────────────────────────────────────
@callback(
    [Output("kpi-container", "children"),
     Output("tabela-overview", "children"),
     Output("dropdown-host", "options"),
     Output("grafico-pizza", "figure"),
     Output("grafico-top5", "figure"),
     Output("ultima-atualizacao-txt", "children")],
    [Input("ov-interval", "n_intervals"),
     Input("filtro-crise", "value"),
     Input("session-store", "data")],
)
def atualizar_painel(n, modo, session):
    if not session or not session.get("authenticated"):
        vazio = px.pie(); _estilo_grafico(vazio)
        return [], html.Div(), [], vazio, vazio, ""

    lim = get_limiares()
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("SELECT * FROM maquinas_v6 ORDER BY hostname")
                rows = c.fetchall()
                cols = [d[0] for d in c.description]

                # Trends: últimas 2 leituras por máquina
                c.execute("""
                    SELECT hostname, cpu, ram
                    FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY hostname ORDER BY id DESC) rn
                          FROM historico_v6 WHERE timestamp > NOW() - INTERVAL '2 hours') t
                    WHERE rn <= 2
                """)
                trend_rows = c.fetchall()
    except Exception as e:
        err = html.Div(f"ERRO DB: {e}", style={"color": "#f87171", "padding": "1rem"})
        return [], err, [], px.pie(), px.bar(), ""

    if not rows:
        return ([], html.Div("AGUARDANDO DADOS DO AGENTE...",
                             style={"color": "#475569", "padding": "1rem", "textAlign": "center"}),
                [], px.pie(), px.bar(), "")

    df = pd.DataFrame(rows, columns=cols)
    agora = datetime.now()
    df["diff"] = (agora - df["ultima_atualizacao"]).dt.total_seconds()

    # Calcular trends
    trends: dict[str, dict] = {}
    for h, cpu, ram in trend_rows:
        if h not in trends:
            trends[h] = {"cpu": [cpu], "ram": [ram]}
        elif len(trends[h]["cpu"]) < 2:
            trends[h]["cpu"].append(cpu)
            trends[h]["ram"].append(ram)

    # KPI cards
    ativos   = len(df[df["diff"] <= 720])
    offline  = len(df[df["diff"] > 720])
    home     = len(df[(df["localidade"] == "Home Office") & (df["diff"] <= 720)])
    c_cpu    = len(df[(df["cpu"] > lim["cpu"])   & (df["diff"] <= 720)])
    c_ram    = len(df[(df["ram"] > lim["ram"])   & (df["diff"] <= 720)])
    c_disco  = len(df[(df["disco_c"] > lim["disco"]) & (df["diff"] <= 720)])

    kpis = [
        kpi_card("TOTAL INVENTARIO", len(df),    "#3b82f6", "fa-solid fa-server"),
        kpi_card("ONLINE",           ativos,      "#10b981", "fa-solid fa-circle-check"),
        kpi_card("OFFLINE",          offline,     "#64748b", "fa-solid fa-circle-xmark"),
        kpi_card("HOME OFFICE",      home,        "#0284c7", "fa-solid fa-house-laptop"),
        kpi_card("ALERTA CPU",       c_cpu,       "#ef4444", "fa-solid fa-microchip", pulse=c_cpu > 0),
        kpi_card("ALERTA RAM",       c_ram,       "#f59e0b", "fa-solid fa-memory",    pulse=c_ram > 0),
        kpi_card("ALERTA DISCO",     c_disco,     "#8b5cf6", "fa-solid fa-hard-drive"),
        kpi_card("DEPARTAMENTOS",    df["departamento"].nunique() if "departamento" in df.columns else 1,
                 "#06b6d4", "fa-solid fa-sitemap"),
    ]

    # Filtro modo crise
    df_tab = df.copy()
    if modo == "CRISE":
        df_tab = df_tab[
            ((df_tab["cpu"] > lim["cpu"]) | (df_tab["ram"] > lim["ram"]) |
             (df_tab["disco_c"] > lim["disco"])) & (df_tab["diff"] <= 720)
        ]

    # Montar display da tabela
    registros = []
    style_cond = [
        {"if": {"filter_query": '{STATUS} = "Offline"'}, "color": "#475569", "fontStyle": "italic"},
    ]
    for i, row in df_tab.iterrows():
        diff = row["diff"]
        if diff > 720:
            status = "Offline"
            rec = {"SAUDE": "0%", "STATUS": status, "HOSTNAME": row["hostname"],
                   "CPU": "-", "RAM": "-", "DISCO C": "-", "REDE": row.get("rede", "-"),
                   "LOCALIDADE": row.get("localidade", "-"), "UPTIME": "-",
                   "DEPTO": row.get("departamento", "Geral"),
                   "REPORT": fmt_ts(row["ultima_atualizacao"])}
        else:
            t = trends.get(row["hostname"], {})
            cpuv = row["cpu"]; ramv = row["ram"]
            cpu_tr = _trend_str(t.get("cpu", []))
            ram_tr = _trend_str(t.get("ram", []))
            status = "Online" if diff <= 120 else "Alerta"
            h_score = calcular_health_score({
                "diff": diff, "cpu": cpuv, "ram": ramv,
                "disco_c": row.get("disco_c", 0),
                "defender_ativo": row.get("defender_ativo"),
                "updates_pendentes": row.get("updates_pendentes"),
            })
            rec = {
                "SAUDE":     f"{int(h_score)}%",
                "STATUS":    status,
                "HOSTNAME":  row["hostname"],
                "CPU":       f"{cpuv}%{cpu_tr}",
                "RAM":       f"{ramv}% ({row['ram_total']}GB){ram_tr}",
                "DISCO C":   f"{row['disco_c']}% ({row['disco_c_total']}GB)",
                "REDE":      row.get("rede", "-"),
                "LOCALIDADE": row.get("localidade", "-"),
                "UPTIME":    row.get("uptime", "-"),
                "DEPTO":     row.get("departamento", "Geral"),
                "REPORT":    fmt_ts(row["ultima_atualizacao"]),
            }
            if cpuv > lim["cpu"]:
                style_cond.append({"if": {"row_index": i, "column_id": "CPU"},
                                   "backgroundColor": "rgba(239,68,68,.12)", "color": "#ef4444"})
            if ramv > lim["ram"]:
                style_cond.append({"if": {"row_index": i, "column_id": "RAM"},
                                   "backgroundColor": "rgba(245,158,11,.12)", "color": "#fbbf24"})
        registros.append(rec)

    # Health score coloring
    style_cond += [
        {"if": {"filter_query": '{SAUDE} = "0%"',  "column_id": "SAUDE"}, "color": "#475569"},
        {"if": {"filter_query": '{SAUDE} < "60%"', "column_id": "SAUDE"}, "color": "#ef4444"},
        {"if": {"filter_query": '{SAUDE} < "80%"', "column_id": "SAUDE"}, "color": "#f59e0b"},
        {"if": {"filter_query": '{SAUDE} >= "80%"',"column_id": "SAUDE"}, "color": "#10b981"},
    ]

    col_widths = {
        "SAUDE": "62px", "STATUS": "80px", "HOSTNAME": "140px", "CPU": "100px",
        "RAM": "140px", "DISCO C": "130px", "REDE": "180px",
        "LOCALIDADE": "110px", "UPTIME": "90px", "DEPTO": "90px", "REPORT": "130px",
    }
    tabela = dash_table.DataTable(
        data=registros,
        columns=[{"name": c, "id": c} for c in registros[0].keys()] if registros else [],
        filter_action="native", sort_action="native",
        export_format="xlsx", export_headers="display",
        page_size=20,
        style_table={"overflowX": "auto", "width": "100%", "minWidth": "100%"},
        style_cell={"textAlign": "center", "padding": "9px 10px", "fontSize": "11px",
                    "backgroundColor": "#090d16", "color": "#94a3b8",
                    "border": "1px solid rgba(6,182,212,.05)",
                    "whiteSpace": "nowrap", "overflow": "hidden",
                    "textOverflow": "ellipsis", "maxWidth": "200px"},
        style_header={"backgroundColor": "#020617", "color": "#22d3ee",
                      "fontWeight": "bold", "border": "1px solid rgba(6,182,212,.15)",
                      "whiteSpace": "nowrap"},
        style_cell_conditional=[
            {"if": {"column_id": col}, "minWidth": w, "width": w, "maxWidth": w}
            for col, w in col_widths.items()
        ],
        style_data_conditional=style_cond,
    )

    # Gráfico pizza — localidade
    loc_counts = df[df["diff"] <= 720]["localidade"].value_counts().reset_index()
    loc_counts.columns = ["localidade", "total"]
    pizza = px.pie(loc_counts, names="localidade", values="total",
                   color_discrete_sequence=["#06b6d4", "#a855f7", "#64748b"])
    _estilo_grafico(pizza)
    pizza.update_traces(textfont_size=11)

    # Gráfico top 5 CPU
    top5 = df[df["diff"] <= 720].nlargest(5, "cpu")[["hostname", "cpu"]].copy()
    top5["cor"] = top5["cpu"].apply(lambda x: "#ef4444" if x > lim["cpu"] else "#06b6d4")
    bar = go.Figure(go.Bar(x=top5["cpu"], y=top5["hostname"], orientation="h",
                           marker_color=top5["cor"].tolist(), text=top5["cpu"].apply(lambda x: f"{x}%"),
                           textposition="inside"))
    _estilo_grafico(bar)
    bar.update_layout(xaxis={"range": [0, 105]}, yaxis={"autorange": "reversed"})

    opts = [{"label": h, "value": h} for h in df["hostname"].unique()]
    ts_txt = f"Atualizado: {datetime.now().strftime('%H:%M:%S')}"
    return kpis, tabela, opts, pizza, bar, ts_txt


# ── Callback: gráfico histórico individual ────────────────────────────────────
@callback(
    Output("grafico-historico-ov", "figure"),
    [Input("dropdown-host", "value"),
     Input("dropdown-metrica", "value"),
     Input("ov-interval", "n_intervals")],
    State("session-store", "data"),
)
def grafico_individual(hostname, metrica, n, session):
    if not session or not session.get("authenticated") or not hostname:
        fig = px.line(title="Selecione um hostname para visualizar a tendencia")
        _estilo_grafico(fig)
        return fig

    cols_map = {"cpu_ram": ["cpu", "ram"], "disco": ["disco_c", "disco_d"]}
    ycols = cols_map.get(metrica, ["cpu", "ram"])
    null_filter = "AND (disco_c IS NOT NULL OR disco_d IS NOT NULL)" if metrica == "disco" else ""

    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute(f"""
                    SELECT timestamp, cpu, ram, disco_c, disco_d
                    FROM historico_v6
                    WHERE hostname = %s {null_filter}
                    ORDER BY id DESC LIMIT 120
                """, (hostname,))
                rows = c.fetchall()
                cnames = [d[0] for d in c.description]
    except Exception as e:
        log.error("Erro historico [%s]: %s", hostname, e)
        fig = px.line(title="Erro ao carregar historico")
        _estilo_grafico(fig)
        return fig

    if not rows:
        fig = px.line(title="Sem dados historicos para este hostname")
        _estilo_grafico(fig)
        return fig

    df = pd.DataFrame(rows, columns=cnames).iloc[::-1]
    cores = {"cpu": "#06b6d4", "ram": "#a855f7", "disco_c": "#10b981", "disco_d": "#f59e0b"}
    fig = px.line(df, x="timestamp", y=ycols,
                  title=f"TENDENCIA — {hostname}",
                  color_discrete_map=cores,
                  markers=True)
    _estilo_grafico(fig)
    fig.update_layout(yaxis_range=[0, 105])
    return fig


def _estilo_grafico(fig) -> None:
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font_color="#94a3b8", title_font_color="#22d3ee",
        margin=dict(l=10, r=10, t=40, b=10),
        legend=dict(font=dict(color="#94a3b8")),
        xaxis=dict(gridcolor="rgba(6,182,212,.06)", showgrid=True),
        yaxis=dict(gridcolor="rgba(6,182,212,.06)", showgrid=True),
        autosize=True,
    )


def _trend_str(vals: list) -> str:
    if len(vals) < 2:
        return ""
    diff = vals[0] - vals[1]
    if abs(diff) < 1:
        return ""
    return f" ↑{diff:.1f}" if diff > 0 else f" ↓{abs(diff):.1f}"
