import dash
import plotly.graph_objects as go
from dash import Input, Output, State, callback, dcc, html

from dashboard.components import fmt_ts, page_header
from database import get_conn

dash.register_page(__name__, path="/processos", name="Processos",
                   title="Neon — Processos")

_CORES_CPU = [[0, "#1e3a5f"], [0.3, "#3b82f6"], [0.6, "#f59e0b"], [1, "#ef4444"]]
_CORES_RAM = [[0, "#1e3a5f"], [0.4, "#10b981"], [0.8, "#f59e0b"], [1, "#ef4444"]]


def layout():
    return html.Div(className="page-content", children=[
        dcc.Interval(id="proc-interval", interval=30_000, n_intervals=0),
        page_header("Processos", "Consumo de CPU e memória por processo em tempo real",
                    "fa-solid fa-microchip"),

        # ── Seletor de máquina ────────────────────────────────────────────────
        html.Div(style={"marginBottom": "1.25rem", "display": "flex",
                        "alignItems": "center", "gap": ".75rem", "flexWrap": "wrap"}, children=[
            html.Label("Máquina:", style={"color": "#94a3b8", "fontSize": ".7rem",
                                          "fontWeight": "700", "letterSpacing": ".08em",
                                          "whiteSpace": "nowrap"}),
            dcc.Dropdown(id="proc-host-select",
                         placeholder="Selecione uma máquina...",
                         style={"minWidth": "280px", "flex": "0 0 auto"}),
            html.Div(id="proc-info-ts",
                     style={"fontSize": ".65rem", "color": "#475569", "letterSpacing": ".06em"}),
        ]),

        # ── KPI cards ─────────────────────────────────────────────────────────
        html.Div(id="proc-top-cards", className="kpi-grid",
                 style={"marginBottom": "1.25rem"}),

        # ── Análise inteligente ───────────────────────────────────────────────
        html.Div(id="proc-inteligencia", style={"marginBottom": "1.25rem"}),

        # ── Gráficos de consumo ───────────────────────────────────────────────
        html.Div(className="grid-2", style={"marginBottom": "1.25rem"}, children=[
            html.Div(className="panel neon-cyan", children=[
                html.Div("TOP 15 — CPU % (maior → menor)", className="section-title"),
                dcc.Graph(id="proc-cpu-chart", config={"displayModeBar": False},
                          responsive=True),
            ]),
            html.Div(className="panel neon-cyan", children=[
                html.Div("TOP 15 — Memória MB (maior → menor)", className="section-title"),
                dcc.Graph(id="proc-ram-chart", config={"displayModeBar": False},
                          responsive=True),
            ]),
        ]),

        # ── Tendência histórica ───────────────────────────────────────────────
        html.Div(className="panel neon-cyan", style={"marginBottom": "1.25rem"}, children=[
            html.Div("Tendência Histórica — Top 5 por CPU (últimas 24h)", className="section-title"),
            dcc.Graph(id="proc-trend-chart", config={"displayModeBar": False},
                      responsive=True),
        ]),

        # ── Tabela completa ───────────────────────────────────────────────────
        html.Div(className="panel neon-cyan", children=[
            html.Div("Detalhamento Completo — ordenado por CPU", className="section-title"),
            html.Div(id="proc-tabela"),
        ]),
    ])


# ── Popula dropdown com máquinas do maquinas_v6 ───────────────────────────────
@callback(
    Output("proc-host-select", "options"),
    Output("proc-host-select", "value"),
    Input("proc-interval", "n_intervals"),
    State("session-store", "data"),
    State("proc-host-select", "value"),
)
def carregar_hosts(_, session, valor_atual):
    if not (session or {}).get("authenticated"):
        return [], None
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("""
                    SELECT hostname,
                           EXTRACT(EPOCH FROM (NOW() - ultima_atualizacao)) AS diff
                    FROM maquinas_v6
                    ORDER BY hostname
                """)
                rows = c.fetchall()
        opts = []
        hosts = []
        for host, diff in rows:
            diff = float(diff or 9999)
            icone = "🟢" if diff <= 120 else ("🟡" if diff <= 720 else "🔴")
            opts.append({"label": f"{icone} {host}", "value": host})
            hosts.append(host)
        valor = valor_atual if valor_atual in hosts else (hosts[0] if hosts else None)
        return opts, valor
    except Exception:
        return [], None


# ── Callback principal ────────────────────────────────────────────────────────
@callback(
    Output("proc-top-cards",   "children"),
    Output("proc-inteligencia","children"),
    Output("proc-cpu-chart",   "figure"),
    Output("proc-ram-chart",   "figure"),
    Output("proc-trend-chart", "figure"),
    Output("proc-tabela",      "children"),
    Output("proc-info-ts",     "children"),
    Input("proc-interval",     "n_intervals"),
    Input("proc-host-select",  "value"),
    State("session-store",     "data"),
)
def atualizar_processos(_, hostname, session):
    vazio = _fig_vazio()
    if not (session or {}).get("authenticated") or not hostname:
        return [], None, vazio, vazio, vazio, \
               html.P("Selecione uma máquina.",
                      style={"color": "#64748b", "padding": "1rem"}), ""

    # ── Snapshot atual ────────────────────────────────────────────────────────
    snapshot, ts_ultimo = _buscar_snapshot(hostname)
    if not snapshot:
        aviso = _aviso_sem_dados(hostname)
        return [], aviso, vazio, vazio, vazio, aviso, ""

    nomes = [r[0] for r in snapshot]
    rams  = [int(r[1] or 0)   for r in snapshot]
    pids  = [r[2]              for r in snapshot]
    cpus  = [float(r[3] or 0) for r in snapshot]

    # ── Análise histórica (24h) ───────────────────────────────────────────────
    historico, trend_rows = _buscar_historico(hostname)
    hist_map = {r[0]: r for r in historico}   # nome → (nome,avg_cpu,max_cpu,avg_ram,max_ram,n)

    # ── KPI cards ─────────────────────────────────────────────────────────────
    idx_cpu = cpus.index(max(cpus)) if cpus else 0
    idx_ram = rams.index(max(rams)) if rams else 0
    cards = [
        _kpi("fa-solid fa-fire",         "MAIOR CPU",    nomes[idx_cpu],
             f"{cpus[idx_cpu]:.1f}%",    "#ef4444" if cpus[idx_cpu] > 20 else "#f59e0b"),
        _kpi("fa-solid fa-memory",        "MAIOR RAM",    nomes[idx_ram],
             f"{rams[idx_ram]} MB",       "#f59e0b" if rams[idx_ram] > 500 else "#3b82f6"),
        _kpi("fa-solid fa-list",          "PROCESSOS",    "monitorados",
             str(len(snapshot)),          "#10b981"),
        _kpi("fa-solid fa-chart-simple",  "CPU TOTAL",    "soma dos processos",
             f"{sum(cpus):.1f}%",         "#a855f7"),
    ]

    # ── Inteligência ──────────────────────────────────────────────────────────
    alertas = _detectar_alertas(nomes, cpus, rams, hist_map, historico)
    intelig = _render_inteligencia(alertas, historico)

    # ── Gráfico CPU (top 15, maior→menor, ou seja sort asc para plotly) ───────
    cpu_top = sorted(zip(cpus, nomes), key=lambda x: x[0])[-15:]  # 15 maiores
    nomes_cpu = [_trunc(n, 32) for _, n in cpu_top]
    vals_cpu  = [c for c, _ in cpu_top]
    n_cpu     = len(cpu_top)

    fig_cpu = go.Figure(go.Bar(
        x=vals_cpu, y=nomes_cpu, orientation="h",
        marker=dict(color=vals_cpu, colorscale=_CORES_CPU,
                    cmin=0, cmax=max(vals_cpu) or 1, showscale=False),
        text=[f"  {v:.1f}%" for v in vals_cpu],
        textposition="outside",
        cliponaxis=False,
        hovertemplate="<b>%{y}</b><br>CPU: %{x:.2f}%<extra></extra>",
    ))
    fig_cpu.update_layout(**_layout_bar("CPU (%)", max(vals_cpu) * 1.4 or 1, n_cpu))

    # ── Gráfico RAM (top 15 maiores) ──────────────────────────────────────────
    ram_top = sorted(zip(rams, nomes), key=lambda x: x[0])[-15:]
    nomes_ram = [_trunc(n, 32) for _, n in ram_top]
    vals_ram  = [r for r, _ in ram_top]
    n_ram     = len(ram_top)

    fig_ram = go.Figure(go.Bar(
        x=vals_ram, y=nomes_ram, orientation="h",
        marker=dict(color=vals_ram, colorscale=_CORES_RAM,
                    cmin=0, cmax=max(vals_ram) or 1, showscale=False),
        text=[f"  {v} MB" for v in vals_ram],
        textposition="outside",
        cliponaxis=False,
        hovertemplate="<b>%{y}</b><br>RAM: %{x} MB<extra></extra>",
    ))
    fig_ram.update_layout(**_layout_bar("RAM (MB)", max(vals_ram) * 1.35 or 100, n_ram))

    # ── Gráfico tendência histórica ───────────────────────────────────────────
    fig_trend = _render_trend(trend_rows, historico)

    # ── Tabela completa ───────────────────────────────────────────────────────
    tabela = _render_tabela(nomes, rams, pids, cpus, hist_map)

    ts_txt = f"Snapshot: {fmt_ts(ts_ultimo)}" if ts_ultimo else ""
    return cards, intelig, fig_cpu, fig_ram, fig_trend, tabela, ts_txt


# ── Consultas ao banco ────────────────────────────────────────────────────────

def _buscar_snapshot(hostname: str):
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("""
                    SELECT nome, ram_mb, pid, COALESCE(cpu_pct, 0), timestamp
                    FROM processos_top
                    WHERE hostname = %s
                      AND timestamp = (
                          SELECT MAX(timestamp) FROM processos_top WHERE hostname = %s
                      )
                    ORDER BY COALESCE(cpu_pct, 0) DESC NULLS LAST, ram_mb DESC
                    LIMIT 15
                """, (hostname, hostname))
                raw = c.fetchall()
        if not raw:
            return [], None
        return [(r[0], r[1], r[2], r[3]) for r in raw], raw[0][4]
    except Exception:
        return [], None


def _buscar_historico(hostname: str):
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                # Médias por processo nas últimas 24h
                c.execute("""
                    SELECT nome,
                           ROUND(AVG(COALESCE(cpu_pct,0))::numeric, 2) AS avg_cpu,
                           ROUND(MAX(COALESCE(cpu_pct,0))::numeric, 2) AS max_cpu,
                           ROUND(AVG(ram_mb)::numeric,              0) AS avg_ram,
                           MAX(ram_mb)                                  AS max_ram,
                           COUNT(*)                                     AS snapshots
                    FROM processos_top
                    WHERE hostname = %s
                      AND timestamp > NOW() - INTERVAL '24 hours'
                    GROUP BY nome
                    HAVING COUNT(*) >= 2
                    ORDER BY avg_cpu DESC NULLS LAST
                    LIMIT 20
                """, (hostname,))
                hist = [
                    (r[0], float(r[1] or 0), float(r[2] or 0),
                     float(r[3] or 0), int(r[4] or 0), int(r[5]))
                    for r in c.fetchall()
                ]

                # Série temporal dos top 5 por cpu médio para tendência
                top5 = [r[0] for r in hist[:5]]
                trend_rows = []
                if top5:
                    ph = ",".join(["%s"] * len(top5))
                    c.execute(f"""
                        SELECT nome, timestamp, COALESCE(cpu_pct, 0) AS cpu_pct
                        FROM processos_top
                        WHERE hostname = %s
                          AND nome IN ({ph})
                          AND timestamp > NOW() - INTERVAL '24 hours'
                        ORDER BY timestamp
                    """, [hostname] + top5)
                    trend_rows = c.fetchall()
        return hist, trend_rows
    except Exception:
        return [], []


# ── Inteligência ───────────────────────────────────────────────────────────────

def _detectar_alertas(nomes, cpus, rams, hist_map, historico):
    alertas = []
    hist_nomes = {r[0] for r in historico}

    for nome, cpu, ram in zip(nomes, cpus, rams):
        h = hist_map.get(nome)

        # Spike de CPU: atual é 3x maior que a média histórica
        if h and h[1] and h[1] > 0 and cpu > h[1] * 3 and cpu > 5:
            alertas.append({
                "tipo": "spike_cpu", "nome": nome,
                "msg": f"CPU atual {cpu:.1f}% vs média histórica {h[1]:.1f}% (+{cpu/h[1]:.0f}x)",
                "cor": "#ef4444",
            })

        # Processo pesado persistente: média > 15% CPU
        if h and h[1] and h[1] > 15:
            alertas.append({
                "tipo": "pesado_cpu", "nome": nome,
                "msg": f"Média de {h[1]:.1f}% CPU nas últimas 24h (pico {h[2]:.1f}%)",
                "cor": "#f59e0b",
            })

        # RAM persistentemente alta: média > 800 MB
        if h and h[3] and h[3] > 800:
            alertas.append({
                "tipo": "pesado_ram", "nome": nome,
                "msg": f"Média de {int(h[3])} MB RAM nas últimas 24h (pico {h[4]} MB)",
                "cor": "#f59e0b",
            })

        # Processo novo: não estava no histórico de 24h
        if nome not in hist_nomes and (cpu > 2 or ram > 200):
            alertas.append({
                "tipo": "novo", "nome": nome,
                "msg": f"Processo novo detectado — {cpu:.1f}% CPU / {ram} MB RAM",
                "cor": "#a855f7",
            })

    return alertas[:8]  # máximo 8 alertas


def _render_inteligencia(alertas, historico):
    if not alertas and not historico:
        return None

    icones = {
        "spike_cpu":  ("fa-solid fa-bolt",              "#ef4444"),
        "pesado_cpu": ("fa-solid fa-fire-flame-curved", "#f59e0b"),
        "pesado_ram": ("fa-solid fa-memory",             "#f59e0b"),
        "novo":       ("fa-solid fa-circle-exclamation", "#a855f7"),
    }

    blocos_alerta = []
    for a in alertas:
        ico, cor = icones.get(a["tipo"], ("fa-solid fa-triangle-exclamation", "#94a3b8"))
        blocos_alerta.append(
            html.Div(style={
                "display": "flex", "alignItems": "flex-start", "gap": ".6rem",
                "padding": ".5rem .75rem", "borderRadius": ".375rem",
                "background": f"rgba({_hex_to_rgb(cor)},0.08)",
                "border": f"1px solid rgba({_hex_to_rgb(cor)},0.25)",
                "marginBottom": ".4rem",
            }, children=[
                html.I(className=ico, style={"color": cor, "marginTop": ".15rem",
                                              "fontSize": ".9rem", "flexShrink": "0"}),
                html.Div([
                    html.Span(a["nome"],
                              style={"color": cor, "fontWeight": "700",
                                     "fontSize": ".75rem", "fontFamily": "monospace"}),
                    html.Span(f" — {a['msg']}",
                              style={"color": "#94a3b8", "fontSize": ".7rem"}),
                ]),
            ])
        )

    # Top 5 mais pesados historicamente
    top5_hist = []
    for r in historico[:5]:
        nome, avg_cpu, max_cpu, avg_ram, max_ram, n = r
        top5_hist.append(html.Tr([
            html.Td(_trunc(nome, 28),
                    style={"padding": ".3rem .5rem", "fontFamily": "monospace",
                           "fontSize": ".7rem", "color": "#e2e8f0"}),
            html.Td(f"{avg_cpu:.1f}%",
                    style={"padding": ".3rem .5rem", "textAlign": "right",
                           "color": "#ef4444" if avg_cpu > 15 else "#f59e0b" if avg_cpu > 5 else "#10b981",
                           "fontWeight": "700", "fontSize": ".7rem"}),
            html.Td(f"{int(avg_ram)} MB",
                    style={"padding": ".3rem .5rem", "textAlign": "right",
                           "color": "#94a3b8", "fontSize": ".7rem"}),
            html.Td(str(n),
                    style={"padding": ".3rem .5rem", "textAlign": "center",
                           "color": "#475569", "fontSize": ".65rem"}),
        ]))

    return html.Div(className="grid-2", children=[
        # Alertas
        html.Div(className="panel neon-cyan", children=[
            html.Div("Alertas Detectados", className="section-title"),
            html.Div(blocos_alerta) if blocos_alerta else
            html.Div([
                html.I(className="fa-solid fa-circle-check",
                       style={"color": "#10b981", "marginRight": ".5rem"}),
                html.Span("Nenhuma anomalia detectada.",
                          style={"color": "#64748b", "fontSize": ".75rem"}),
            ], style={"padding": ".5rem 0"}),
        ]),
        # Histórico top processos
        html.Div(className="panel neon-cyan", children=[
            html.Div("Top Processos 24h (média CPU)", className="section-title"),
            html.Table(style={"width": "100%", "borderCollapse": "collapse"}, children=[
                html.Thead(html.Tr([
                    html.Th("Processo", style=_th()),
                    html.Th("CPU méd.", style=_th("right")),
                    html.Th("RAM méd.", style=_th("right")),
                    html.Th("Snapshots", style=_th("center")),
                ])),
                html.Tbody(top5_hist),
            ]) if top5_hist else
            html.P("Histórico ainda insuficiente.",
                   style={"color": "#475569", "fontSize": ".7rem", "padding": ".5rem 0"}),
        ]),
    ])


def _render_trend(trend_rows, historico):
    if not trend_rows:
        fig = _fig_vazio("Histórico de 24h disponível após mais ciclos de coleta")
        fig.update_layout(height=220)
        return fig

    from collections import defaultdict
    series = defaultdict(lambda: {"x": [], "y": []})
    for nome, ts, cpu in trend_rows:
        series[nome]["x"].append(ts)
        series[nome]["y"].append(float(cpu or 0))

    cores = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#a855f7"]
    fig = go.Figure()
    for i, (nome, data) in enumerate(series.items()):
        fig.add_trace(go.Scatter(
            x=data["x"], y=data["y"],
            mode="lines",
            name=_trunc(nome, 22),
            line=dict(color=cores[i % len(cores)], width=2),
            hovertemplate=f"<b>{nome}</b><br>%{{x}}<br>CPU: %{{y:.1f}}%<extra></extra>",
        ))

    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e2e8f0", size=11),
        margin=dict(l=40, r=20, t=10, b=40),
        xaxis=dict(gridcolor="#1e293b", color="#94a3b8", showgrid=True),
        yaxis=dict(gridcolor="#1e293b", color="#94a3b8", title="CPU (%)",
                   rangemode="tozero"),
        legend=dict(orientation="h", yanchor="bottom", y=1.02,
                    xanchor="left", x=0, font=dict(size=10)),
        height=240,
        hovermode="x unified",
        hoverlabel=dict(
            bgcolor="#0f172a",
            bordercolor="#334155",
            font=dict(color="#e2e8f0", size=11, family="monospace"),
        ),
    )
    return fig


def _render_tabela(nomes, rams, pids, cpus, hist_map):
    def cpu_cor(v):
        if v >= 50: return "#ef4444"
        if v >= 20: return "#f59e0b"
        if v >= 5:  return "#3b82f6"
        return "#10b981"

    linhas = sorted(zip(nomes, rams, pids, cpus), key=lambda x: (x[3], x[1]), reverse=True)
    max_ram = max((r for _, r, _, _ in linhas), default=1) or 1

    def delta_tag(nome, cpu, ram):
        h = hist_map.get(nome)
        if not h:
            return html.Span("novo", style={"fontSize": ".6rem", "color": "#a855f7",
                                             "background": "rgba(168,85,247,.12)",
                                             "padding": ".1rem .35rem", "borderRadius": ".2rem"})
        if h[1] and h[1] > 0 and cpu > h[1] * 3 and cpu > 3:
            return html.Span("↑ spike", style={"fontSize": ".6rem", "color": "#ef4444",
                                                "background": "rgba(239,68,68,.12)",
                                                "padding": ".1rem .35rem", "borderRadius": ".2rem"})
        return None

    rows_html = []
    for nome, ram, pid, cpu in linhas:
        tag = delta_tag(nome, cpu, ram)
        rows_html.append(html.Tr(
            style={"borderBottom": "1px solid #1e293b",
                   "background": "rgba(239,68,68,.04)" if cpu >= 50 else "transparent"},
            children=[
                html.Td([
                    html.Span(_trunc(nome, 34),
                              style={"fontFamily": "monospace", "fontSize": ".75rem",
                                     "color": "#e2e8f0"}),
                    html.Span(" "),
                    tag,
                ], style={"padding": ".4rem .5rem"}),
                html.Td(str(pid),
                        style={"padding": ".4rem .5rem", "textAlign": "center",
                               "color": "#64748b", "fontSize": ".7rem"}),
                html.Td(f"{cpu:.1f}%",
                        style={"padding": ".4rem .5rem", "textAlign": "right",
                               "fontWeight": "700", "color": cpu_cor(cpu),
                               "fontSize": ".8rem"}),
                html.Td(f"{ram} MB",
                        style={"padding": ".4rem .5rem", "textAlign": "right",
                               "color": "#94a3b8", "fontSize": ".75rem"}),
                html.Td(
                    html.Div(style={
                        "height": "6px", "borderRadius": "3px",
                        "background": "#3b82f6",
                        "width": f"{min(100, ram / max_ram * 100):.0f}%",
                        "minWidth": "2px",
                    }),
                    style={"padding": ".4rem .5rem", "minWidth": "100px"},
                ),
            ]
        ))

    return html.Table(
        style={"width": "100%", "borderCollapse": "collapse"},
        children=[
            html.Thead(html.Tr([
                html.Th("Processo",  style=_th()),
                html.Th("PID",       style=_th("center")),
                html.Th("CPU %",     style=_th("right")),
                html.Th("RAM (MB)",  style=_th("right")),
                html.Th("Barra RAM", style=_th()),
            ])),
            html.Tbody(rows_html),
        ],
    )


def _aviso_sem_dados(hostname: str):
    viloes = ""
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("SELECT viloes FROM maquinas_v6 WHERE hostname=%s", (hostname,))
                row = c.fetchone()
        if row:
            viloes = row[0] or ""
    except Exception:
        pass
    return html.Div(style={"padding": "1rem"}, children=[
        html.P([
            html.I(className="fa-solid fa-triangle-exclamation",
                   style={"color": "#f59e0b", "marginRight": ".4rem"}),
            f"Dados de processos ainda não disponíveis para {hostname}.",
        ], style={"color": "#94a3b8", "fontSize": ".8rem", "marginBottom": ".5rem"}),
        html.P("Atualize o agente TelemetriaAgent.exe para coletar dados detalhados.",
               style={"color": "#475569", "fontSize": ".7rem"}),
        html.Div([
            html.Span("Processos reportados: ", style={"color": "#64748b", "fontSize": ".7rem"}),
            html.Span(viloes, style={"color": "#94a3b8", "fontFamily": "monospace",
                                     "fontSize": ".75rem"}),
        ]) if viloes and viloes not in ("Normal", "") else None,
    ])


# ── Helpers visuais ───────────────────────────────────────────────────────────

def _kpi(icone, titulo, subtitulo, valor, cor):
    return html.Div(className="kpi-card neon-cyan", children=[
        html.Div([
            html.Span(titulo, className="kpi-label"),
            html.Span(subtitulo, style={"display": "block", "fontSize": ".55rem",
                                         "color": "#475569", "marginTop": ".1rem",
                                         "letterSpacing": ".06em"}),
            html.Span(valor, className="kpi-value", style={"color": cor}),
        ]),
        html.Div(className="kpi-icon",
                 children=[html.I(className=icone, style={"color": cor})]),
    ])


def _layout_bar(titulo_eixo: str, x_max: float, n: int) -> dict:
    height = max(220, n * 34 + 70)
    return dict(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e2e8f0", size=11),
        margin=dict(l=220, r=90, t=10, b=40),
        xaxis=dict(title=titulo_eixo, gridcolor="#1e293b",
                   range=[0, x_max], color="#94a3b8", zeroline=False),
        yaxis=dict(gridcolor="rgba(0,0,0,0)", color="#94a3b8", automargin=True),
        height=height,
    )


def _fig_vazio(msg: str = "Sem dados") -> go.Figure:
    fig = go.Figure()
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        annotations=[dict(text=msg, xref="paper", yref="paper",
                          x=0.5, y=0.5, showarrow=False,
                          font=dict(size=13, color="#475569"))],
        height=300,
        xaxis=dict(visible=False), yaxis=dict(visible=False),
    )
    return fig


def _trunc(s: str, n: int) -> str:
    return s if len(s) <= n else s[:n - 1] + "…"


def _th(align: str = "left") -> dict:
    return {"padding": ".35rem .5rem", "fontSize": ".6rem", "fontWeight": "800",
            "color": "#22d3ee", "letterSpacing": ".08em", "textTransform": "uppercase",
            "textAlign": align, "borderBottom": "1px solid #1e3a5f"}


def _hex_to_rgb(hex_color: str) -> str:
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"{r},{g},{b}"
