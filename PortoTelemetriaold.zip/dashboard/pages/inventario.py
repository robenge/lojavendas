import dash
import pandas as pd
from dash import Input, Output, State, callback, ctx, dash_table, dcc, html
from datetime import datetime

from dashboard.components import page_header, kpi_card
from database import get_conn

dash.register_page(__name__, path="/inventario", name="Inventario", title="Neon — Inventario")


def layout(**kwargs):
    return html.Div(className="page-content", children=[
        page_header("INVENTARIO DE HARDWARE", "Especificacoes e estado do parque",
                    "fa-solid fa-server"),

        dcc.Store(id="inv-store-host"),
        dcc.Interval(id="inv-interval", interval=30_000, n_intervals=0),

        html.Div(id="inv-kpis", className="kpi-grid", style={"marginBottom": "1rem"}),

        # Filtros
        html.Div(className="panel neon-cyan", style={"marginBottom": "1rem"}, children=[
            html.Div(className="grid-2", children=[
                html.Div([
                    html.Label("FILTRAR POR DEPARTAMENTO", className="login-label"),
                    dcc.Dropdown(id="inv-depto", placeholder="Todos...",
                                 style={"color": "#1e293b"}),
                ]),
                html.Div([
                    html.Label("FILTRAR POR LOCALIDADE", className="login-label"),
                    dcc.Dropdown(id="inv-localidade", options=[],
                                 placeholder="Todas...", style={"color": "#1e293b"}),
                ]),
            ]),
        ]),

        # Tabela principal (DataTable com ID fixo para suportar selecao de linha)
        html.Div(className="panel neon-cyan", style={"marginBottom": "1rem"}, children=[
            html.Div(style={"display": "flex", "justifyContent": "space-between",
                            "marginBottom": ".5rem", "alignItems": "center"}, children=[
                html.P("CATALOGO DE HARDWARE", className="section-title",
                       style={"marginBottom": 0}),
                html.Span("Selecione uma linha para editar os dados do dispositivo",
                          style={"fontSize": ".65rem", "color": "#475569"}),
            ]),
            dash_table.DataTable(
                id="inv-tabela-dt",
                data=[], columns=[],
                row_selectable="single",
                selected_rows=[],
                filter_action="native", sort_action="native",
                export_format="xlsx", export_headers="display",
                page_size=25,
                style_table={"overflowX": "auto", "width": "100%"},
                style_cell={"textAlign": "left", "padding": "9px 12px", "fontSize": "11px",
                            "backgroundColor": "#090d16", "color": "#94a3b8",
                            "border": "1px solid rgba(6,182,212,.05)",
                            "whiteSpace": "nowrap", "overflow": "hidden",
                            "textOverflow": "ellipsis", "maxWidth": "200px"},
                style_header={"backgroundColor": "#020617", "color": "#22d3ee",
                              "fontWeight": "bold", "border": "1px solid rgba(6,182,212,.15)"},
                style_data_conditional=[
                    {"if": {"filter_query": '{STATUS} = "Online"'},  "color": "#34d399"},
                    {"if": {"filter_query": '{STATUS} = "Alerta"'},  "color": "#fbbf24"},
                    {"if": {"filter_query": '{STATUS} = "Offline"'}, "color": "#475569",
                     "fontStyle": "italic"},
                ],
            ),
        ]),

        # Painel de edicao — visivel somente ao selecionar uma linha
        html.Div(id="inv-edit-panel", className="panel neon-purple",
                 style={"display": "none"}, children=[
            html.Div(style={"display": "flex", "justifyContent": "space-between",
                            "marginBottom": ".75rem", "alignItems": "center"}, children=[
                html.Div(style={"display": "flex", "alignItems": "center", "gap": ".75rem"}, children=[
                    html.I(className="fa-solid fa-pen-to-square",
                           style={"color": "#a78bfa", "fontSize": ".9rem"}),
                    html.P("EDITAR DISPOSITIVO", className="section-title",
                           style={"marginBottom": 0}),
                ]),
                html.Span(id="inv-edit-hostname",
                          style={"color": "#a78bfa", "fontWeight": "800",
                                 "fontSize": ".9rem", "letterSpacing": "0.05em"}),
            ]),

            html.Div(className="grid-3", children=[
                html.Div([
                    html.Label("LOCALIDADE", className="login-label"),
                    dcc.Input(id="inv-edit-localidade", type="text",
                              placeholder="Ex: Escritorio, Home Office, Filial SP...",
                              className="login-input", style={"marginBottom": 0}),
                ]),
                html.Div([
                    html.Label("DEPARTAMENTO", className="login-label"),
                    dcc.Input(id="inv-edit-depto", type="text",
                              placeholder="Ex: TI, Financeiro, RH...",
                              className="login-input", style={"marginBottom": 0}),
                ]),
                html.Div([
                    html.Label("ATIVO FISICO (AF)", className="login-label"),
                    dcc.Input(id="inv-edit-af", type="text",
                              placeholder="Ex: AF-00123",
                              className="login-input", style={"marginBottom": 0}),
                ]),
            ]),

            html.Div(className="grid-3", style={"marginTop": ".75rem"}, children=[
                html.Div([
                    html.Label("CENTRO DE CUSTO (CC)", className="login-label"),
                    dcc.Input(id="inv-edit-cc", type="text",
                              placeholder="Ex: CC-456",
                              className="login-input", style={"marginBottom": 0}),
                ]),
                html.Div(),
                html.Div(),
            ]),

            html.Div(style={"display": "flex", "gap": ".5rem", "marginTop": "1rem",
                            "alignItems": "center"}, children=[
                html.Button("SALVAR ALTERACOES", id="inv-btn-salvar", n_clicks=0,
                            className="btn-login",
                            style={"width": "auto", "padding": ".4rem 1.4rem"}),
                html.Button("REMOVER DISPOSITIVO", id="inv-btn-remover", n_clicks=0,
                            className="btn-logout", style={"fontSize": ".65rem"}),
                html.Span(id="inv-edit-feedback",
                          style={"fontSize": ".7rem", "color": "#34d399",
                                 "marginLeft": ".5rem"}),
            ]),
        ]),
    ])


@callback(
    [Output("inv-kpis", "children"),
     Output("inv-tabela-dt", "data"),
     Output("inv-tabela-dt", "columns"),
     Output("inv-depto", "options"),
     Output("inv-localidade", "options")],
    [Input("inv-interval", "n_intervals"),
     Input("inv-depto", "value"),
     Input("inv-localidade", "value")],
    State("session-store", "data"),
)
def atualizar_inventario(n, depto, localidade, session):
    if not session or not session.get("authenticated"):
        return [], [], [], [], []

    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("""
                    SELECT hostname, modelo, cpu_modelo, ram_total,
                           disco_c_total, disco_d_total, os_version,
                           usuario, ip_address, departamento, localidade,
                           ativo_fisico, centro_custo, boot_time, ultima_atualizacao
                    FROM maquinas_v6
                    ORDER BY hostname
                """)
                rows = c.fetchall()
                cols = [d[0] for d in c.description]
    except Exception:
        return [], [], [], [], []

    if not rows:
        return [], [], [], [], []

    df = pd.DataFrame(rows, columns=cols)
    agora = datetime.now()
    df["diff"] = (agora - df["ultima_atualizacao"]).dt.total_seconds()

    if depto:
        df = df[df["departamento"] == depto]
    if localidade:
        df = df[df["localidade"] == localidade]

    # Opções de departamento — do df já filtrado (cascata)
    deptos_unicos = df["departamento"].dropna().unique()
    depto_opts = [{"label": d, "value": d} for d in sorted(deptos_unicos)]

    # Opções de localidade — de TODOS os dados (antes do filtro de localidade)
    df_full = pd.DataFrame(rows, columns=cols)
    locais_unicos = df_full["localidade"].dropna().unique()
    local_opts = [{"label": l, "value": l} for l in sorted(locais_unicos)]

    ram_media   = df["ram_total"].mean()   if not df.empty else 0
    disco_media = df["disco_c_total"].mean() if not df.empty else 0
    kpis = [
        kpi_card("TOTAL MAQUINAS", len(df),                          "#3b82f6", "fa-solid fa-server"),
        kpi_card("RAM MEDIA",       f"{ram_media:.0f} GB",           "#10b981", "fa-solid fa-memory"),
        kpi_card("DISCO C MEDIO",   f"{disco_media:.0f} GB",         "#a855f7", "fa-solid fa-hard-drive"),
        kpi_card("DEPARTAMENTOS",   df["departamento"].nunique(),    "#06b6d4", "fa-solid fa-sitemap"),
    ]

    df_tab = df.copy()
    df_tab["DISCO D"] = df_tab["disco_d_total"].apply(
        lambda x: f"{int(x)} GB" if x and x > 0 else "N/A")
    df_tab["DISCO C"] = df_tab["disco_c_total"].apply(lambda x: f"{int(x)} GB" if x else "-")
    df_tab["RAM"]     = df_tab["ram_total"].apply(lambda x: f"{int(x)} GB" if x else "-")
    df_tab["STATUS"]  = df_tab["diff"].apply(
        lambda d: "Online" if d <= 120 else ("Alerta" if d <= 720 else "Offline"))
    df_tab["REPORT"]  = df_tab["ultima_atualizacao"].dt.strftime("%d/%m/%Y %H:%M")
    df_tab["AF"]      = df_tab["ativo_fisico"].fillna("-")
    df_tab["CC"]      = df_tab["centro_custo"].fillna("-")
    df_tab["BOOT"]    = df_tab["boot_time"].fillna("-")

    cols_disp = {
        "STATUS": "STATUS", "hostname": "HOSTNAME", "modelo": "MODELO",
        "cpu_modelo": "PROCESSADOR", "RAM": "RAM", "DISCO C": "DISCO C",
        "DISCO D": "DISCO D", "os_version": "SISTEMA OP.", "usuario": "USUARIO",
        "ip_address": "IP", "departamento": "DEPARTAMENTO", "localidade": "LOCALIDADE",
        "AF": "AF", "CC": "CC", "BOOT": "BOOT SISTEMA", "REPORT": "ULTIMO REPORT",
    }
    df_out  = df_tab[[c for c in cols_disp if c in df_tab.columns]].rename(columns=cols_disp)
    data    = df_out.to_dict("records")
    columns = [{"name": c, "id": c} for c in df_out.columns]
    return kpis, data, columns, depto_opts, local_opts


@callback(
    [Output("inv-store-host",      "data"),
     Output("inv-edit-panel",      "style"),
     Output("inv-edit-hostname",   "children"),
     Output("inv-edit-localidade", "value"),
     Output("inv-edit-depto",      "value"),
     Output("inv-edit-af",         "value"),
     Output("inv-edit-cc",         "value")],
    [Input("inv-tabela-dt", "selected_rows")],
    [State("inv-tabela-dt", "data")],
)
def selecionar_dispositivo(selected_rows, data):
    fechado  = {"display": "none"}
    aberto   = {"display": "block"}
    if not selected_rows or not data:
        return None, fechado, "", None, "", "", ""
    hostname = data[selected_rows[0]].get("HOSTNAME", "")
    if not hostname:
        return None, fechado, "", None, "", "", ""
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("""
                    SELECT localidade, departamento, ativo_fisico, centro_custo
                    FROM maquinas_v6 WHERE hostname = %s
                """, (hostname,))
                row = c.fetchone()
    except Exception:
        row = None
    if not row:
        return hostname, aberto, hostname, None, "", "", ""
    return (
        hostname, aberto, hostname,
        row[0],        # localidade
        row[1] or "",  # departamento
        row[2] or "",  # ativo_fisico
        row[3] or "",  # centro_custo
    )


@callback(
    [Output("inv-edit-feedback",       "children"),
     Output("inv-tabela-dt", "selected_rows")],
    [Input("inv-btn-salvar",  "n_clicks"),
     Input("inv-btn-remover", "n_clicks")],
    [State("inv-store-host",       "data"),
     State("inv-edit-localidade",  "value"),
     State("inv-edit-depto",       "value"),
     State("inv-edit-af",          "value"),
     State("inv-edit-cc",          "value")],
    prevent_initial_call=True,
)
def acoes_edicao(n_salvar, n_remover, hostname, localidade, depto, af, cc):
    trigger = ctx.triggered_id
    if not hostname:
        return "Nenhum dispositivo selecionado.", dash.no_update

    if trigger == "inv-btn-salvar":
        try:
            with get_conn() as conn:
                with conn.cursor() as c:
                    c.execute("""
                        UPDATE maquinas_v6
                        SET localidade=%s, departamento=%s,
                            ativo_fisico=%s, centro_custo=%s,
                            meta_manual=TRUE
                        WHERE hostname=%s
                    """, (localidade, depto or None, af or None, cc or None, hostname))
            return f"Salvo com sucesso: {hostname}", []
        except Exception as e:
            return f"Erro ao salvar: {e}", dash.no_update

    if trigger == "inv-btn-remover":
        try:
            with get_conn() as conn:
                with conn.cursor() as c:
                    c.execute("DELETE FROM maquinas_v6  WHERE hostname=%s", (hostname,))
                    c.execute("DELETE FROM historico_v6 WHERE hostname=%s", (hostname,))
                    c.execute("DELETE FROM alertas      WHERE hostname=%s", (hostname,))
            return f"{hostname} removido do inventario.", []
        except Exception as e:
            return f"Erro ao remover: {e}", dash.no_update

    return "", dash.no_update
