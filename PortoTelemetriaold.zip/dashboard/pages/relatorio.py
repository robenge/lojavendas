import io
import dash
import pandas as pd
from dash import Input, Output, State, callback, ctx, dcc, html, dash_table
from datetime import datetime

from dashboard.components import page_header, kpi_card
from database import get_conn

dash.register_page(__name__, path="/relatorio", name="Relatorio", title="Neon — Relatorio")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _status(diff: float) -> str:
    if diff <= 120:  return "Online"
    if diff <= 720:  return "Alerta"
    return "Offline"


def _query(status_f=None, depto_f=None, local_f=None) -> pd.DataFrame:
    with get_conn() as conn:
        with conn.cursor() as c:
            c.execute("""
                SELECT hostname, modelo, cpu_modelo, cpu, ram, ram_total,
                       disco_c, disco_c_total, disco_d, disco_d_total,
                       battery_status, carregador, rede, localidade,
                       departamento, usuario, ip_address, ativo_fisico,
                       centro_custo, uptime, boot_time, ultima_atualizacao,
                       os_version
                FROM maquinas_v6
                ORDER BY hostname
            """)
            rows = c.fetchall()
            cols = [d[0] for d in c.description]

    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows, columns=cols)
    agora = datetime.now()
    df["diff"]   = (agora - df["ultima_atualizacao"]).dt.total_seconds()
    df["STATUS"] = df["diff"].apply(_status)
    df["REPORT"] = df["ultima_atualizacao"].dt.strftime("%d/%m/%Y %H:%M")

    if status_f and status_f != "TODOS":
        df = df[df["STATUS"] == status_f]
    if depto_f:
        df = df[df["departamento"] == depto_f]
    if local_f:
        df = df[df["localidade"] == local_f]

    return df.reset_index(drop=True)


# ── Geradores de export ───────────────────────────────────────────────────────

def _gerar_csv(df: pd.DataFrame) -> str:
    cols = ["STATUS", "hostname", "modelo", "cpu_modelo", "cpu", "ram",
            "disco_c", "disco_c_total", "ram_total", "localidade",
            "departamento", "usuario", "ip_address", "os_version",
            "ativo_fisico", "centro_custo", "boot_time", "REPORT"]
    out = df[[c for c in cols if c in df.columns]].copy()
    out.columns = [c.upper() for c in out.columns]
    return out.to_csv(index=False, encoding="utf-8-sig")


def _gerar_excel(df: pd.DataFrame) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import PatternFill, Font, Alignment
    from openpyxl.utils import get_column_letter

    wb = Workbook()

    # ── Aba 1: Resumo ─────────────────────────────────────────────────────────
    ws_r = wb.active
    ws_r.title = "Resumo"
    ws_r.sheet_view.showGridLines = False

    total   = len(df)
    online  = len(df[df["STATUS"] == "Online"])
    alerta  = len(df[df["STATUS"] == "Alerta"])
    offline = len(df[df["STATUS"] == "Offline"])

    ws_r.merge_cells("A1:D1")
    ws_r["A1"] = "NEON CONTROL CENTER — RELATORIO DE EQUIPAMENTOS"
    ws_r["A1"].font      = Font(bold=True, size=14, color="22D3EE")
    ws_r["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws_r["A1"].fill      = PatternFill("solid", fgColor="020617")
    ws_r.row_dimensions[1].height = 30

    ws_r.merge_cells("A2:D2")
    ws_r["A2"] = f"Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}"
    ws_r["A2"].font      = Font(size=9, color="64748B")
    ws_r["A2"].alignment = Alignment(horizontal="center")
    ws_r["A2"].fill      = PatternFill("solid", fgColor="0F172A")

    kpi_cfg = [
        ("TOTAL",   total,   "3B82F6", "DBEAFE"),
        ("ONLINE",  online,  "10B981", "D1FAE5"),
        ("ALERTA",  alerta,  "F59E0B", "FEF9C3"),
        ("OFFLINE", offline, "64748B", "F1F5F9"),
    ]
    for i, (label, value, fg, bg) in enumerate(kpi_cfg, start=1):
        col = get_column_letter(i)
        ws_r.column_dimensions[col].width = 20
        ws_r[f"{col}4"] = label
        ws_r[f"{col}4"].font      = Font(bold=True, size=10, color="FFFFFF")
        ws_r[f"{col}4"].fill      = PatternFill("solid", fgColor=fg)
        ws_r[f"{col}4"].alignment = Alignment(horizontal="center", vertical="center")
        ws_r.row_dimensions[4].height = 22
        ws_r[f"{col}5"] = value
        ws_r[f"{col}5"].font      = Font(bold=True, size=22, color=fg)
        ws_r[f"{col}5"].fill      = PatternFill("solid", fgColor=bg)
        ws_r[f"{col}5"].alignment = Alignment(horizontal="center", vertical="center")
        ws_r.row_dimensions[5].height = 36

    # ── Aba 2: Equipamentos ───────────────────────────────────────────────────
    ws = wb.create_sheet("Equipamentos")
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A2"

    col_map = [
        ("STATUS",        "STATUS"),
        ("hostname",      "HOSTNAME"),
        ("modelo",        "MODELO"),
        ("cpu_modelo",    "PROCESSADOR"),
        ("cpu",           "CPU (%)"),
        ("ram",           "RAM (%)"),
        ("disco_c",       "DISCO C (%)"),
        ("disco_d",       "DISCO D (%)"),
        ("ram_total",     "RAM TOTAL (GB)"),
        ("disco_c_total", "DISCO C TOTAL (GB)"),
        ("localidade",    "LOCALIDADE"),
        ("departamento",  "DEPARTAMENTO"),
        ("usuario",       "USUARIO"),
        ("ip_address",    "IP"),
        ("os_version",    "SISTEMA OP."),
        ("ativo_fisico",  "ATIVO FISICO (AF)"),
        ("centro_custo",  "CENTRO CUSTO (CC)"),
        ("boot_time",     "BOOT SISTEMA"),
        ("REPORT",        "ULTIMO REPORT"),
    ]
    col_widths = [11, 20, 24, 32, 9, 9, 11, 11, 14, 17, 14, 16, 16, 15, 28, 16, 16, 16, 16]

    hdr_fill = PatternFill("solid", fgColor="020617")
    hdr_font = Font(bold=True, color="22D3EE", size=9)
    for ci, ((_, label), w) in enumerate(zip(col_map, col_widths), 1):
        cell = ws.cell(row=1, column=ci, value=label)
        cell.fill      = hdr_fill
        cell.font      = hdr_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.column_dimensions[get_column_letter(ci)].width = w
    ws.row_dimensions[1].height = 22

    status_style = {
        "Online":  ("D1FAE5", "065F46", "10B981"),
        "Alerta":  ("FEF9C3", "92400E", "F59E0B"),
        "Offline": ("F1F5F9", "374151", "64748B"),
    }
    for ri, (_, row) in enumerate(df.iterrows(), start=2):
        status = str(row.get("STATUS", "Offline"))
        bg, fg_st, _ = status_style.get(status, ("F1F5F9", "374151", "64748B"))
        vals = [
            status,
            row.get("hostname"),
            row.get("modelo"),
            row.get("cpu_modelo"),
            round(float(row.get("cpu") or 0), 1),
            round(float(row.get("ram") or 0), 1),
            round(float(row.get("disco_c") or 0), 1),
            round(float(row.get("disco_d") or 0), 1),
            int(row.get("ram_total") or 0),
            int(row.get("disco_c_total") or 0),
            row.get("localidade"),
            row.get("departamento"),
            row.get("usuario"),
            row.get("ip_address"),
            row.get("os_version"),
            row.get("ativo_fisico"),
            row.get("centro_custo"),
            row.get("boot_time"),
            row.get("REPORT"),
        ]
        for ci, val in enumerate(vals, 1):
            cell = ws.cell(row=ri, column=ci, value=val)
            cell.font      = Font(size=9)
            cell.alignment = Alignment(vertical="center")
            if ci == 1:
                cell.fill      = PatternFill("solid", fgColor=bg)
                cell.font      = Font(size=9, bold=True, color=fg_st)
                cell.alignment = Alignment(horizontal="center", vertical="center")

    ws.auto_filter.ref = f"A1:{get_column_letter(len(col_map))}1"

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()


def _gerar_pdf(df: pd.DataFrame) -> bytes:
    from fpdf import FPDF

    total   = len(df)
    online  = len(df[df["STATUS"] == "Online"])
    alerta  = len(df[df["STATUS"] == "Alerta"])
    offline = len(df[df["STATUS"] == "Offline"])
    agora   = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

    pdf = FPDF(orientation="L", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=12)
    pdf.set_margins(10, 10, 10)
    pdf.add_page()

    # ── Cabeçalho ─────────────────────────────────────────────────────────────
    pdf.set_fill_color(2, 6, 23)
    pdf.rect(0, 0, 297, 28, "F")
    pdf.set_y(5)
    pdf.set_font("Helvetica", "B", 15)
    pdf.set_text_color(34, 211, 238)
    pdf.cell(0, 8, "NEON CONTROL CENTER", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "B", 10)
    pdf.set_text_color(148, 163, 184)
    pdf.cell(0, 6, "RELATORIO DE EQUIPAMENTOS", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 8)
    pdf.set_text_color(100, 116, 139)
    pdf.cell(0, 5, f"Gerado em {agora}", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(5)

    # ── KPI bar ───────────────────────────────────────────────────────────────
    kpis = [
        ("TOTAL",   str(total),   (59, 130, 246),  (219, 234, 254)),
        ("ONLINE",  str(online),  (16, 185, 129),  (209, 250, 229)),
        ("ALERTA",  str(alerta),  (245, 158, 11),  (254, 249, 195)),
        ("OFFLINE", str(offline), (100, 116, 139), (241, 245, 249)),
    ]
    box_w = 66
    for label, value, (r, g, b), (br, bg_c, bb) in kpis:
        x0 = pdf.get_x()
        y0 = pdf.get_y()
        pdf.set_fill_color(br, bg_c, bb)
        pdf.rect(x0, y0, box_w, 14, "F")
        pdf.set_xy(x0, y0 + 1)
        pdf.set_font("Helvetica", "B", 7)
        pdf.set_text_color(r, g, b)
        pdf.cell(box_w, 5, label, align="C")
        pdf.set_xy(x0, y0 + 6)
        pdf.set_font("Helvetica", "B", 14)
        pdf.cell(box_w, 8, value, align="C")
        pdf.set_xy(x0 + box_w, y0)
    pdf.ln(16)

    # ── Tabela ────────────────────────────────────────────────────────────────
    headers = ["STATUS", "HOSTNAME", "MODELO", "CPU%", "RAM%", "DISCO C%",
               "LOCALIDADE", "DEPARTAMENTO", "USUARIO", "IP", "ULTIMO REPORT"]
    widths  = [18,       35,         38,       12,      12,     14,
               22,          24,           24,       24,    30]

    # Header row
    pdf.set_fill_color(2, 6, 23)
    pdf.set_text_color(34, 211, 238)
    pdf.set_font("Helvetica", "B", 7)
    pdf.set_draw_color(30, 41, 59)
    for hdr, w in zip(headers, widths):
        pdf.cell(w, 7, hdr, border=1, fill=True, align="C")
    pdf.ln()

    # Data rows
    status_colors = {
        "Online":  ((209, 250, 229), (6, 95, 70)),
        "Alerta":  ((254, 249, 195), (146, 64, 14)),
        "Offline": ((241, 245, 249), (55, 65, 81)),
    }
    row_bg_alt = (249, 250, 251)
    row_bg_def = (255, 255, 255)

    pdf.set_font("Helvetica", "", 7)
    pdf.set_draw_color(226, 232, 240)
    for ri, (_, row) in enumerate(df.iterrows()):
        status = str(row.get("STATUS", "Offline"))
        (st_bg, st_fg) = status_colors.get(status, ((241, 245, 249), (55, 65, 81)))
        row_bg = row_bg_alt if ri % 2 else row_bg_def

        # STATUS cell
        pdf.set_fill_color(*st_bg)
        pdf.set_text_color(*st_fg)
        pdf.set_font("Helvetica", "B", 7)
        pdf.cell(widths[0], 6, status, border=1, fill=True, align="C")

        # Remaining cells
        pdf.set_fill_color(*row_bg)
        pdf.set_text_color(30, 41, 59)
        pdf.set_font("Helvetica", "", 7)

        def _val(v, maxc=None):
            s = str(v) if v is not None and str(v) != "nan" else "-"
            return s[:maxc] if maxc else s

        cells = [
            _val(row.get("hostname"), 18),
            _val(row.get("modelo"), 20),
            f"{float(row.get('cpu') or 0):.1f}%",
            f"{float(row.get('ram') or 0):.1f}%",
            f"{float(row.get('disco_c') or 0):.1f}%",
            _val(row.get("localidade"), 14),
            _val(row.get("departamento"), 15),
            _val(row.get("usuario"), 15),
            _val(row.get("ip_address"), 15),
            _val(row.get("REPORT"), 16),
        ]
        for val, w in zip(cells, widths[1:]):
            pdf.cell(w, 6, val, border=1, fill=True)
        pdf.ln()

    # ── Rodapé ────────────────────────────────────────────────────────────────
    pdf.set_y(-12)
    pdf.set_font("Helvetica", "I", 7)
    pdf.set_text_color(148, 163, 184)
    pdf.cell(0, 5, f"NEON Control Center  |  {agora}  |  Total: {total} equipamentos", align="C")

    return bytes(pdf.output())


def _gerar_html(df: pd.DataFrame) -> str:
    total   = len(df)
    online  = len(df[df["STATUS"] == "Online"])
    alerta  = len(df[df["STATUS"] == "Alerta"])
    offline = len(df[df["STATUS"] == "Offline"])
    agora   = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

    def _v(v, default="-"):
        s = str(v) if v is not None and str(v) not in ("", "nan", "None") else default
        return s

    rows_html = ""
    for _, row in df.iterrows():
        status = row.get("STATUS", "Offline")
        cls    = {"Online": "st-on", "Alerta": "st-al", "Offline": "st-off"}.get(status, "st-off")
        cpu    = f"{float(row.get('cpu') or 0):.1f}%"
        ram    = f"{float(row.get('ram') or 0):.1f}%"
        disco  = f"{float(row.get('disco_c') or 0):.1f}%"
        rows_html += f"""<tr>
          <td><span class="badge {cls}">{status}</span></td>
          <td class="mono">{_v(row.get('hostname'))}</td>
          <td>{_v(row.get('modelo'))}</td>
          <td class="num">{cpu}</td><td class="num">{ram}</td><td class="num">{disco}</td>
          <td>{_v(row.get('localidade'))}</td>
          <td>{_v(row.get('departamento'))}</td>
          <td>{_v(row.get('usuario'))}</td>
          <td class="mono">{_v(row.get('ip_address'))}</td>
          <td>{_v(row.get('os_version'))}</td>
          <td>{_v(row.get('boot_time'))}</td>
          <td class="mono">{_v(row.get('REPORT'))}</td>
        </tr>"""

    return f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Relatorio de Equipamentos — NEON</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:'Segoe UI',sans-serif;background:#f8fafc;color:#1e293b;font-size:13px}}
.header{{background:#020617;color:#22d3ee;padding:1.5rem 2rem;text-align:center}}
.header h1{{font-size:1.4rem;font-weight:900;letter-spacing:.12em}}
.header h2{{font-size:.85rem;color:#94a3b8;margin-top:.3rem;letter-spacing:.08em}}
.header p{{font-size:.75rem;color:#475569;margin-top:.2rem}}
.kpis{{display:flex;gap:1rem;padding:1.25rem 2rem;background:#0f172a;flex-wrap:wrap}}
.kpi{{flex:1;min-width:110px;padding:.75rem 1rem;border-radius:.5rem;text-align:center}}
.kpi-label{{font-size:.6rem;font-weight:800;letter-spacing:.1em;display:block;margin-bottom:.3rem}}
.kpi-value{{font-size:2rem;font-weight:900;display:block;line-height:1}}
.kt{{background:#1e3a5f;color:#93c5fd}}.kt .kpi-value{{color:#3b82f6}}
.ko{{background:#064e3b;color:#6ee7b7}}.ko .kpi-value{{color:#10b981}}
.ka{{background:#78350f;color:#fde68a}}.ka .kpi-value{{color:#f59e0b}}
.kf{{background:#1e293b;color:#94a3b8}}.kf .kpi-value{{color:#64748b}}
.content{{padding:1.5rem 2rem}}
.meta{{display:flex;justify-content:space-between;align-items:center;margin-bottom:.75rem;font-size:.75rem;color:#64748b}}
.meta strong{{color:#1e293b}}
table{{width:100%;border-collapse:collapse;font-size:.75rem}}
thead tr{{background:#0f172a}}
thead th{{padding:.55rem .65rem;text-align:left;font-size:.65rem;letter-spacing:.06em;
          color:#22d3ee;font-weight:700;white-space:nowrap;border-bottom:2px solid #1e3a5f}}
tbody tr{{border-bottom:1px solid #e2e8f0;transition:background .1s}}
tbody tr:nth-child(even){{background:#f8fafc}}
tbody tr:hover{{background:#e0f2fe}}
tbody td{{padding:.45rem .65rem;white-space:nowrap;vertical-align:middle}}
.mono{{font-family:'Courier New',monospace;font-size:.7rem}}
.num{{text-align:right}}
.badge{{padding:.15rem .5rem;border-radius:.25rem;font-size:.65rem;font-weight:700;white-space:nowrap}}
.st-on{{background:#dcfce7;color:#15803d}}.st-al{{background:#fef9c3;color:#a16207}}
.st-off{{background:#f1f5f9;color:#64748b}}
.footer{{text-align:center;padding:.75rem;font-size:.7rem;color:#94a3b8;
         background:#0f172a;margin-top:1.5rem}}
@media print{{
  body{{background:#fff}}
  .header{{background:#020617!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}}
  .kpis{{background:#0f172a!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}}
  thead tr{{background:#0f172a!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}}
}}
</style>
</head>
<body>
<div class="header">
  <h1>NEON CONTROL CENTER</h1>
  <h2>RELATORIO DE EQUIPAMENTOS</h2>
  <p>Gerado em {agora}</p>
</div>
<div class="kpis">
  <div class="kpi kt"><span class="kpi-label">TOTAL</span><span class="kpi-value">{total}</span></div>
  <div class="kpi ko"><span class="kpi-label">ONLINE</span><span class="kpi-value">{online}</span></div>
  <div class="kpi ka"><span class="kpi-label">ALERTA</span><span class="kpi-value">{alerta}</span></div>
  <div class="kpi kf"><span class="kpi-label">OFFLINE</span><span class="kpi-value">{offline}</span></div>
</div>
<div class="content">
  <div class="meta">
    <span>Total de registros: <strong>{total}</strong></span>
    <span>Relatorio gerado em <strong>{agora}</strong></span>
  </div>
  <table>
    <thead><tr>
      <th>STATUS</th><th>HOSTNAME</th><th>MODELO</th>
      <th>CPU%</th><th>RAM%</th><th>DISCO C%</th>
      <th>LOCALIDADE</th><th>DEPARTAMENTO</th><th>USUARIO</th>
      <th>IP</th><th>SISTEMA OP.</th><th>BOOT SISTEMA</th><th>ULTIMO REPORT</th>
    </tr></thead>
    <tbody>{rows_html}</tbody>
  </table>
</div>
<div class="footer">NEON Control Center &mdash; {agora} &mdash; {total} equipamentos</div>
</body>
</html>"""


# ── Layout ────────────────────────────────────────────────────────────────────

def layout(**kwargs):
    return html.Div(className="page-content", children=[
        page_header("RELATORIO DE EQUIPAMENTOS",
                    "Exportacao completa do parque tecnologico",
                    "fa-solid fa-file-chart-column"),

        dcc.Interval(id="rel-interval", interval=60_000, n_intervals=0),

        dcc.Download(id="rel-dl-csv"),
        dcc.Download(id="rel-dl-excel"),
        dcc.Download(id="rel-dl-html"),
        dcc.Download(id="rel-dl-pdf"),

        # ── Filtros ───────────────────────────────────────────────────────────
        html.Div(className="panel neon-cyan", style={"marginBottom": "1rem"}, children=[
            html.Div(className="grid-3", children=[
                html.Div([
                    html.Label("STATUS", className="login-label"),
                    dcc.Dropdown(
                        id="rel-f-status",
                        options=[
                            {"label": "Todos",   "value": "TODOS"},
                            {"label": "Online",  "value": "Online"},
                            {"label": "Alerta",  "value": "Alerta"},
                            {"label": "Offline", "value": "Offline"},
                        ],
                        value="TODOS", clearable=False,
                        style={"color": "#1e293b"},
                    ),
                ]),
                html.Div([
                    html.Label("DEPARTAMENTO", className="login-label"),
                    dcc.Dropdown(id="rel-f-depto", placeholder="Todos...",
                                 style={"color": "#1e293b"}),
                ]),
                html.Div([
                    html.Label("LOCALIDADE", className="login-label"),
                    dcc.Dropdown(
                        id="rel-f-local",
                        options=[
                            {"label": "Escritorio",  "value": "Escritorio"},
                            {"label": "Home Office", "value": "Home Office"},
                            {"label": "Desconhecido","value": "Desconhecido"},
                        ],
                        placeholder="Todas...", style={"color": "#1e293b"},
                    ),
                ]),
            ]),
        ]),

        # ── KPIs ──────────────────────────────────────────────────────────────
        html.Div(id="rel-kpis", className="kpi-grid", style={"marginBottom": "1rem"}),

        # ── Barra de exportação ───────────────────────────────────────────────
        html.Div(className="panel neon-purple", style={"marginBottom": "1rem"}, children=[
            html.Div(style={"display": "flex", "alignItems": "center",
                            "gap": ".75rem", "flexWrap": "wrap"}, children=[
                html.Span("EXPORTAR:", style={"fontSize": ".65rem", "fontWeight": "800",
                                              "color": "#a78bfa", "letterSpacing": ".1em"}),
                html.Button(
                    [html.I(className="fa-solid fa-file-csv",
                            style={"marginRight": ".4rem"}), "CSV"],
                    id="rel-btn-csv", n_clicks=0,
                    className="btn-login",
                    style={"width": "auto", "padding": ".35rem 1rem",
                           "fontSize": ".7rem", "background": "linear-gradient(135deg,#059669,#065f46)"},
                ),
                html.Button(
                    [html.I(className="fa-solid fa-file-excel",
                            style={"marginRight": ".4rem"}), "EXCEL"],
                    id="rel-btn-excel", n_clicks=0,
                    className="btn-login",
                    style={"width": "auto", "padding": ".35rem 1rem",
                           "fontSize": ".7rem", "background": "linear-gradient(135deg,#16a34a,#14532d)"},
                ),
                html.Button(
                    [html.I(className="fa-solid fa-file-code",
                            style={"marginRight": ".4rem"}), "HTML"],
                    id="rel-btn-html", n_clicks=0,
                    className="btn-login",
                    style={"width": "auto", "padding": ".35rem 1rem",
                           "fontSize": ".7rem", "background": "linear-gradient(135deg,#d97706,#92400e)"},
                ),
                html.Button(
                    [html.I(className="fa-solid fa-file-pdf",
                            style={"marginRight": ".4rem"}), "PDF"],
                    id="rel-btn-pdf", n_clicks=0,
                    className="btn-login",
                    style={"width": "auto", "padding": ".35rem 1rem",
                           "fontSize": ".7rem", "background": "linear-gradient(135deg,#dc2626,#7f1d1d)"},
                ),
                html.Span(id="rel-export-status",
                          style={"fontSize": ".7rem", "color": "#34d399",
                                 "marginLeft": ".5rem"}),
            ]),
        ]),

        # ── Tabela ────────────────────────────────────────────────────────────
        html.Div(className="panel neon-cyan", children=[
            html.Div(style={"display": "flex", "justifyContent": "space-between",
                            "alignItems": "center", "marginBottom": ".5rem"}, children=[
                html.P("CATALOGO COMPLETO", className="section-title",
                       style={"marginBottom": 0}),
                html.Span(id="rel-total-txt",
                          style={"fontSize": ".65rem", "color": "#475569"}),
            ]),
            dash_table.DataTable(
                id="rel-tabela",
                data=[], columns=[],
                filter_action="native",
                sort_action="native",
                page_size=30,
                style_table={"overflowX": "auto", "width": "100%"},
                style_cell={
                    "textAlign": "left", "padding": "8px 12px", "fontSize": "11px",
                    "backgroundColor": "#090d16", "color": "#94a3b8",
                    "border": "1px solid rgba(6,182,212,.05)",
                    "whiteSpace": "nowrap", "overflow": "hidden",
                    "textOverflow": "ellipsis", "maxWidth": "220px",
                },
                style_header={
                    "backgroundColor": "#020617", "color": "#22d3ee",
                    "fontWeight": "bold", "border": "1px solid rgba(6,182,212,.15)",
                },
                style_data_conditional=[
                    {"if": {"filter_query": '{STATUS} = "Online"'},
                     "color": "#34d399"},
                    {"if": {"filter_query": '{STATUS} = "Alerta"'},
                     "color": "#fbbf24"},
                    {"if": {"filter_query": '{STATUS} = "Offline"'},
                     "color": "#475569", "fontStyle": "italic"},
                ],
            ),
        ]),
    ])


# ── Callback: atualizar tabela e KPIs ─────────────────────────────────────────
@callback(
    [Output("rel-kpis",      "children"),
     Output("rel-tabela",    "data"),
     Output("rel-tabela",    "columns"),
     Output("rel-f-depto",   "options"),
     Output("rel-total-txt", "children")],
    [Input("rel-interval",  "n_intervals"),
     Input("rel-f-status", "value"),
     Input("rel-f-depto",  "value"),
     Input("rel-f-local",  "value")],
    State("session-store", "data"),
)
def atualizar(n, status_f, depto_f, local_f, session):
    if not session or not session.get("authenticated"):
        return [], [], [], [], ""
    try:
        df = _query(status_f, depto_f, local_f)
    except Exception as e:
        return [], [], [], [], f"Erro: {e}"

    if df.empty:
        return [], [], [], [], "Nenhum dado encontrado."

    total   = len(df)
    online  = int((df["STATUS"] == "Online").sum())
    alerta  = int((df["STATUS"] == "Alerta").sum())
    offline = int((df["STATUS"] == "Offline").sum())

    kpis = [
        kpi_card("TOTAL",   total,   "#3b82f6", "fa-solid fa-server"),
        kpi_card("ONLINE",  online,  "#10b981", "fa-solid fa-circle-check"),
        kpi_card("ALERTA",  alerta,  "#f59e0b", "fa-solid fa-triangle-exclamation",
                 pulse=alerta > 0),
        kpi_card("OFFLINE", offline, "#64748b", "fa-solid fa-circle-xmark"),
        kpi_card("DEPARTAMENTOS", df["departamento"].nunique(),
                 "#06b6d4", "fa-solid fa-sitemap"),
        kpi_card("HOME OFFICE",
                 int((df["localidade"] == "Home Office").sum()),
                 "#8b5cf6", "fa-solid fa-house-laptop"),
    ]

    deptos = sorted(df["departamento"].dropna().unique())
    depto_opts = [{"label": d, "value": d} for d in deptos]

    cols_disp = {
        "STATUS": "STATUS", "hostname": "HOSTNAME", "modelo": "MODELO",
        "cpu_modelo": "PROCESSADOR", "cpu": "CPU (%)", "ram": "RAM (%)",
        "disco_c": "DISCO C (%)", "localidade": "LOCALIDADE",
        "departamento": "DEPARTAMENTO", "usuario": "USUARIO",
        "ip_address": "IP", "os_version": "SISTEMA OP.",
        "ativo_fisico": "AF", "centro_custo": "CC",
        "boot_time": "BOOT SISTEMA", "REPORT": "ULTIMO REPORT",
    }
    df_out  = df[[c for c in cols_disp if c in df.columns]].rename(columns=cols_disp)
    data    = df_out.to_dict("records")
    columns = [{"name": v, "id": v} for v in df_out.columns]

    txt = f"{total} equipamento{'s' if total != 1 else ''} — {online} online · {alerta} alerta · {offline} offline"
    return kpis, data, columns, depto_opts, txt


# ── Callback: exports ─────────────────────────────────────────────────────────
@callback(
    [Output("rel-dl-csv",        "data"),
     Output("rel-dl-excel",      "data"),
     Output("rel-dl-html",       "data"),
     Output("rel-dl-pdf",        "data"),
     Output("rel-export-status", "children")],
    [Input("rel-btn-csv",   "n_clicks"),
     Input("rel-btn-excel", "n_clicks"),
     Input("rel-btn-html",  "n_clicks"),
     Input("rel-btn-pdf",   "n_clicks")],
    [State("rel-f-status", "value"),
     State("rel-f-depto",  "value"),
     State("rel-f-local",  "value"),
     State("session-store","data")],
    prevent_initial_call=True,
)
def exportar(n_csv, n_excel, n_html, n_pdf, status_f, depto_f, local_f, session):
    no = dash.no_update
    if not session or not session.get("authenticated"):
        return no, no, no, no, "Nao autenticado."

    trigger = ctx.triggered_id
    ts = datetime.now().strftime("%Y%m%d_%H%M")

    try:
        df = _query(status_f, depto_f, local_f)
    except Exception as e:
        return no, no, no, no, f"Erro ao carregar dados: {e}"

    if df.empty:
        return no, no, no, no, "Sem dados para exportar."

    try:
        if trigger == "rel-btn-csv":
            conteudo = _gerar_csv(df)
            return (
                {"content": conteudo, "filename": f"relatorio_{ts}.csv"},
                no, no, no, f"CSV gerado — {len(df)} registros."
            )

        if trigger == "rel-btn-excel":
            dados = _gerar_excel(df)
            return (
                no,
                dcc.send_bytes(dados, f"relatorio_{ts}.xlsx"),
                no, no, f"Excel gerado — {len(df)} registros."
            )

        if trigger == "rel-btn-html":
            conteudo = _gerar_html(df)
            return (
                no, no,
                {"content": conteudo, "filename": f"relatorio_{ts}.html"},
                no, f"HTML gerado — {len(df)} registros."
            )

        if trigger == "rel-btn-pdf":
            dados = _gerar_pdf(df)
            return (
                no, no, no,
                dcc.send_bytes(dados, f"relatorio_{ts}.pdf"),
                f"PDF gerado — {len(df)} registros."
            )

    except Exception as e:
        return no, no, no, no, f"Erro ao exportar: {e}"

    return no, no, no, no, ""
