import dash
import pandas as pd
import plotly.express as px
from dash import Input, Output, callback, dcc, html
from datetime import datetime

from dashboard.components import page_header, fmt_ts
from database import get_conn

dash.register_page(__name__, path="/maquina", name="Detalhe", title="Neon — Detalhe")


def layout(hostname=None, **kwargs):
    if not hostname:
        return html.Div(className="page-content", children=[
            page_header("DETALHE DA MAQUINA", "", "fa-solid fa-laptop"),
            html.Div(className="panel neon-cyan", children=[
                html.P("Acesse este painel clicando em um hostname no Painel principal.",
                       style={"color": "#475569", "fontSize": ".85rem"}),
                dcc.Link("Voltar ao Painel", href="/",
                         style={"color": "#22d3ee", "fontSize": ".8rem"}),
            ]),
        ])

    return html.Div(className="page-content", children=[
        html.Div(style={"display": "flex", "alignItems": "center", "gap": "1rem", "marginBottom": "1.5rem"}, children=[
            dcc.Link(html.I(className="fa-solid fa-arrow-left",
                            style={"fontSize": "1rem", "color": "#22d3ee"}), href="/"),
            page_header(f"MAQUINA: {hostname}", "Diagnostico completo e historico",
                        "fa-solid fa-laptop"),
        ]),

        dcc.Store(id="detalhe-hostname", data=hostname),
        dcc.Interval(id="detalhe-interval", interval=15_000, n_intervals=0),

        # Info Cards
        html.Div(id="detalhe-info", className="grid-2", style={"marginBottom": "1rem"}),

        # Grafico historico completo
        html.Div(className="panel neon-cyan", style={"marginBottom": "1rem"}, children=[
            html.P("HISTORICO 24H — CPU / RAM / DISCO", className="section-title"),
            dcc.Graph(id="detalhe-grafico", style={"height": "350px"},
                      config={"displayModeBar": True}),
        ]),

        # Processos pesados (último report)
        html.Div(className="panel neon-purple", children=[
            html.P("PROCESSOS MAIS PESADOS (ultimo report)", className="section-title"),
            html.Div(id="detalhe-processos"),
        ]),
    ])


@callback(
    [Output("detalhe-info", "children"),
     Output("detalhe-grafico", "figure"),
     Output("detalhe-processos", "children")],
    [Input("detalhe-interval", "n_intervals"),
     Input("detalhe-hostname", "data"),
     Input("session-store", "data")],
)
def atualizar_detalhe(n, hostname, session):
    if not session or not session.get("authenticated") or not hostname:
        return [], _fig_vazio(""), html.Div()

    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("SELECT * FROM maquinas_v6 WHERE hostname = %s", (hostname,))
                row = c.fetchone()
                if not row:
                    return [html.Div("Maquina nao encontrada.")], _fig_vazio(""), html.Div()
                cols = [d[0] for d in c.description]
                m = dict(zip(cols, row))

                c.execute("""
                    SELECT timestamp, cpu, ram, disco_c, disco_d
                    FROM historico_v6
                    WHERE hostname = %s
                      AND timestamp > NOW() - INTERVAL '24 hours'
                    ORDER BY timestamp
                """, (hostname,))
                hist_rows = c.fetchall()
                hist_cols = [d[0] for d in c.description]
    except Exception as e:
        return [html.Div(f"Erro: {e}")], _fig_vazio(""), html.Div()

    diff = (datetime.now() - m["ultima_atualizacao"]).total_seconds() if m.get("ultima_atualizacao") else 9999
    if diff <= 120:
        status_label, status_color = "Online",  "#10b981"
    elif diff <= 720:
        status_label, status_color = "Alerta",  "#f59e0b"
    else:
        status_label, status_color = "Offline", "#64748b"

    def info_row(label, valor):
        return html.Div(style={"display": "flex", "justifyContent": "space-between",
                                "padding": ".35rem 0", "borderBottom": "1px solid rgba(6,182,212,.07)"}, children=[
            html.Span(label, style={"fontSize": ".65rem", "color": "#475569", "fontWeight": "700"}),
            html.Span(str(valor) if valor else "-", style={"fontSize": ".7rem", "color": "#e2e8f0"}),
        ])

    info_cards = [
        # Card esquerdo — Hardware
        html.Div(className="panel neon-cyan", children=[
            html.Div(style={"display": "flex", "justifyContent": "space-between", "marginBottom": ".5rem"}, children=[
                html.P("HARDWARE", className="section-title", style={"marginBottom": 0}),
                html.Span(status_label, style={"fontSize": ".7rem", "fontWeight": "800",
                                               "color": status_color}),
            ]),
            info_row("Modelo",        m.get("modelo")),
            info_row("Processador",   m.get("cpu_modelo")),
            info_row("RAM Total",     f"{m.get('ram_total', 0)} GB"),
            info_row("Disco C Total", f"{m.get('disco_c_total', 0)} GB"),
            info_row("Disco D Total", f"{m.get('disco_d_total', 0)} GB" if m.get('disco_d_total') else "N/A"),
            info_row("Sistema Op.",   m.get("os_version")),
        ]),
        # Card direito — Rede / Status
        html.Div(className="panel neon-purple", children=[
            html.P("STATUS E REDE", className="section-title"),
            info_row("CPU Atual",     f"{m.get('cpu', 0)}%"),
            info_row("RAM Atual",     f"{m.get('ram', 0)}%"),
            info_row("Disco C",       f"{m.get('disco_c', 0)}%"),
            info_row("Bateria",       f"{m.get('battery_status', 0)}% ({m.get('carregador', '-')})"),
            info_row("Rede",          m.get("rede")),
            info_row("Localidade",    m.get("localidade")),
            info_row("Departamento",  m.get("departamento")),
            info_row("Ativo Fisico",  m.get("ativo_fisico")),
            info_row("Centro Custo",  m.get("centro_custo")),
            info_row("Usuario",       m.get("usuario")),
            info_row("IP",            m.get("ip_address")),
            info_row("Uptime",        m.get("uptime")),
            info_row("Boot do Sistema", m.get("boot_time")),
            info_row("Ultimo Report", fmt_ts(m.get("ultima_atualizacao"))),
        ]),
    ]

    # Grafico
    if hist_rows:
        df = pd.DataFrame(hist_rows, columns=hist_cols)
        cores = {"cpu": "#06b6d4", "ram": "#a855f7", "disco_c": "#10b981", "disco_d": "#f59e0b"}
        fig = px.line(df, x="timestamp", y=["cpu", "ram", "disco_c", "disco_d"],
                      color_discrete_map=cores, title=f"HISTORICO 24H — {hostname}")
        fig.update_layout(
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            font_color="#94a3b8", title_font_color="#22d3ee",
            margin=dict(l=10, r=10, t=40, b=10),
            yaxis_range=[0, 105],
            xaxis=dict(gridcolor="rgba(6,182,212,.06)"),
            yaxis=dict(gridcolor="rgba(6,182,212,.06)"),
        )
    else:
        fig = _fig_vazio("Sem historico nas ultimas 24h")

    # Processos
    viloes = m.get("viloes", "Normal")
    if viloes and viloes != "Normal":
        processos = [
            html.Div(p.strip(), style={"padding": ".3rem .5rem", "fontSize": ".75rem",
                                       "color": "#f59e0b", "borderBottom": "1px solid rgba(168,85,247,.08)"})
            for p in viloes.split(",") if p.strip()
        ]
    else:
        processos = [html.Div("Nenhum processo pesado registrado.",
                              style={"color": "#475569", "fontSize": ".8rem"})]

    return info_cards, fig, html.Div(processos)


def _fig_vazio(titulo):
    fig = px.line(title=titulo)
    fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      font_color="#94a3b8", margin=dict(l=10, r=10, t=40, b=10))
    return fig
