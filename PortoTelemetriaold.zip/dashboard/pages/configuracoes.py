import dash
from dash import Input, Output, State, callback, dcc, html

from config import (
    ALERT_COOLDOWN, ADMIN_USER,
    EMAIL_HOST, EMAIL_PORT, EMAIL_TO, EMAIL_USER,
    GOOGLE_CHAT_WEBHOOK, get_limiares,
)
from dashboard.components import page_header

dash.register_page(__name__, path="/configuracoes", name="Config", title="Neon — Config")


def layout(**kwargs):
    lim = get_limiares()
    return html.Div(className="page-content", children=[
        page_header("CONFIGURACOES", "Alertas, notificacoes e parametros do sistema",
                    "fa-solid fa-sliders"),

        # Limiares de alerta
        html.Div(className="panel neon-cyan", style={"marginBottom": "1rem"}, children=[
            html.P("LIMIARES DE ALERTA", className="section-title"),
            html.Div(className="grid-3", children=[
                _campo("CPU CRITICO (%)",   "cfg2-cpu",   lim["cpu"],   "number"),
                _campo("RAM CRITICO (%)",   "cfg2-ram",   lim["ram"],   "number"),
                _campo("DISCO CRITICO (%)", "cfg2-disco", lim["disco"], "number"),
            ]),
            html.Button("SALVAR LIMIARES", id="btn-salvar-lim", n_clicks=0,
                        className="btn-login", style={"width": "auto", "marginTop": ".75rem",
                                                      "padding": ".5rem 1.5rem"}),
            html.Span(id="feedback-lim", style={"fontSize": ".7rem", "color": "#34d399",
                                                "marginLeft": "1rem", "fontWeight": "700"}),
        ]),

        # Google Chat
        html.Div(className="panel neon-purple", style={"marginBottom": "1rem"}, children=[
            html.P("NOTIFICACOES — GOOGLE CHAT", className="section-title"),
            _campo("URL DO WEBHOOK", "cfg2-webhook", GOOGLE_CHAT_WEBHOOK or "", "text"),
            _campo("COOLDOWN ENTRE ALERTAS (seg)", "cfg2-cooldown", ALERT_COOLDOWN, "number"),
            html.Button("TESTAR WEBHOOK", id="btn-testar-webhook", n_clicks=0,
                        className="btn-logout",
                        style={"fontSize": ".65rem", "marginTop": ".5rem"}),
            html.Span(id="feedback-webhook",
                      style={"fontSize": ".7rem", "color": "#34d399", "marginLeft": "1rem"}),
        ]),

        # Email
        html.Div(className="panel neon-cyan", style={"marginBottom": "1rem"}, children=[
            html.P("NOTIFICACOES — EMAIL (SMTP)", className="section-title"),
            html.Div(className="grid-2", children=[
                _campo("SERVIDOR SMTP",       "cfg2-email-host", EMAIL_HOST or "",  "text"),
                _campo("PORTA SMTP",           "cfg2-email-port", EMAIL_PORT,        "number"),
                _campo("USUARIO SMTP",         "cfg2-email-user", EMAIL_USER or "",  "text"),
                _campo("DESTINATARIO (To)",    "cfg2-email-to",   EMAIL_TO   or "",  "text"),
            ]),
            html.Button("TESTAR EMAIL", id="btn-testar-email", n_clicks=0,
                        className="btn-logout",
                        style={"fontSize": ".65rem", "marginTop": ".5rem"}),
            html.Span(id="feedback-email",
                      style={"fontSize": ".7rem", "color": "#34d399", "marginLeft": "1rem"}),
        ]),

        # Info do sistema
        html.Div(className="panel neon-purple", children=[
            html.P("INFORMACOES DO SISTEMA", className="section-title"),
            _info_row("Usuario Admin",   ADMIN_USER),
            _info_row("Porta do Servidor", "8090"),
            _info_row("API Endpoint",    "POST /api/telemetry"),
            _info_row("Health Check",    "GET /api/health"),
            _info_row("Token da API",    "***configurado via variavel API_TOKEN***"),
        ]),
    ])


def _campo(label: str, id_: str, valor, tipo: str) -> html.Div:
    return html.Div(style={"marginBottom": ".5rem"}, children=[
        html.Label(label, className="login-label"),
        dcc.Input(id=id_, type=tipo, value=valor,
                  className="login-input", style={"marginBottom": 0}),
    ])


def _info_row(label: str, valor: str) -> html.Div:
    return html.Div(style={"display": "flex", "justifyContent": "space-between",
                            "padding": ".3rem 0", "borderBottom": "1px solid rgba(168,85,247,.07)"}, children=[
        html.Span(label, style={"fontSize": ".65rem", "color": "#475569", "fontWeight": "700"}),
        html.Span(valor, style={"fontSize": ".7rem", "color": "#a78bfa", "fontFamily": "monospace"}),
    ])


@callback(
    Output("feedback-lim", "children"),
    Input("btn-salvar-lim", "n_clicks"),
    [State("cfg2-cpu", "value"), State("cfg2-ram", "value"), State("cfg2-disco", "value")],
    prevent_initial_call=True,
)
def salvar_limiares(n, cpu, ram, disco):
    from config import set_limiares
    set_limiares(cpu=cpu, ram=ram, disco=disco)
    return f"Salvo: CPU {cpu}% | RAM {ram}% | Disco {disco}%"


@callback(
    Output("feedback-webhook", "children"),
    Input("btn-testar-webhook", "n_clicks"),
    State("cfg2-webhook", "value"),
    prevent_initial_call=True,
)
def testar_webhook(n, url):
    if not url:
        return "URL nao configurada."
    import requests
    try:
        from datetime import datetime
        res = requests.post(url, json={"text": f"[TESTE] Neon Telemetry — {datetime.now().strftime('%H:%M:%S')}"},
                            timeout=8)
        return f"Enviado! Status: {res.status_code}"
    except Exception as e:
        return f"Erro: {e}"


@callback(
    Output("feedback-email", "children"),
    Input("btn-testar-email", "n_clicks"),
    [State("cfg2-email-host", "value"), State("cfg2-email-port", "value"),
     State("cfg2-email-user", "value"), State("cfg2-email-to", "value")],
    prevent_initial_call=True,
)
def testar_email(n, host, port, user, to):
    if not all([host, user, to]):
        return "Configure servidor SMTP, usuario e destinatario."
    import smtplib, os
    from email.mime.text import MIMEText
    from datetime import datetime
    pwd = os.getenv("EMAIL_PASS") or ""
    msg = MIMEText(f"Teste de email do Neon Telemetry — {datetime.now()}", "plain", "utf-8")
    msg["Subject"] = "[NEON TELEMETRIA] Teste de email"
    msg["From"] = user; msg["To"] = to
    try:
        with smtplib.SMTP(host, int(port or 587), timeout=10) as s:
            s.starttls(); s.login(user, pwd); s.sendmail(user, [to], msg.as_string())
        return f"Email enviado para {to}!"
    except Exception as e:
        return f"Erro: {e}"
