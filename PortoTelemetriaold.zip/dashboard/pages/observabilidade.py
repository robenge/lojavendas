import dash
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Input, Output, State, callback, dcc, html, dash_table
from datetime import datetime

from analytics import (
    calcular_health_score, health_cor,
    prever_disco_cheio, detectar_anomalias,
    calcular_sla, reconstruir_timeline,
)
from dashboard.components import page_header, kpi_card
from database import get_conn

dash.register_page(__name__, path="/observabilidade", name="Observabilidade",
                   title="Neon — Observabilidade")


def layout(**kwargs):
    return html.Div(className="page-content", children=[
        dcc.Interval(id="obs-interval", interval=60_000, n_intervals=0),

        page_header("OBSERVABILIDADE",
                    "Saude, previsoes, eventos Windows e disponibilidade",
                    "fa-solid fa-microscope"),

        # KPIs
        html.Div(id="obs-kpis", className="kpi-grid", style={"marginBottom": "1rem"}),

        # ── Linha 1: Health Ranking + Previsão Disco ──────────────────────────
        html.Div(className="grid-2", style={"marginBottom": "1rem"}, children=[
            html.Div(className="panel neon-cyan", children=[
                html.P("RANKING DE SAUDE DAS MAQUINAS", className="section-title"),
                html.Div(id="obs-health-ranking"),
            ]),
            html.Div(className="panel neon-purple", children=[
                html.P("PREVISAO — DISCO C CRITICO", className="section-title"),
                html.Div(id="obs-disco-previsao"),
            ]),
        ]),

        # ── Linha 2: Eventos stats + Anomalias ────────────────────────────────
        html.Div(className="grid-2", style={"marginBottom": "1rem"}, children=[
            html.Div(className="panel neon-purple", children=[
                html.P("EVENTOS WINDOWS — ULTIMAS 24H", className="section-title"),
                html.Div(id="obs-eventos-stats"),
            ]),
            html.Div(className="panel neon-cyan", children=[
                html.P("ANOMALIAS DETECTADAS (Z-SCORE > 2.5)", className="section-title"),
                html.Div(id="obs-anomalias"),
            ]),
        ]),

        # ── SLA por máquina ───────────────────────────────────────────────────
        html.Div(className="panel neon-cyan", style={"marginBottom": "1rem"}, children=[
            html.P("DISPONIBILIDADE (SLA) — ULTIMOS 7 DIAS", className="section-title"),
            dcc.Graph(id="obs-sla-chart", config={"displayModeBar": False},
                      responsive=True, style={"height": "300px"}),
        ]),

        # ── Timeline Gantt ────────────────────────────────────────────────────
        html.Div(className="panel neon-cyan", style={"marginBottom": "1rem"}, children=[
            html.Div(style={"display": "flex", "justifyContent": "space-between",
                            "alignItems": "center", "marginBottom": ".5rem"}, children=[
                html.P("TIMELINE DE DISPONIBILIDADE",
                       className="section-title", style={"marginBottom": 0}),
                dcc.Dropdown(
                    id="obs-gantt-dias",
                    options=[
                        {"label": "1 dia",  "value": 1},
                        {"label": "3 dias", "value": 3},
                        {"label": "7 dias", "value": 7},
                    ],
                    value=3, clearable=False,
                    style={"color": "#1e293b", "width": "120px", "fontSize": ".75rem"},
                ),
            ]),
            dcc.Graph(id="obs-gantt", config={"displayModeBar": False},
                      responsive=True, style={"height": "400px"}),
        ]),

        # ── Segurança detalhada ───────────────────────────────────────────────
        html.Div(className="grid-2", style={"marginBottom": "1rem"}, children=[
            html.Div(className="panel neon-purple", children=[
                html.P("FIREWALL & DEFENDER", className="section-title"),
                html.Div(id="obs-seguranca-fw"),
            ]),
            html.Div(className="panel neon-purple", children=[
                html.P("ADMINISTRADORES LOCAIS", className="section-title"),
                html.Div(id="obs-seguranca-admins"),
            ]),
        ]),

        # ── Hardware — GPU + Discos físicos ──────────────────────────────────
        html.Div(className="grid-2", style={"marginBottom": "1rem"}, children=[
            html.Div(className="panel neon-cyan", children=[
                html.P("GPU & BIOS POR MÁQUINA", className="section-title"),
                html.Div(id="obs-hardware-gpu"),
            ]),
            html.Div(className="panel neon-cyan", children=[
                html.P("DISCOS FÍSICOS (S.M.A.R.T.)", className="section-title"),
                html.Div(id="obs-hardware-discos"),
            ]),
        ]),

        # ── Segurança v4 — RDP, UAC, Usuários locais ─────────────────────────
        html.Div(className="grid-2", style={"marginBottom": "1rem"}, children=[
            html.Div(className="panel neon-purple", children=[
                html.P("ACESSO REMOTO & UAC", className="section-title"),
                html.Div(id="obs-seguranca-rdp"),
            ]),
            html.Div(className="panel neon-purple", children=[
                html.P("USUÁRIOS LOCAIS HABILITADOS", className="section-title"),
                html.Div(id="obs-seguranca-usuarios"),
            ]),
        ]),

        # ── Hardware v4 — Temperatura CPU + Bateria/Rede ─────────────────────
        html.Div(className="grid-2", style={"marginBottom": "1rem"}, children=[
            html.Div(className="panel neon-cyan", children=[
                html.P("TEMPERATURA CPU & REBOOT INESPERADO", className="section-title"),
                html.Div(id="obs-hardware-temp"),
            ]),
            html.Div(className="panel neon-cyan", children=[
                html.P("BATERIA & TIPO DE REDE", className="section-title"),
                html.Div(id="obs-hardware-bateria"),
            ]),
        ]),

        # ── Log de Eventos Windows (tabela completa) ──────────────────────────
        html.Div(className="panel neon-purple", style={"marginBottom": "1rem"}, children=[
            html.P("LOG DE EVENTOS WINDOWS — ULTIMAS 24H", className="section-title"),
            html.Div(id="obs-eventos-tabela"),
        ]),
    ])


# ── Callback principal ────────────────────────────────────────────────────────
@callback(
    [Output("obs-kpis",              "children"),
     Output("obs-health-ranking",    "children"),
     Output("obs-disco-previsao",    "children"),
     Output("obs-eventos-stats",     "children"),
     Output("obs-anomalias",         "children"),
     Output("obs-sla-chart",         "figure"),
     Output("obs-eventos-tabela",    "children"),
     Output("obs-seguranca-fw",      "children"),
     Output("obs-seguranca-admins",  "children"),
     Output("obs-hardware-gpu",      "children"),
     Output("obs-hardware-discos",   "children"),
     Output("obs-seguranca-rdp",     "children"),
     Output("obs-seguranca-usuarios","children"),
     Output("obs-hardware-temp",     "children"),
     Output("obs-hardware-bateria",  "children")],
    Input("obs-interval", "n_intervals"),
    State("session-store", "data"),
)
def atualizar_obs(n, session):
    sem_dados = html.Div("Sem dados.", style={"color": "#475569",
                                              "fontSize": ".75rem", "padding": ".5rem 0"})
    vazio_fig = _fig_vazio("Sem dados")
    sem = ([], sem_dados, sem_dados, sem_dados, sem_dados, vazio_fig,
           sem_dados, sem_dados, sem_dados, sem_dados, sem_dados,
           sem_dados, sem_dados, sem_dados, sem_dados)

    if not session or not session.get("authenticated"):
        return sem

    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("SELECT * FROM maquinas_v6 ORDER BY hostname")
                rows = c.fetchall()
                cols = [d[0] for d in c.description]
    except Exception:
        return sem

    if not rows:
        return sem

    agora = datetime.now()
    df = pd.DataFrame(rows, columns=cols)
    df["diff"] = (agora - df["ultima_atualizacao"]).dt.total_seconds()
    df["health_score"] = df.apply(lambda r: calcular_health_score(r.to_dict()), axis=1)

    ativos   = int((df["diff"] <= 720).sum())
    offline  = int((df["diff"] > 720).sum())
    criticos = int((df["health_score"] < 40).sum())
    em_alerta = int((df["health_score"] < 60).sum())
    med_h = round(df[df["diff"] <= 720]["health_score"].mean(), 1) if ativos > 0 else 0

    # Defender sem proteção
    sem_av = 0
    if "defender_ativo" in df.columns:
        sem_av = int((df["defender_ativo"] == False).sum())  # noqa: E712

    kpis = [
        kpi_card("TOTAL",        len(df),  "#3b82f6", "fa-solid fa-server"),
        kpi_card("ONLINE",       ativos,   "#10b981", "fa-solid fa-circle-check"),
        kpi_card("OFFLINE",      offline,  "#64748b", "fa-solid fa-circle-xmark"),
        kpi_card("SAUDE MEDIA",  f"{med_h}", "#06b6d4", "fa-solid fa-heart-pulse"),
        kpi_card("CRITICOS",     criticos, "#ef4444", "fa-solid fa-triangle-exclamation",
                 pulse=criticos > 0),
        kpi_card("SEM ANTIVIRUS", sem_av,  "#a855f7", "fa-solid fa-shield-halved",
                 pulse=sem_av > 0),
    ]

    # Health ranking (piores primeiro)
    df_rank = df[df["diff"] <= 720].sort_values("health_score").head(15)
    health_comp = _render_health_ranking(df_rank)

    # Previsão de disco
    try:
        with get_conn() as conn:
            previsoes = []
            for h in df[df["diff"] <= 720]["hostname"].tolist():
                p = prever_disco_cheio(h, conn)
                if p:
                    previsoes.append({"hostname": h, **p})
        previsoes.sort(key=lambda x: x["dias"])
        disco_comp = _render_disco_previsao(previsoes)
    except Exception:
        disco_comp = sem_dados

    # Eventos Windows
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("""
                    SELECT nivel, COUNT(*) FROM eventos_windows
                    WHERE timestamp > NOW() - INTERVAL '24 hours'
                    GROUP BY nivel ORDER BY COUNT(*) DESC
                """)
                ev_stats = c.fetchall()

                c.execute("""
                    SELECT hostname, timestamp, nivel, fonte, event_id, mensagem
                    FROM eventos_windows
                    WHERE timestamp > NOW() - INTERVAL '24 hours'
                    ORDER BY timestamp DESC LIMIT 200
                """)
                ev_rows = c.fetchall()
        ev_stats_comp  = _render_eventos_stats(ev_stats)
        ev_tabela_comp = _render_eventos_tabela(ev_rows)
    except Exception:
        ev_stats_comp  = sem_dados
        ev_tabela_comp = sem_dados

    # Anomalias
    try:
        with get_conn() as conn:
            anomalias = []
            for h in df[df["diff"] <= 720]["hostname"].tolist()[:25]:
                for a in detectar_anomalias(h, conn):
                    anomalias.append({"hostname": h, **a})
        anomalias_comp = _render_anomalias(anomalias)
    except Exception:
        anomalias_comp = sem_dados

    # SLA chart
    try:
        with get_conn() as conn:
            slas = []
            for h in df["hostname"].tolist()[:35]:
                slas.append({"hostname": h, "sla": calcular_sla(h, conn, 7)})
        sla_fig = _render_sla_chart(slas)
    except Exception:
        sla_fig = vazio_fig

    # Segurança — firewall e admins
    seg_fw_comp     = _render_seguranca_fw(df)
    seg_admins_comp = _render_seguranca_admins(df)

    # Hardware — GPU e discos físicos
    hw_gpu_comp    = _render_hardware_gpu(df)
    hw_discos_comp = _render_hardware_discos(df)

    # Segurança v4 — RDP, UAC, usuários locais
    seg_rdp_comp      = _render_seguranca_rdp(df)
    seg_usuarios_comp = _render_seguranca_usuarios(df)

    # Hardware v4 — temperatura, reboot, bateria, rede
    hw_temp_comp    = _render_hardware_temp(df)
    hw_bateria_comp = _render_hardware_bateria(df)

    return (kpis, health_comp, disco_comp, ev_stats_comp, anomalias_comp, sla_fig,
            ev_tabela_comp, seg_fw_comp, seg_admins_comp, hw_gpu_comp, hw_discos_comp,
            seg_rdp_comp, seg_usuarios_comp, hw_temp_comp, hw_bateria_comp)


# ── Callback Gantt ────────────────────────────────────────────────────────────
@callback(
    Output("obs-gantt", "figure"),
    [Input("obs-gantt-dias",  "value"),
     Input("obs-interval",    "n_intervals")],
    State("session-store", "data"),
)
def atualizar_gantt(dias, n, session):
    if not session or not session.get("authenticated"):
        return _fig_vazio("Faça login para visualizar")

    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("SELECT hostname FROM maquinas_v6 ORDER BY hostname LIMIT 35")
                hostnames = [r[0] for r in c.fetchall()]

            segs = []
            for h in hostnames:
                segs.extend(reconstruir_timeline(h, conn, dias=int(dias)))
    except Exception:
        return _fig_vazio("Erro ao carregar dados")

    if not segs:
        return _fig_vazio("Sem histórico no período selecionado")

    df_g = pd.DataFrame(segs)
    fig = px.timeline(
        df_g, x_start="inicio", x_end="fim", y="hostname",
        color="status",
        color_discrete_map={"Online": "#10b981", "Offline": "#ef4444"},
    )
    fig.update_yaxes(autorange="reversed", title="", tickfont=dict(size=10))
    fig.update_xaxes(title="")
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font_color="#94a3b8",
        margin=dict(l=10, r=10, t=10, b=10),
        legend=dict(orientation="h", yanchor="bottom", y=1.01,
                    title_text="", font=dict(color="#94a3b8")),
    )
    fig.update_traces(marker_line_width=0)
    return fig


# ── Helpers de renderização ───────────────────────────────────────────────────

def _render_health_ranking(df: pd.DataFrame):
    if df.empty:
        return html.Div("Todas as maquinas com saude acima do limiar.",
                        style={"color": "#34d399", "fontSize": ".75rem"})
    itens = []
    for _, row in df.iterrows():
        sc  = float(row.get("health_score") or 0)
        cor = health_cor(sc)
        itens.append(html.Div(
            style={"display": "flex", "alignItems": "center", "gap": ".6rem",
                   "padding": ".3rem 0", "borderBottom": "1px solid rgba(6,182,212,.06)"},
            children=[
                html.Div(f"{int(sc)}", style={
                    "width": "44px", "height": "22px", "borderRadius": "4px",
                    "background": cor, "display": "flex", "alignItems": "center",
                    "justifyContent": "center", "flexShrink": 0,
                    "fontSize": ".65rem", "fontWeight": "800", "color": "#fff",
                }),
                html.Span(row["hostname"],
                          style={"fontSize": ".7rem", "color": "#94a3b8", "flex": 1,
                                 "overflow": "hidden", "textOverflow": "ellipsis",
                                 "whiteSpace": "nowrap"}),
                html.Span(
                    f"CPU {row.get('cpu', 0):.0f}% · RAM {row.get('ram', 0):.0f}% · Disco {row.get('disco_c', 0):.0f}%",
                    style={"fontSize": ".6rem", "color": "#475569", "whiteSpace": "nowrap"}),
            ],
        ))
    return html.Div(itens, style={"maxHeight": "320px", "overflowY": "auto"})


def _render_disco_previsao(previsoes: list):
    if not previsoes:
        return html.Div("Nenhuma previsao critica nos proximos 365 dias.",
                        style={"color": "#34d399", "fontSize": ".75rem"})
    itens = []
    for p in previsoes[:15]:
        cor = "#ef4444" if p["dias"] <= 7 else ("#f59e0b" if p["dias"] <= 30 else "#06b6d4")
        itens.append(html.Div(
            style={"display": "flex", "alignItems": "center", "gap": ".6rem",
                   "padding": ".3rem 0", "borderBottom": "1px solid rgba(168,85,247,.06)"},
            children=[
                html.Div(f"{p['dias']}d", style={
                    "minWidth": "48px", "padding": ".2rem .3rem", "borderRadius": "4px",
                    "background": cor, "textAlign": "center",
                    "fontSize": ".7rem", "fontWeight": "800", "color": "#fff",
                }),
                html.Span(p["hostname"],
                          style={"fontSize": ".7rem", "color": "#94a3b8", "flex": 1,
                                 "overflow": "hidden", "textOverflow": "ellipsis",
                                 "whiteSpace": "nowrap"}),
                html.Span(f"{p['atual']}% · +{p['taxa_dia']}%/dia",
                          style={"fontSize": ".6rem", "color": "#475569", "whiteSpace": "nowrap"}),
            ],
        ))
    return html.Div(itens, style={"maxHeight": "320px", "overflowY": "auto"})


def _render_eventos_stats(ev_stats: list):
    if not ev_stats:
        return html.Div("Nenhum evento registrado nas ultimas 24h.",
                        style={"color": "#34d399", "fontSize": ".75rem"})
    cores = {"Error": "#f87171", "Critical": "#ef4444", "Warning": "#fbbf24",
             "Information": "#06b6d4"}
    itens = []
    for nivel, total in ev_stats:
        cor = cores.get(str(nivel), "#94a3b8")
        itens.append(html.Div(
            style={"display": "flex", "justifyContent": "space-between",
                   "padding": ".3rem 0", "borderBottom": "1px solid rgba(168,85,247,.06)"},
            children=[
                html.Span(str(nivel),  style={"fontSize": ".7rem", "color": cor, "fontWeight": "700"}),
                html.Span(str(total), style={"fontSize": ".7rem", "color": "#94a3b8",
                                             "fontWeight": "700"}),
            ],
        ))
    return html.Div(itens)


def _render_anomalias(anomalias: list):
    if not anomalias:
        return html.Div("Nenhuma anomalia detectada no momento.",
                        style={"color": "#34d399", "fontSize": ".75rem"})
    itens = []
    for a in anomalias[:12]:
        itens.append(html.Div(
            style={"display": "flex", "alignItems": "flex-start", "gap": ".5rem",
                   "padding": ".3rem 0", "borderBottom": "1px solid rgba(6,182,212,.06)"},
            children=[
                html.I(className="fa-solid fa-triangle-exclamation",
                       style={"color": "#f59e0b", "fontSize": ".8rem", "marginTop": "2px"}),
                html.Div([
                    html.Span(f"{a['hostname']} — {a['metrica']}",
                              style={"fontSize": ".7rem", "color": "#fbbf24",
                                     "fontWeight": "700", "display": "block"}),
                    html.Span(
                        f"Atual: {a['valor']}% | Media historica: {a['media']}% | Z-score: {a['z_score']}",
                        style={"fontSize": ".6rem", "color": "#64748b"}),
                ]),
            ],
        ))
    return html.Div(itens, style={"maxHeight": "280px", "overflowY": "auto"})


def _render_eventos_tabela(rows: list):
    if not rows:
        return html.Div(
            "Nenhum evento Windows registrado. Atualize o agente C# para enviar eventos.",
            style={"color": "#475569", "fontSize": ".75rem", "padding": ".75rem 0",
                   "fontStyle": "italic"},
        )
    records = []
    for hostname, ts, nivel, fonte, event_id, mensagem in rows:
        records.append({
            "DATA/HORA": ts.strftime("%d/%m %H:%M:%S") if ts else "-",
            "HOSTNAME":  hostname or "-",
            "NIVEL":     str(nivel or "-"),
            "FONTE":     str(fonte or "-"),
            "EVENT ID":  str(event_id) if event_id else "-",
            "MENSAGEM":  (str(mensagem) or "")[:150],
        })

    return dash_table.DataTable(
        data=records,
        columns=[{"name": k, "id": k} for k in records[0].keys()],
        filter_action="native", sort_action="native",
        page_size=20,
        style_table={"overflowX": "auto", "width": "100%"},
        style_cell={"textAlign": "left", "padding": "7px 10px", "fontSize": "11px",
                    "backgroundColor": "#090d16", "color": "#94a3b8",
                    "border": "1px solid rgba(168,85,247,.05)",
                    "whiteSpace": "nowrap", "overflow": "hidden",
                    "textOverflow": "ellipsis", "maxWidth": "220px"},
        style_header={"backgroundColor": "#020617", "color": "#a78bfa",
                      "fontWeight": "bold", "border": "1px solid rgba(168,85,247,.15)"},
        style_data_conditional=[
            {"if": {"filter_query": '{NIVEL} = "Error"'},    "color": "#f87171"},
            {"if": {"filter_query": '{NIVEL} = "Critical"'}, "color": "#ef4444", "fontWeight": "800"},
            {"if": {"filter_query": '{NIVEL} = "Warning"'},  "color": "#fbbf24"},
        ],
    )


def _render_sla_chart(slas: list):
    if not slas:
        return _fig_vazio("Sem dados de SLA")
    df = pd.DataFrame(slas).sort_values("sla")
    df["cor"] = df["sla"].apply(
        lambda x: "#ef4444" if x < 80 else ("#f59e0b" if x < 95 else "#10b981")
    )
    fig = go.Figure(go.Bar(
        x=df["sla"], y=df["hostname"], orientation="h",
        marker_color=df["cor"].tolist(),
        text=df["sla"].apply(lambda x: f"{x}%"),
        textposition="inside",
    ))
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font_color="#94a3b8",
        margin=dict(l=10, r=10, t=10, b=10),
        xaxis=dict(range=[0, 105], gridcolor="rgba(6,182,212,.06)", ticksuffix="%"),
        yaxis=dict(autorange="reversed", gridcolor="rgba(0,0,0,0)", tickfont=dict(size=10)),
    )
    return fig


def _render_seguranca_fw(df: pd.DataFrame):
    rows = []
    tem_v3 = False
    for _, r in df.iterrows():
        host = r["hostname"]

        # ── Firewall ──────────────────────────────────────────────────────────
        fw_d = r.get("firewall_domain")
        fw_p = r.get("firewall_private")
        fw_b = r.get("firewall_public")
        # Todos None → dado não disponível (agente antigo)
        if fw_d is None and fw_p is None and fw_b is None:
            fw_txt, fw_cor = "N/D", "#475569"
        elif fw_d is False or fw_p is False or fw_b is False:
            perfis = [n for n, v in [("D", fw_d), ("P", fw_p), ("Pub", fw_b)] if v is False]
            fw_txt, fw_cor = f"✗ ({','.join(perfis)})", "#ef4444"
        else:
            fw_txt, fw_cor = "✓", "#10b981"
            tem_v3 = True

        # ── Defender ──────────────────────────────────────────────────────────
        def_ativo = r.get("defender_ativo")
        if def_ativo is True:
            av_txt, av_cor = "ON", "#10b981"
        elif def_ativo is False:
            av_txt, av_cor = "OFF", "#ef4444"
        else:
            av_txt, av_cor = "N/D", "#475569"

        def_def  = r.get("defender_ultima_def") or "—"
        def_scan = r.get("defender_scan_dias")
        if def_scan is None:
            scan_txt, scan_cor = "—", "#475569"
        elif def_scan > 7:
            scan_txt, scan_cor = f"{def_scan}d", "#ef4444"
        else:
            scan_txt, scan_cor = f"{def_scan}d", "#10b981"
            tem_v3 = True

        # ── BitLocker ─────────────────────────────────────────────────────────
        bl = r.get("bitlocker_ativo")
        if bl is True:
            bl_txt, bl_cor = "Ativo", "#10b981"
        elif bl is False:
            bl_txt, bl_cor = "Inativo", "#f59e0b"
        else:
            bl_txt, bl_cor = "N/D", "#475569"

        rows.append(html.Tr([
            html.Td(host,     style=_tc()),
            html.Td(fw_txt,   style=_tc("center", fw_cor,   bold=True)),
            html.Td(av_txt,   style=_tc("center", av_cor,   bold=True)),
            html.Td(def_def,  style=_tc("center", "#94a3b8")),
            html.Td(scan_txt, style=_tc("center", scan_cor, bold=def_scan is not None)),
            html.Td(bl_txt,   style=_tc("center", bl_cor,   bold=True)),
        ]))

    aviso_v3 = _aviso_agente_v3() if not tem_v3 else None
    tabela = html.Table(
        style={"width": "100%", "borderCollapse": "collapse"},
        children=[
            html.Thead(html.Tr([
                html.Th("Máquina",     style=_th2()),
                html.Th("Firewall",    style=_th2("center")),
                html.Th("Antivírus",   style=_th2("center")),
                html.Th("Def. atualiz.", style=_th2("center")),
                html.Th("Último Scan", style=_th2("center")),
                html.Th("BitLocker",   style=_th2("center")),
            ])),
            html.Tbody(rows),
        ]
    ) if rows else html.Div("Nenhuma máquina encontrada.",
                            style={"color": "#475569", "fontSize": ".75rem"})
    return html.Div([aviso_v3, tabela] if aviso_v3 else [tabela])


def _render_seguranca_admins(df: pd.DataFrame):
    import json as _json
    itens = []
    maquinas_sem_dado = []
    for _, r in df.iterrows():
        raw = r.get("admins_locais")
        # None/NaN = no v3 agent; [] = agent ran but returned empty list
        is_none = raw is None or (isinstance(raw, float) and pd.isna(raw))
        if is_none:
            maquinas_sem_dado.append(r["hostname"])
            continue
        try:
            admins = _json.loads(raw) if isinstance(raw, str) else (raw if isinstance(raw, list) else [])
        except Exception:
            maquinas_sem_dado.append(r["hostname"])
            continue
        alerta = len(admins) > 2 or len(admins) == 0
        itens.append(html.Div(
            style={"padding": ".35rem .5rem", "marginBottom": ".3rem",
                   "borderRadius": ".3rem",
                   "background": "rgba(239,68,68,.06)" if alerta else "rgba(30,58,95,.3)",
                   "border": f"1px solid {'rgba(239,68,68,.2)' if alerta else 'rgba(30,58,95,.5)'}"},
            children=[
                html.Div([
                    html.Span(r["hostname"],
                              style={"fontSize": ".7rem", "color": "#22d3ee",
                                     "fontWeight": "700", "fontFamily": "monospace"}),
                    html.Span(
                    f" — {len(admins)} conta(s)" if admins else " — nenhum admin detectado",
                    style={"fontSize": ".65rem",
                           "color": "#ef4444" if alerta else "#64748b"}),
                ]),
                html.Div(
                    ", ".join(str(a) for a in admins[:8]) if admins else "Sem administradores na lista (verificar manualmente)",
                    style={"fontSize": ".65rem", "color": "#94a3b8",
                           "marginTop": ".15rem", "fontFamily": "monospace"}),
            ]
        ))

    children = []
    if itens:
        children.append(html.Div(itens, style={"maxHeight": "260px", "overflowY": "auto",
                                               "marginBottom": ".5rem"}))
    if maquinas_sem_dado:
        children.append(_aviso_agente_v3(maquinas_sem_dado))
    return html.Div(children) if children else \
           html.Div("Nenhuma máquina encontrada.", style={"color": "#475569", "fontSize": ".75rem"})


def _render_hardware_gpu(df: pd.DataFrame):
    rows = []
    sem_dado = []
    for _, r in df.iterrows():
        gpu  = r.get("gpu_modelo")
        bios = r.get("bios_versao")
        # Sem nenhum campo v3 → máquina ainda com agente antigo
        if not gpu and not bios:
            sem_dado.append(r["hostname"])
            continue
        mem   = r.get("gpu_memoria_mb")
        mem_t = f"{mem} MB" if mem else "N/D"
        idle  = r.get("idle_minutos")
        idle_t = f"{idle} min" if idle is not None and idle >= 0 else "N/D"
        bloq  = r.get("tela_bloqueada")
        if bloq is True:
            bloq_t, bloq_cor = "Sim", "#f59e0b"
        elif bloq is False:
            bloq_t, bloq_cor = "Não", "#10b981"
        else:
            bloq_t, bloq_cor = "N/D", "#475569"
        gpu_s  = str(gpu or "N/D")
        bios_s = str(bios or "N/D")
        rows.append(html.Tr([
            html.Td(r["hostname"], style=_tc()),
            html.Td(gpu_s[:30] + "…" if len(gpu_s) > 30 else gpu_s, style=_tc()),
            html.Td(mem_t,  style=_tc("right")),
            html.Td(bios_s[:20] + "…" if len(bios_s) > 20 else bios_s, style=_tc()),
            html.Td(idle_t, style=_tc("center")),
            html.Td(bloq_t, style=_tc("center", bloq_cor, bold=bloq is not None)),
        ]))

    children = []
    if rows:
        children.append(html.Table(
            style={"width": "100%", "borderCollapse": "collapse"},
            children=[
                html.Thead(html.Tr([
                    html.Th("Máquina", style=_th2()),
                    html.Th("GPU",     style=_th2()),
                    html.Th("VRAM",    style=_th2("right")),
                    html.Th("BIOS",    style=_th2()),
                    html.Th("Idle",    style=_th2("center")),
                    html.Th("Bloq.",   style=_th2("center")),
                ])),
                html.Tbody(rows),
            ]
        ))
    if sem_dado:
        children.append(_aviso_agente_v3(sem_dado))
    return html.Div(children) if children else \
           html.Div("Nenhuma máquina encontrada.", style={"color": "#475569", "fontSize": ".75rem"})


def _render_hardware_discos(df: pd.DataFrame):
    import json as _json
    itens = []
    sem_dado = []
    for _, r in df.iterrows():
        smart_ok = r.get("smart_ok")
        raw = r.get("discos_fisicos")
        if not raw:
            sem_dado.append(r["hostname"])
            continue
        try:
            discos = _json.loads(raw) if isinstance(raw, str) else (raw or [])
        except Exception:
            sem_dado.append(r["hostname"])
            continue
        if not discos:
            sem_dado.append(r["hostname"])
            continue
        if smart_ok is False:
            smart_cor, smart_txt = "#ef4444", "FALHA PREVISTA"
        elif smart_ok is True:
            smart_cor, smart_txt = "#10b981", "OK"
        else:
            smart_cor, smart_txt = "#475569", "N/D"
        itens.append(html.Div(
            style={"padding": ".35rem .5rem", "marginBottom": ".3rem", "borderRadius": ".3rem",
                   "background": "rgba(239,68,68,.08)" if smart_ok is False else "rgba(16,185,129,.04)",
                   "border": f"1px solid {'rgba(239,68,68,.3)' if smart_ok is False else 'rgba(16,185,129,.1)'}"},
            children=[
                html.Div([
                    html.Span(r["hostname"],
                              style={"fontSize": ".7rem", "color": "#22d3ee",
                                     "fontWeight": "700", "fontFamily": "monospace"}),
                    html.Span(f"  S.M.A.R.T.: {smart_txt}",
                              style={"fontSize": ".65rem", "color": smart_cor,
                                     "fontWeight": "700"}),
                ]),
                html.Div([
                    html.Span(
                        f"{str(d.get('modelo','?'))[:24]} · {d.get('tipo','?')} · {d.get('tamanho_gb', 0)} GB",
                        style={"fontSize": ".65rem", "color": "#94a3b8",
                               "display": "block", "fontFamily": "monospace"}
                    ) for d in (discos if isinstance(discos, list) else [])[:4]
                ], style={"marginTop": ".2rem"}),
            ]
        ))

    children = []
    if itens:
        children.append(html.Div(itens, style={"maxHeight": "260px", "overflowY": "auto",
                                               "marginBottom": ".5rem"}))
    if sem_dado:
        children.append(_aviso_agente_v3(sem_dado))
    return html.Div(children) if children else \
           html.Div("Nenhuma máquina encontrada.", style={"color": "#475569", "fontSize": ".75rem"})


def _render_seguranca_rdp(df: pd.DataFrame):
    rows = []
    sem_dado = []
    for _, r in df.iterrows():
        rdp = r.get("rdp_habilitado")
        uac = r.get("uac_habilitado")
        rbt = r.get("reboot_inesperado")
        if rdp is None and uac is None and rbt is None:
            sem_dado.append(r["hostname"])
            continue
        if rdp is True:
            rdp_t, rdp_c = "✓ ATIVO", "#ef4444"
        elif rdp is False:
            rdp_t, rdp_c = "✗ Desativ.", "#10b981"
        else:
            rdp_t, rdp_c = "N/D", "#475569"
        if uac is True:
            uac_t, uac_c = "✓ Ativo", "#10b981"
        elif uac is False:
            uac_t, uac_c = "✗ DESATIV.", "#ef4444"
        else:
            uac_t, uac_c = "N/D", "#475569"
        if rbt is True:
            rbt_t, rbt_c = "Sim", "#f59e0b"
        elif rbt is False:
            rbt_t, rbt_c = "Não", "#10b981"
        else:
            rbt_t, rbt_c = "N/D", "#475569"
        rows.append(html.Tr([
            html.Td(r["hostname"], style=_tc()),
            html.Td(rdp_t, style=_tc("center", rdp_c, bold=rdp is not None)),
            html.Td(uac_t, style=_tc("center", uac_c, bold=uac is not None)),
            html.Td(rbt_t, style=_tc("center", rbt_c, bold=rbt is True)),
        ]))
    children = []
    if rows:
        children.append(html.Table(
            style={"width": "100%", "borderCollapse": "collapse"},
            children=[
                html.Thead(html.Tr([
                    html.Th("Máquina",       style=_th2()),
                    html.Th("RDP",           style=_th2("center")),
                    html.Th("UAC",           style=_th2("center")),
                    html.Th("Reboot Inesp.", style=_th2("center")),
                ])),
                html.Tbody(rows),
            ]
        ))
    if sem_dado:
        children.append(_aviso_agente_v3(sem_dado))
    return html.Div(children) if children else \
           html.Div("Nenhuma máquina encontrada.", style={"color": "#475569", "fontSize": ".75rem"})


def _render_seguranca_usuarios(df: pd.DataFrame):
    import json as _json
    itens = []
    sem_dado = []
    for _, r in df.iterrows():
        raw = r.get("usuarios_locais")
        is_none = raw is None or (isinstance(raw, float) and pd.isna(raw))
        if is_none:
            sem_dado.append(r["hostname"])
            continue
        try:
            usuarios = _json.loads(raw) if isinstance(raw, str) else (raw if isinstance(raw, list) else [])
        except Exception:
            sem_dado.append(r["hostname"])
            continue
        alerta = len(usuarios) > 3
        itens.append(html.Div(
            style={"padding": ".35rem .5rem", "marginBottom": ".3rem",
                   "borderRadius": ".3rem",
                   "background": "rgba(239,68,68,.06)" if alerta else "rgba(30,58,95,.3)",
                   "border": f"1px solid {'rgba(239,68,68,.2)' if alerta else 'rgba(30,58,95,.5)'}"},
            children=[
                html.Div([
                    html.Span(r["hostname"],
                              style={"fontSize": ".7rem", "color": "#22d3ee",
                                     "fontWeight": "700", "fontFamily": "monospace"}),
                    html.Span(
                        f" — {len(usuarios)} conta(s)" if usuarios else " — nenhuma conta detectada",
                        style={"fontSize": ".65rem",
                               "color": "#ef4444" if alerta else "#64748b"}),
                ]),
                html.Div(
                    ", ".join(str(u) for u in usuarios[:8]) if usuarios else "—",
                    style={"fontSize": ".65rem", "color": "#94a3b8",
                           "marginTop": ".15rem", "fontFamily": "monospace"}),
            ]
        ))
    children = []
    if itens:
        children.append(html.Div(itens, style={"maxHeight": "260px", "overflowY": "auto",
                                               "marginBottom": ".5rem"}))
    if sem_dado:
        children.append(_aviso_agente_v3(sem_dado))
    return html.Div(children) if children else \
           html.Div("Nenhuma máquina encontrada.", style={"color": "#475569", "fontSize": ".75rem"})


def _render_hardware_temp(df: pd.DataFrame):
    rows = []
    for _, r in df.iterrows():
        temp = r.get("temperatura_cpu")
        temp_null = temp is None or (isinstance(temp, float) and pd.isna(temp))
        if temp_null or int(temp or 0) < 0:
            temp_t, temp_c = "N/D", "#475569"
        elif temp < 60:
            temp_t, temp_c = f"{int(temp)}°C", "#10b981"
        elif temp < 80:
            temp_t, temp_c = f"{int(temp)}°C", "#f59e0b"
        elif temp < 90:
            temp_t, temp_c = f"{int(temp)}°C", "#f97316"
        else:
            temp_t, temp_c = f"{int(temp)}°C", "#ef4444"
        rbt = r.get("reboot_inesperado")
        if rbt is True:
            rbt_t, rbt_c = "Sim", "#f59e0b"
        elif rbt is False:
            rbt_t, rbt_c = "Não", "#10b981"
        else:
            rbt_t, rbt_c = "N/D", "#475569"
        rows.append(html.Tr([
            html.Td(r["hostname"], style=_tc()),
            html.Td(temp_t, style=_tc("center", temp_c, bold=not temp_null)),
            html.Td(rbt_t,  style=_tc("center", rbt_c,  bold=rbt is not None)),
        ]))
    if not rows:
        return html.Div("Nenhuma máquina encontrada.", style={"color": "#475569", "fontSize": ".75rem"})
    return html.Table(
        style={"width": "100%", "borderCollapse": "collapse"},
        children=[
            html.Thead(html.Tr([
                html.Th("Máquina",         style=_th2()),
                html.Th("Temperatura CPU", style=_th2("center")),
                html.Th("Reboot Inesp.",   style=_th2("center")),
            ])),
            html.Tbody(rows),
        ]
    )


def _render_hardware_bateria(df: pd.DataFrame):
    rows = []
    sem_dado = []
    for _, r in df.iterrows():
        rede_tp = r.get("rede_tipo")
        is_none = rede_tp is None or (isinstance(rede_tp, float) and pd.isna(rede_tp))
        if is_none:
            sem_dado.append(r["hostname"])
            continue
        if rede_tp == "Wi-Fi":
            rede_t, rede_c = "Wi-Fi", "#f59e0b"
        elif rede_tp == "Ethernet":
            rede_t, rede_c = "Ethernet", "#10b981"
        else:
            rede_t, rede_c = rede_tp or "N/D", "#475569"
        tem_bat = r.get("tem_bateria")
        if tem_bat is True:
            bat_pct  = r.get("battery_status")
            bat_desc = r.get("bateria_descricao") or ""
            bat_pct_v = int(bat_pct) if bat_pct is not None else None
            bat_t = f"{bat_pct_v}% — {bat_desc}" if bat_pct_v is not None else bat_desc or "N/D"
            bat_c = "#ef4444" if (bat_pct_v is not None and bat_pct_v < 20) else "#10b981"
        elif tem_bat is False:
            bat_t, bat_c = "Desktop/Servidor", "#475569"
        else:
            bat_t, bat_c = "N/D", "#475569"
        rows.append(html.Tr([
            html.Td(r["hostname"], style=_tc()),
            html.Td(rede_t, style=_tc("center", rede_c, bold=True)),
            html.Td(bat_t,  style=_tc("center", bat_c)),
        ]))
    children = []
    if rows:
        children.append(html.Table(
            style={"width": "100%", "borderCollapse": "collapse"},
            children=[
                html.Thead(html.Tr([
                    html.Th("Máquina",   style=_th2()),
                    html.Th("Rede",      style=_th2("center")),
                    html.Th("Bateria",   style=_th2("center")),
                ])),
                html.Tbody(rows),
            ]
        ))
    if sem_dado:
        children.append(_aviso_agente_v3(sem_dado))
    return html.Div(children) if children else \
           html.Div("Nenhuma máquina encontrada.", style={"color": "#475569", "fontSize": ".75rem"})


def _aviso_agente_v3(maquinas: list | None = None) -> html.Div:
    lista = f": {', '.join(maquinas[:5])}" if maquinas else ""
    sufixo = "..." if maquinas and len(maquinas) > 5 else ""
    return html.Div(
        style={"display": "flex", "alignItems": "flex-start", "gap": ".5rem",
               "padding": ".45rem .65rem", "borderRadius": ".35rem", "marginTop": ".4rem",
               "background": "rgba(245,158,11,.07)",
               "border": "1px solid rgba(245,158,11,.25)"},
        children=[
            html.I(className="fa-solid fa-triangle-exclamation",
                   style={"color": "#f59e0b", "fontSize": ".85rem", "marginTop": ".1rem",
                          "flexShrink": "0"}),
            html.Div([
                html.Span("Agente v3 não instalado",
                          style={"color": "#f59e0b", "fontSize": ".7rem", "fontWeight": "700"}),
                html.Span(f"{lista}{sufixo}",
                          style={"color": "#94a3b8", "fontSize": ".65rem",
                                 "fontFamily": "monospace"}),
                html.Div("Execute INSTALAR-como-admin.bat como Administrador nas máquinas acima "
                         "para ativar coleta de GPU, discos, admins, firewall e S.M.A.R.T.",
                         style={"color": "#64748b", "fontSize": ".65rem", "marginTop": ".15rem"}),
            ]),
        ]
    )


def _th2(align: str = "left") -> dict:
    return {"padding": ".3rem .5rem", "fontSize": ".6rem", "fontWeight": "800",
            "color": "#22d3ee", "letterSpacing": ".08em", "textTransform": "uppercase",
            "textAlign": align, "borderBottom": "1px solid #1e3a5f"}


def _tc(align: str = "left", color: str = "#94a3b8", bold: bool = False) -> dict:
    return {"padding": ".3rem .5rem", "fontSize": ".7rem", "color": color,
            "textAlign": align, "borderBottom": "1px solid rgba(30,58,95,.4)",
            "fontWeight": "700" if bold else "400", "fontFamily": "monospace"}


def _fig_vazio(titulo: str):
    fig = px.scatter(title=titulo)
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font_color="#94a3b8", title_font_color="#475569",
        margin=dict(l=10, r=10, t=40, b=10),
    )
    return fig
