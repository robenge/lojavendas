import dash
import pandas as pd
import plotly.express as px
from dash import Input, Output, State, callback, dcc, html
from datetime import datetime, timedelta

from dashboard.components import page_header
from database import get_conn

dash.register_page(__name__, path="/historico", name="Historico", title="Neon — Historico")


def layout(**kwargs):
    return html.Div(className="page-content", children=[
        page_header("HISTORICO DE METRICAS", "Analise de tendencias por periodo",
                    "fa-solid fa-chart-line"),

        dcc.Interval(id="hist-interval", interval=30_000, n_intervals=0),

        html.Div(className="panel neon-cyan", style={"marginBottom": "1rem"}, children=[
            html.Div(className="grid-3", children=[
                html.Div([
                    html.Label("MAQUINA", className="login-label"),
                    dcc.Dropdown(id="hist-hostname", placeholder="Selecione...",
                                 style={"color": "#1e293b"}),
                ]),
                html.Div([
                    html.Label("METRICA", className="login-label"),
                    dcc.Dropdown(
                        id="hist-metrica",
                        options=[
                            {"label": "CPU + RAM", "value": "cpu_ram"},
                            {"label": "Disco C + D", "value": "disco"},
                            {"label": "Todas", "value": "todas"},
                        ],
                        value="cpu_ram", clearable=False,
                        style={"color": "#1e293b"},
                    ),
                ]),
                html.Div([
                    html.Label("PERIODO", className="login-label"),
                    dcc.Dropdown(
                        id="hist-periodo",
                        options=[
                            {"label": "Ultima hora",  "value": "1h"},
                            {"label": "Ultimas 6h",   "value": "6h"},
                            {"label": "Ultimas 24h",  "value": "24h"},
                            {"label": "Ultimos 3 dias","value": "3d"},
                            {"label": "Ultimos 7 dias","value": "7d"},
                        ],
                        value="24h", clearable=False,
                        style={"color": "#1e293b"},
                    ),
                ]),
            ]),
        ]),

        html.Div(className="panel neon-cyan", children=[
            dcc.Graph(id="hist-grafico", config={"displayModeBar": True},
                      style={"height": "400px"}),
        ]),

        html.Div(className="grid-2", children=[
            html.Div(className="panel neon-cyan", children=[
                html.P("ESTATISTICAS DO PERIODO", className="section-title"),
                html.Div(id="hist-stats"),
            ]),
            html.Div(className="panel neon-purple", children=[
                html.P("MEDIA POR HORA", className="section-title"),
                dcc.Graph(id="hist-heatmap", config={"displayModeBar": False},
                          style={"height": "220px"}),
            ]),
        ]),
    ])


@callback(
    Output("hist-hostname", "options"),
    Input("hist-interval", "n_intervals"),
    State("session-store", "data"),
)
def carregar_hosts(n, session):
    if not session or not session.get("authenticated"):
        return []
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("SELECT DISTINCT hostname FROM historico_v6 ORDER BY hostname")
                return [{"label": r[0], "value": r[0]} for r in c.fetchall()]
    except Exception:
        return []


@callback(
    [Output("hist-grafico", "figure"),
     Output("hist-stats", "children"),
     Output("hist-heatmap", "figure")],
    [Input("hist-hostname", "value"),
     Input("hist-metrica", "value"),
     Input("hist-periodo", "value"),
     Input("hist-interval", "n_intervals")],
    State("session-store", "data"),
)
def atualizar_historico(hostname, metrica, periodo, n, session):
    vazio = _fig_vazio("Selecione uma maquina")
    if not session or not session.get("authenticated") or not hostname:
        return vazio, html.Div(), _fig_vazio("")

    delta = {"1h": 1, "6h": 6, "24h": 24, "3d": 72, "7d": 168}
    horas = delta.get(periodo, 24)
    desde = datetime.now() - timedelta(hours=horas)

    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("""
                    SELECT timestamp, cpu, ram, disco_c, disco_d
                    FROM historico_v6
                    WHERE hostname = %s AND timestamp >= %s
                    ORDER BY timestamp
                """, (hostname, desde))
                rows = c.fetchall()
                cnames = [d[0] for d in c.description]
    except Exception as e:
        return _fig_vazio(f"Erro: {e}"), html.Div(), _fig_vazio("")

    if not rows:
        return _fig_vazio("Sem dados para o periodo"), html.Div(), _fig_vazio("")

    df = pd.DataFrame(rows, columns=cnames)

    cols_map = {
        "cpu_ram": ["cpu", "ram"],
        "disco":   ["disco_c", "disco_d"],
        "todas":   ["cpu", "ram", "disco_c", "disco_d"],
    }
    ycols = cols_map.get(metrica, ["cpu", "ram"])
    df_plot = df[["timestamp"] + [c for c in ycols if c in df.columns]].dropna()

    cores = {"cpu": "#06b6d4", "ram": "#a855f7", "disco_c": "#10b981", "disco_d": "#f59e0b"}
    fig = px.line(df_plot, x="timestamp", y=[c for c in ycols if c in df_plot.columns],
                  title=f"HISTORICO — {hostname} — {periodo}",
                  color_discrete_map=cores)
    _estilo(fig)
    fig.update_layout(yaxis_range=[0, 105], xaxis_title="", yaxis_title="%")

    # Stats
    stats_items = []
    for col in ["cpu", "ram", "disco_c", "disco_d"]:
        if col in df.columns and df[col].notna().any():
            s = df[col].dropna()
            stats_items.append(html.Div(
                style={"display": "flex", "justifyContent": "space-between",
                       "padding": ".3rem 0", "borderBottom": "1px solid rgba(6,182,212,.08)"},
                children=[
                    html.Span(col.upper(), style={"fontSize": ".65rem", "color": "#475569", "fontWeight": "700"}),
                    html.Span(
                        f"Min: {s.min():.1f}%  Med: {s.mean():.1f}%  Max: {s.max():.1f}%",
                        style={"fontSize": ".65rem", "color": "#94a3b8"},
                    ),
                ],
            ))
    stats = html.Div(stats_items) if stats_items else html.Div("Sem dados")

    # Média por hora (heatmap)
    df["hora"] = pd.to_datetime(df["timestamp"]).dt.hour
    media_hora = df.groupby("hora")["cpu"].mean().reset_index()
    hmap = px.bar(media_hora, x="hora", y="cpu",
                  color="cpu", color_continuous_scale=["#06b6d4", "#f59e0b", "#ef4444"],
                  range_color=[0, 100])
    _estilo(hmap)
    hmap.update_layout(xaxis_title="Hora do dia", yaxis_title="CPU media (%)",
                       coloraxis_showscale=False, yaxis_range=[0, 105])

    return fig, stats, hmap


def _fig_vazio(titulo: str):
    fig = px.line(title=titulo)
    _estilo(fig)
    return fig


def _estilo(fig) -> None:
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font_color="#94a3b8", title_font_color="#22d3ee",
        margin=dict(l=10, r=10, t=40, b=10),
        legend=dict(font=dict(color="#94a3b8")),
        xaxis=dict(gridcolor="rgba(6,182,212,.06)"),
        yaxis=dict(gridcolor="rgba(6,182,212,.06)"),
    )
