import dash
import pandas as pd
from dash import Input, Output, State, callback, dash_table, dcc, html
from datetime import datetime

from dashboard.components import page_header, kpi_card
from database import get_conn

dash.register_page(__name__, path="/alertas", name="Alertas", title="Neon — Alertas")


def layout(**kwargs):
    return html.Div(className="page-content", children=[
        page_header("LOG DE ALERTAS", "Historico de todos os alertas disparados",
                    "fa-solid fa-bell"),

        dcc.Interval(id="alertas-interval", interval=30_000, n_intervals=0),

        # KPIs
        html.Div(id="alertas-kpis", className="kpi-grid", style={"marginBottom": "1rem"}),

        # Filtros
        html.Div(className="panel neon-cyan", style={"marginBottom": "1rem"}, children=[
            html.Div(className="grid-3", children=[
                html.Div([
                    html.Label("HOSTNAME", className="login-label"),
                    dcc.Dropdown(id="alerta-host-filtro", placeholder="Todos...",
                                 multi=True, style={"color": "#1e293b"}),
                ]),
                html.Div([
                    html.Label("TIPO", className="login-label"),
                    dcc.Dropdown(
                        id="alerta-tipo-filtro",
                        options=[
                            {"label": "CPU",   "value": "CPU"},
                            {"label": "RAM",   "value": "RAM"},
                            {"label": "Disco", "value": "DISCO"},
                        ],
                        placeholder="Todos...", multi=True,
                        style={"color": "#1e293b"},
                    ),
                ]),
                html.Div([
                    html.Label("PERIODO", className="login-label"),
                    dcc.Dropdown(
                        id="alerta-periodo",
                        options=[
                            {"label": "Ultimo dia",   "value": "1"},
                            {"label": "Ultimos 3 dias","value": "3"},
                            {"label": "Ultimos 7 dias","value": "7"},
                            {"label": "Tudo",          "value": "0"},
                        ],
                        value="7", clearable=False,
                        style={"color": "#1e293b"},
                    ),
                ]),
            ]),
            html.Div(style={"display": "flex", "gap": ".5rem", "marginTop": ".75rem"}, children=[
                html.Button("LIMPAR ALERTAS ANTIGOS (>30 dias)", id="btn-limpar-alertas",
                            n_clicks=0, className="btn-logout",
                            style={"fontSize": ".65rem"}),
                html.Span(id="alertas-limpar-feedback",
                          style={"fontSize": ".7rem", "color": "#34d399", "alignSelf": "center"}),
            ]),
        ]),

        # Tabela
        html.Div(className="panel neon-purple", children=[
            html.Div(id="alertas-tabela"),
        ]),
    ])


@callback(
    [Output("alertas-kpis", "children"),
     Output("alertas-tabela", "children"),
     Output("alerta-host-filtro", "options")],
    [Input("alertas-interval", "n_intervals"),
     Input("alerta-host-filtro", "value"),
     Input("alerta-tipo-filtro", "value"),
     Input("alerta-periodo", "value")],
    State("session-store", "data"),
)
def atualizar_alertas(n, hosts, tipos, periodo, session):
    if not session or not session.get("authenticated"):
        return [], html.Div(), []

    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                # Monta query com filtros
                where = []
                params: list = []
                if periodo and periodo != "0":
                    where.append(f"timestamp > NOW() - INTERVAL '{periodo} days'")
                if hosts:
                    where.append("hostname = ANY(%s)")
                    params.append(hosts)
                if tipos:
                    where.append("tipo = ANY(%s)")
                    params.append(tipos)

                cond = ("WHERE " + " AND ".join(where)) if where else ""
                c.execute(f"SELECT * FROM alertas {cond} ORDER BY timestamp DESC LIMIT 500",
                          params)
                rows = c.fetchall()
                cols = [d[0] for d in c.description]

                c.execute("SELECT DISTINCT hostname FROM alertas ORDER BY hostname")
                hosts_opts = [{"label": r[0], "value": r[0]} for r in c.fetchall()]
    except Exception as e:
        return [], html.Div(f"Erro: {e}", style={"color": "#f87171"}), []

    if not rows:
        return [], html.Div("Nenhum alerta encontrado.",
                            style={"color": "#475569", "padding": "1rem"}), hosts_opts

    df = pd.DataFrame(rows, columns=cols)
    df["timestamp"] = df["timestamp"].dt.strftime("%d/%m/%Y %H:%M:%S")

    kpis = [
        kpi_card("TOTAL ALERTAS", len(df),           "#ef4444", "fa-solid fa-triangle-exclamation"),
        kpi_card("ALERTAS CPU",   len(df[df["tipo"]=="CPU"]),   "#f59e0b", "fa-solid fa-microchip"),
        kpi_card("ALERTAS RAM",   len(df[df["tipo"]=="RAM"]),   "#a855f7", "fa-solid fa-memory"),
        kpi_card("ALERTAS DISCO", len(df[df["tipo"]=="DISCO"]), "#06b6d4", "fa-solid fa-hard-drive"),
    ]

    tabela = dash_table.DataTable(
        data=df.to_dict("records"),
        columns=[
            {"name": "DATA/HORA", "id": "timestamp"},
            {"name": "HOSTNAME",  "id": "hostname"},
            {"name": "TIPO",      "id": "tipo"},
            {"name": "MENSAGEM",  "id": "mensagem"},
        ],
        filter_action="native", sort_action="native",
        page_size=25,
        style_table={"overflowX": "auto", "width": "100%"},
        style_cell={"textAlign": "left", "padding": "9px 12px", "fontSize": "11px",
                    "backgroundColor": "#090d16", "color": "#94a3b8",
                    "border": "1px solid rgba(168,85,247,.05)",
                    "whiteSpace": "nowrap", "overflow": "hidden",
                    "textOverflow": "ellipsis"},
        style_header={"backgroundColor": "#020617", "color": "#a78bfa",
                      "fontWeight": "bold", "border": "1px solid rgba(168,85,247,.15)"},
        style_data_conditional=[
            {"if": {"filter_query": '{tipo} = "CPU"'},   "color": "#f87171"},
            {"if": {"filter_query": '{tipo} = "RAM"'},   "color": "#fbbf24"},
            {"if": {"filter_query": '{tipo} = "DISCO"'}, "color": "#c084fc"},
        ],
    )
    return kpis, tabela, hosts_opts


@callback(
    Output("alertas-limpar-feedback", "children"),
    Input("btn-limpar-alertas", "n_clicks"),
    prevent_initial_call=True,
)
def limpar_alertas(n):
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("DELETE FROM alertas WHERE timestamp < NOW() - INTERVAL '30 days'")
                return f"Alertas com mais de 30 dias removidos."
    except Exception as e:
        return f"Erro: {e}"
