import dash
from dash import dcc, html

from dashboard.components import nav_bar


_INDEX = """<!DOCTYPE html>
<html lang="pt-BR">
<head>
    {%metas%}
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{%title%}</title>
    {%favicon%}
    {%css%}
    <style>
        /* ── Reset & Base ── */
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #05070f; color: #e2e8f0; font-family: 'Segoe UI', system-ui, sans-serif; min-height: 100vh; }
        a { color: inherit; text-decoration: none; }

        /* ── Scrollbar ── */
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #090d16; }
        ::-webkit-scrollbar-thumb { background: #1e293b; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #06b6d4; }

        /* ── Neon Effects ── */
        .neon-cyan   { box-shadow: 0 0 12px rgba(6,182,212,.12); border: 1px solid rgba(6,182,212,.25); }
        .neon-purple { box-shadow: 0 0 12px rgba(168,85,247,.12); border: 1px solid rgba(168,85,247,.25); }
        .neon-text   { text-shadow: 0 0 10px rgba(6,182,212,.6); }

        /* ── Navbar ── */
        .navbar { display: flex; align-items: center; justify-content: space-between; gap: 1rem;
                  padding: .75rem 1.5rem; background: #030508; border-bottom: 1px solid rgba(6,182,212,.12);
                  position: sticky; top: 0; z-index: 50; flex-wrap: wrap; }
        .navbar-brand { display: flex; align-items: center; gap: .75rem; }
        .navbar-icon  { color: #22d3ee; font-size: 1.2rem; }
        .navbar-title { display: block; font-size: .85rem; font-weight: 900; color: #22d3ee;
                        letter-spacing: .1em; text-shadow: 0 0 8px rgba(6,182,212,.5); }
        .navbar-subtitle { display: block; font-size: .6rem; color: #475569; letter-spacing: .12em; }
        .navbar-links { display: flex; gap: .25rem; flex-wrap: wrap; }
        .nav-link { padding: .4rem .75rem; border-radius: .375rem; font-size: .7rem; font-weight: 700;
                    letter-spacing: .06em; color: #94a3b8; transition: all .2s;
                    border: 1px solid transparent; }
        .nav-link:hover { background: rgba(6,182,212,.08); color: #22d3ee;
                          border-color: rgba(6,182,212,.2); }
        .nav-link.active { background: rgba(6,182,212,.12); color: #22d3ee;
                           border-color: rgba(6,182,212,.3); }
        .btn-logout { padding: .4rem .8rem; background: rgba(239,68,68,.1);
                      border: 1px solid rgba(239,68,68,.3); color: #fca5a5;
                      border-radius: .375rem; font-size: .7rem; font-weight: 700;
                      cursor: pointer; transition: all .2s; }
        .btn-logout:hover { background: rgba(239,68,68,.2); }

        /* ── KPI Cards ── */
        .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px,1fr)); gap: 1rem; }
        .kpi-card { display: flex; align-items: center; justify-content: space-between;
                    padding: 1rem; border-radius: .75rem; background: rgba(9,13,22,.8); }
        .kpi-label { display: block; font-size: .6rem; font-weight: 800; color: #475569;
                     letter-spacing: .1em; text-transform: uppercase; }
        .kpi-value { display: block; font-size: 1.4rem; font-weight: 800; margin-top: .2rem; }
        .kpi-icon  { width: 2.2rem; height: 2.2rem; display: flex; align-items: center;
                     justify-content: center; border-radius: 50%;
                     background: rgba(255,255,255,.03); border: 1px solid rgba(255,255,255,.07); }

        /* ── Status Badges ── */
        .badge { padding: .15rem .5rem; border-radius: .25rem; font-size: .65rem; font-weight: 700; }
        .badge-online  { background: rgba(16,185,129,.15); color: #34d399; }
        .badge-alerta  { background: rgba(245,158,11,.15); color: #fbbf24; }
        .badge-offline { background: rgba(100,116,139,.1); color: #64748b; }

        /* ── Page Layout ── */
        .page-content { padding: 1.5rem; max-width: 1400px; margin: 0 auto; }
        .page-header  { display: flex; align-items: center; gap: .75rem; margin-bottom: 1.5rem; }
        .page-header-icon { font-size: 1.4rem; color: #22d3ee; }
        .page-title   { font-size: 1rem; font-weight: 900; color: #22d3ee;
                        letter-spacing: .08em; text-shadow: 0 0 8px rgba(6,182,212,.4); }
        .page-subtitle{ font-size: .65rem; color: #475569; letter-spacing: .08em; margin-top: .1rem; }

        /* ── Cards / Panels ── */
        .panel { background: rgba(9,13,22,.6); border-radius: .75rem; padding: 1rem; margin-bottom: 1rem; }

        /* ── Grid Utilities ── */
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        .grid-3 { display: grid; grid-template-columns: repeat(3,1fr); gap: 1rem; }
        .col-span-2 { grid-column: span 2; }

        /* ── Section Title ── */
        .section-title { font-size: .7rem; font-weight: 800; color: #22d3ee;
                         letter-spacing: .1em; text-transform: uppercase; margin-bottom: .75rem; }

        /* ── Table ── */
        .dash-table-container { border-radius: .5rem; overflow: hidden; }

        /* ── Login ── */
        .login-overlay { position: fixed; inset: 0; display: flex; align-items: center;
                         justify-content: center; z-index: 100;
                         background: radial-gradient(circle at center, #101524 0%, #030508 100%); }
        .login-card { width: 100%; max-width: 400px; padding: 2rem; border-radius: 1rem;
                      background: rgba(9,13,22,.9); }
        .login-title { font-size: 1rem; font-weight: 900; color: #22d3ee;
                       letter-spacing: .1em; text-align: center; }
        .login-sub   { font-size: .6rem; color: #475569; letter-spacing: .15em;
                       text-align: center; margin-bottom: 1.5rem; }
        .login-label { display: block; font-size: .65rem; font-weight: 700; color: #64748b;
                       letter-spacing: .1em; text-transform: uppercase; margin-bottom: .3rem; }
        .login-input { width: 100%; padding: .6rem .75rem; border-radius: .375rem;
                       background: #090d16; color: #22d3ee; border: 1px solid #1e293b;
                       font-size: .85rem; margin-bottom: .75rem; }
        .login-input:focus { outline: none; border-color: #22d3ee; }
        .btn-login { width: 100%; padding: .7rem; border: none; border-radius: .375rem;
                     background: linear-gradient(135deg, #0891b2, #1d4ed8);
                     color: white; font-size: .75rem; font-weight: 800;
                     letter-spacing: .1em; cursor: pointer; transition: opacity .2s; }
        .btn-login:hover { opacity: .85; }
        .login-error { font-size: .7rem; color: #f87171; text-align: center;
                       font-weight: 700; margin-bottom: .5rem; min-height: 1rem; }

        /* ── Responsive ── */
        @media (max-width: 768px) {
            .navbar { padding: .5rem 1rem; }
            .navbar-links { display: none; }
            .page-content { padding: .75rem; }
            .grid-2, .grid-3 { grid-template-columns: 1fr; }
            .col-span-2 { grid-column: span 1; }
            .kpi-grid { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>
    {%app_entry%}
    <footer>
        {%config%}
        {%scripts%}
        {%renderer%}
    </footer>
</body>
</html>"""


def create_login() -> html.Div:
    return html.Div(className="login-overlay", id="container-login", children=[
        html.Div(className="login-card neon-cyan", children=[
            html.Div(className="text-center mb-4", children=[
                html.I(className="fa-solid fa-shield-halved",
                       style={"fontSize": "2rem", "color": "#22d3ee", "marginBottom": ".5rem", "display": "block"}),
                html.H2("NEON SECURITY SYSTEM", className="login-title neon-text"),
                html.P("AUTENTICACAO TECNICA REQUERIDA", className="login-sub"),
            ]),
            html.Label("USUARIO", className="login-label"),
            dcc.Input(id="login-username", type="text", placeholder="Username",
                      className="login-input", debounce=False),
            html.Label("SENHA", className="login-label"),
            dcc.Input(id="login-password", type="password", placeholder="••••••••",
                      className="login-input", debounce=False),
            html.Div(id="login-feedback", className="login-error"),
            html.Button("VERIFICAR IDENTIDADE", id="btn-login", n_clicks=0,
                        className="btn-login"),
        ]),
    ])


def create_root_layout() -> html.Div:
    return html.Div([
        dcc.Store(id="session-store", storage_type="session", data={"authenticated": False}),

        # Tela de login
        create_login(),

        # App principal (oculto até autenticar)
        html.Div(id="container-dashboard", style={"display": "none"}, children=[
            nav_bar(),
            html.Main(dash.page_container),
        ]),
    ])
