from datetime import datetime
from dash import html, dcc


# ── KPI Card ──────────────────────────────────────────────────────────────────
def kpi_card(titulo: str, valor, cor: str, icone: str, pulse: bool = False) -> html.Div:
    glow   = "neon-cyan" if cor in ("#3b82f6", "#10b981", "#0284c7") else "neon-purple"
    pulse_ = "animate-pulse" if pulse else ""
    return html.Div(
        className=f"kpi-card {glow} {pulse_}",
        children=[
            html.Div([
                html.Span(titulo, className="kpi-label"),
                html.Span(str(valor), className="kpi-value", style={"color": cor}),
            ]),
            html.Div(
                className="kpi-icon",
                children=[html.I(className=icone, style={"color": cor})],
            ),
        ],
    )


# ── Status Badge ─────────────────────────────────────────────────────────────
def status_badge(diff_seconds: float) -> html.Span:
    if diff_seconds <= 120:
        return html.Span("Online", className="badge badge-online")
    if diff_seconds <= 720:
        return html.Span("Alerta", className="badge badge-alerta")
    return html.Span("Offline", className="badge badge-offline")


# ── Trend Arrow ───────────────────────────────────────────────────────────────
def trend(atual: float | None, anterior: float | None) -> str:
    if atual is None or anterior is None:
        return ""
    diff = atual - anterior
    if abs(diff) < 1:
        return " →"
    return f" ↑{diff:.1f}" if diff > 0 else f" ↓{abs(diff):.1f}"


# ── Nav Bar ───────────────────────────────────────────────────────────────────
def nav_bar() -> html.Header:
    links = [
        ("/",                "fa-solid fa-gauge",            "Painel"),
        ("/historico",       "fa-solid fa-chart-line",       "Historico"),
        ("/alertas",         "fa-solid fa-bell",             "Alertas"),
        ("/inventario",      "fa-solid fa-server",           "Inventario"),
        ("/relatorio",       "fa-solid fa-file-chart-column","Relatorio"),
        ("/observabilidade", "fa-solid fa-microscope",       "Observ."),
        ("/processos",       "fa-solid fa-microchip",        "Processos"),
        ("/configuracoes",   "fa-solid fa-sliders",          "Config"),
    ]
    return html.Header(
        className="navbar",
        children=[
            html.Div(className="navbar-brand", children=[
                html.I(className="fa-solid fa-terminal navbar-icon"),
                html.Div([
                    html.Span("NEON CONTROL CENTER", className="navbar-title"),
                    html.Span("MONITOR DE PARQUE TECNOLOGICO",
                              className="navbar-subtitle"),
                ]),
            ]),
            html.Nav(className="navbar-links", children=[
                dcc.Link(
                    children=[html.I(className=f"{ico} mr-1"), lbl],
                    href=href, className="nav-link",
                )
                for href, ico, lbl in links
            ]),
            html.Button(
                [html.I(className="fa-solid fa-right-from-bracket mr-1"), "Sair"],
                id="btn-logout", n_clicks=0, className="btn-logout",
            ),
        ],
    )


# ── Page Header ───────────────────────────────────────────────────────────────
def page_header(titulo: str, subtitulo: str = "", icone: str = "") -> html.Div:
    return html.Div(className="page-header", children=[
        html.I(className=f"{icone} page-header-icon") if icone else None,
        html.Div([
            html.H1(titulo, className="page-title"),
            html.P(subtitulo, className="page-subtitle") if subtitulo else None,
        ]),
    ])


# ── Última atualização formatada ──────────────────────────────────────────────
def fmt_ts(ts) -> str:
    if ts is None:
        return "-"
    if isinstance(ts, str):
        return ts
    return ts.strftime("%d/%m/%Y %H:%M:%S")


# ── Classificar status por tempo offline ─────────────────────────────────────
def get_status(diff_seconds: float) -> tuple[str, str]:
    """Returns (label, css_class)"""
    if diff_seconds <= 120:
        return "Online",  "status-online"
    if diff_seconds <= 720:
        return "Alerta",  "status-alerta"
    return "Offline", "status-offline"
