import logging
import secrets

import dash
from apscheduler.schedulers.background import BackgroundScheduler
from dash import Input, Output, State, ctx
from flask import Flask

from api import api_bp
from config import ADMIN_PASS, ADMIN_USER, APP_HOST, APP_PORT, APP_THREADS
from dashboard.layout import _INDEX, create_root_layout
from database import get_conn, init_db

log = logging.getLogger(__name__)

# ── Flask + Dash ──────────────────────────────────────────────────────────────
server = Flask(__name__)
server.register_blueprint(api_bp)

app = dash.Dash(
    __name__,
    server=server,
    use_pages=True,
    pages_folder="dashboard/pages",
    suppress_callback_exceptions=True,
    external_stylesheets=[
        "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css",
    ],
)
app.title  = "Neon Control Center"
app.index_string = _INDEX
app.layout = create_root_layout()

# ── Callback global de autenticação ──────────────────────────────────────────
@app.callback(
    [Output("container-login",     "style"),
     Output("container-dashboard", "style"),
     Output("session-store",       "data"),
     Output("login-feedback",      "children")],
    [Input("btn-login",  "n_clicks"),
     Input("btn-logout", "n_clicks")],
    [State("login-username", "value"),
     State("login-password", "value")],
)
def handle_auth(login_clicks, logout_clicks, user, password):
    trigger = ctx.triggered_id

    if trigger == "btn-login" and (login_clicks or 0) > 0:
        ok_user = bool(user)     and secrets.compare_digest(user,     ADMIN_USER)
        ok_pass = bool(password) and secrets.compare_digest(password, ADMIN_PASS)
        if ok_user and ok_pass:
            return {"display": "none"}, {"display": "block"}, {"authenticated": True}, ""
        return ({"display": "flex"}, {"display": "none"},
                {"authenticated": False}, "CREDENCIAIS INVALIDAS")

    if trigger == "btn-logout" and (logout_clicks or 0) > 0:
        return {"display": "flex"}, {"display": "none"}, {"authenticated": False}, ""

    return {"display": "flex"}, {"display": "none"}, {"authenticated": False}, ""


# ── Startup ───────────────────────────────────────────────────────────────────
init_db()


def _limpar_historico() -> None:
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute(
                    "DELETE FROM historico_v6 WHERE timestamp < NOW() - INTERVAL '7 days'"
                )
        log.info("Limpeza de historico concluida.")
    except Exception as e:
        log.error("Erro na limpeza de historico: %s", e)


def _enviar_relatorio_diario() -> None:
    from config import EMAIL_HOST, EMAIL_PORT, EMAIL_USER, EMAIL_PASS, EMAIL_TO
    if not all([EMAIL_HOST, EMAIL_USER, EMAIL_TO]):
        return
    try:
        import smtplib
        from datetime import datetime
        from email.mime.multipart import MIMEMultipart
        from email.mime.text import MIMEText
        from dashboard.pages.relatorio import _query, _gerar_html

        df = _query()
        if df.empty:
            return
        conteudo = _gerar_html(df)
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"[NEON] Relatorio Diario — {datetime.now().strftime('%d/%m/%Y')}"
        msg["From"]    = EMAIL_USER
        msg["To"]      = EMAIL_TO
        msg.attach(MIMEText(conteudo, "html", "utf-8"))
        with smtplib.SMTP(EMAIL_HOST, int(EMAIL_PORT), timeout=30) as s:
            s.starttls()
            s.login(EMAIL_USER, EMAIL_PASS)
            s.sendmail(EMAIL_USER, [EMAIL_TO], msg.as_string())
        log.info("Relatorio diario enviado para %s", EMAIL_TO)
    except Exception as e:
        log.warning("Falha no relatorio diario: %s", e)


_scheduler = BackgroundScheduler(daemon=True)
_scheduler.add_job(_limpar_historico,       "interval", hours=1,  id="limpar_historico")
_scheduler.add_job(_enviar_relatorio_diario, "cron",    hour=7, minute=0, id="relatorio_diario")
_scheduler.start()


if __name__ == "__main__":
    from waitress import serve
    log.info("Iniciando Waitress — %s:%s (%d threads)", APP_HOST, APP_PORT, APP_THREADS)
    serve(server, host=APP_HOST, port=APP_PORT, threads=APP_THREADS)
