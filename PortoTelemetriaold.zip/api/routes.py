import json
import logging
import re
import secrets
from datetime import datetime, timedelta

from flask import jsonify, request

from alerts import alertar
from config import API_TOKEN, get_limiares
from database import get_conn
from api import api_bp

log = logging.getLogger(__name__)


def _boot_from_uptime(uptime_str: str) -> str | None:
    try:
        d = int(re.search(r'(\d+)d', uptime_str).group(1)) if 'd' in uptime_str else 0
        h = int(re.search(r'(\d+)h', uptime_str).group(1)) if 'h' in uptime_str else 0
        m = int(re.search(r'(\d+)m', uptime_str).group(1)) if 'm' in uptime_str else 0
        return (datetime.now() - timedelta(days=d, hours=h, minutes=m)).strftime("%d/%m/%Y %H:%M")
    except Exception:
        return None


_CAMPOS_OBRIGATORIOS = frozenset({
    "hostname", "modelo", "cpu_modelo", "cpu", "ram", "ram_total",
    "disco_c", "disco_c_total", "disco_d", "disco_d_total",
    "rede", "viloes", "bateria_status", "carregador", "uptime",
})


def _auth_ok() -> bool:
    header = request.headers.get("Authorization", "")
    return bool(API_TOKEN) and secrets.compare_digest(
        header.encode(), f"Bearer {API_TOKEN}".encode()
    )


# ── Saúde do servidor ─────────────────────────────────────────────────────────
@api_bp.route("/api/health", methods=["GET"])
def health():
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("SELECT COUNT(*) FROM maquinas_v6")
                total = c.fetchone()[0]
        return jsonify({"status": "ok", "db": "ok", "maquinas": total,
                        "timestamp": datetime.now().isoformat()}), 200
    except Exception as e:
        return jsonify({"status": "ok", "db": "error", "error": str(e)}), 200


# ── Lista de máquinas (REST externo) ──────────────────────────────────────────
@api_bp.route("/api/machines", methods=["GET"])
def list_machines():
    if not _auth_ok():
        return jsonify({"status": "nao_autorizado"}), 401
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("""
                    SELECT hostname, modelo, cpu, ram, localidade,
                           departamento, ultima_atualizacao
                    FROM maquinas_v6
                    ORDER BY hostname
                """)
                rows = c.fetchall()
                cols = [d[0] for d in c.description]
        machines = []
        for r in rows:
            m = dict(zip(cols, r))
            if m.get("ultima_atualizacao"):
                m["ultima_atualizacao"] = m["ultima_atualizacao"].isoformat()
            machines.append(m)
        return jsonify({"machines": machines, "total": len(machines)}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Detalhe de uma máquina (REST externo) ─────────────────────────────────────
@api_bp.route("/api/machines/<hostname>", methods=["GET"])
def get_machine(hostname):
    if not _auth_ok():
        return jsonify({"status": "nao_autorizado"}), 401
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("SELECT * FROM maquinas_v6 WHERE hostname = %s", (hostname,))
                row = c.fetchone()
                if not row:
                    return jsonify({"error": "not_found"}), 404
                cols = [d[0] for d in c.description]
        machine = dict(zip(cols, row))
        if machine.get("ultima_atualizacao"):
            machine["ultima_atualizacao"] = machine["ultima_atualizacao"].isoformat()
        return jsonify(machine), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Edição manual de metadados de um dispositivo ─────────────────────────────
@api_bp.route("/api/machines/<hostname>", methods=["PUT"])
def update_machine(hostname):
    if not _auth_ok():
        return jsonify({"status": "nao_autorizado"}), 401
    dados = request.get_json(silent=True) or {}
    campos_permitidos = {"localidade", "departamento", "ativo_fisico", "centro_custo"}
    campos = {k: v for k, v in dados.items() if k in campos_permitidos}
    if not campos:
        return jsonify({"status": "sem_campos_validos"}), 400
    campos["meta_manual"] = True
    sets = ", ".join(f"{k}=%s" for k in campos)
    vals = list(campos.values()) + [hostname]
    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute(f"UPDATE maquinas_v6 SET {sets} WHERE hostname=%s", vals)
                if c.rowcount == 0:
                    return jsonify({"status": "not_found"}), 404
        return jsonify({"status": "sucesso"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Receptor de telemetria dos agentes C# ────────────────────────────────────
@api_bp.route("/api/telemetry", methods=["POST"])
def receber_dados():
    if not _auth_ok():
        return jsonify({"status": "nao_autorizado"}), 401

    dados = request.get_json(silent=True)
    if not dados or not _CAMPOS_OBRIGATORIOS.issubset(dados):
        return jsonify({"status": "dados_invalidos"}), 400

    from analytics import calcular_health_score

    agora    = datetime.now()
    hostname = str(dados["hostname"])
    cpu      = float(dados["cpu"])
    ram      = float(dados["ram"])
    disco_c  = float(dados["disco_c"])
    disco_d  = float(dados["disco_d"])
    rede     = str(dados["rede"]).lower()

    carregador_str = "Conectado" if dados.get("carregador") else "Na Bateria"
    boot_time = dados.get("boot_time") or _boot_from_uptime(dados.get("uptime", ""))

    if "corporativa" in rede or "cabo" in rede:
        localidade = "Escritorio"
    elif "wi-fi" in rede or "wifi" in rede:
        localidade = "Home Office"
    else:
        localidade = "Desconhecido"

    # Campos de observabilidade v1
    defender_ativo   = dados.get("defender_ativo")
    defender_produto = dados.get("defender_produto")
    updates_pend     = dados.get("updates_pendentes")
    net_up           = dados.get("net_kbps_up")
    net_down         = dados.get("net_kbps_down")
    servicos_parados = dados.get("servicos_parados")

    ultimo_wu = None
    wu_str = dados.get("ultimo_windows_update")
    if wu_str:
        try:
            ultimo_wu = datetime.fromisoformat(wu_str)
        except Exception:
            pass

    # Campos novos (v2)
    temperatura_cpu     = dados.get("temperatura_cpu")
    reboot_pendente     = dados.get("reboot_pendente")
    bitlocker_ativo     = dados.get("bitlocker_ativo")
    latencia_gw         = dados.get("latencia_gateway_ms")
    latencia_inet       = dados.get("latencia_internet_ms")
    disco_lat           = dados.get("disco_latencia_ms")
    monitores_count     = dados.get("monitores_count")
    resolucao_principal = dados.get("resolucao_principal")
    pasta_uso_raw       = dados.get("pasta_uso")
    portas_raw          = dados.get("portas_abertas")

    pasta_uso_json = json.dumps(pasta_uso_raw) if pasta_uso_raw is not None else None
    portas_json    = json.dumps(portas_raw)    if portas_raw    is not None else None

    # Campos v3 — segurança / hardware / rede
    firewall_domain    = dados.get("firewall_domain")
    firewall_private   = dados.get("firewall_private")
    firewall_public    = dados.get("firewall_public")
    admins_locais_raw  = dados.get("admins_locais")
    admins_locais_json = json.dumps(admins_locais_raw) if admins_locais_raw is not None else None
    defender_ult_def   = dados.get("defender_ultima_def")
    defender_scan_dias = dados.get("defender_scan_dias")
    smart_ok           = dados.get("smart_ok")
    tela_bloqueada     = dados.get("tela_bloqueada")
    idle_minutos       = dados.get("idle_minutos")
    gpu_modelo         = dados.get("gpu_modelo")
    gpu_memoria_mb     = dados.get("gpu_memoria_mb")
    discos_fis_raw     = dados.get("discos_fisicos")
    discos_fis_json    = json.dumps(discos_fis_raw) if discos_fis_raw is not None else None
    bios_versao        = dados.get("bios_versao")
    conexoes_ext_raw   = dados.get("conexoes_externas")
    conexoes_ext_json  = json.dumps(conexoes_ext_raw) if conexoes_ext_raw is not None else None
    dns_serv_raw       = dados.get("dns_servidores")
    dns_serv_json      = json.dumps(dns_serv_raw) if dns_serv_raw is not None else None
    updates_pend_v3    = dados.get("updates_pendentes")  # sobrescreve updates_pend se vier

    # Campos v4 — RDP, UAC, rede, reboot, bateria, usuários locais
    rdp_habilitado       = dados.get("rdp_habilitado")
    uac_habilitado       = dados.get("uac_habilitado")
    rede_tipo            = dados.get("rede_tipo")
    reboot_inesperado    = dados.get("reboot_inesperado")
    tem_bateria          = dados.get("tem_bateria")
    bateria_descricao    = dados.get("bateria_descricao")
    usuarios_locais_raw  = dados.get("usuarios_locais")
    usuarios_locais_json = json.dumps(usuarios_locais_raw) if usuarios_locais_raw is not None else None

    health = calcular_health_score({
        "diff": 0, "cpu": cpu, "ram": ram, "disco_c": disco_c,
        "defender_ativo": defender_ativo, "updates_pendentes": updates_pend,
    })

    lim = get_limiares()
    if cpu > lim["cpu"]:
        alertar(hostname, "CPU",
                f"CPU em {cpu}% (limite {lim['cpu']}%). Processos: {dados['viloes']}")
    if ram > lim["ram"]:
        alertar(hostname, "RAM", f"RAM em {ram}% (limite {lim['ram']}%)")
    if disco_c > lim["disco"]:
        alertar(hostname, "DISCO", f"Disco C em {disco_c}% (limite {lim['disco']}%)")
    if temperatura_cpu is not None and temperatura_cpu > 85:
        alertar(hostname, "TEMPERATURA",
                f"CPU a {temperatura_cpu}°C — risco de throttling/danos")
    if firewall_domain is False or firewall_private is False or firewall_public is False:
        perfis = [p for p, v in [("Domain", firewall_domain),
                                  ("Private", firewall_private),
                                  ("Public", firewall_public)] if v is False]
        alertar(hostname, "FIREWALL",
                f"Firewall desativado nos perfis: {', '.join(perfis)}")
    if smart_ok is False:
        alertar(hostname, "DISCO_SMART", "S.M.A.R.T. prevê falha iminente no disco físico")
    # Contabilizar falhas de autenticação recentes
    falhas_logon = sum(1 for l in (dados.get("logins") or []) if l.get("tipo") == "Falha_Logon")
    if falhas_logon >= 5:
        alertar(hostname, "SEGURANCA",
                f"{falhas_logon} falhas de autenticação detectadas no último ciclo")
    if rdp_habilitado:
        alertar(hostname, "SEGURANCA", "RDP habilitado — acesso remoto desktop ativo na máquina")
    if uac_habilitado is False:
        alertar(hostname, "SEGURANCA", "UAC desabilitado — máquina sem controle de conta de usuário")
    if reboot_inesperado:
        alertar(hostname, "SISTEMA", "Detectado reboot inesperado nos últimos 30 dias (queda de energia ou crash)")

    try:
        with get_conn() as conn:
            with conn.cursor() as c:
                c.execute("""
                    INSERT INTO maquinas_v6
                        (hostname, modelo, cpu_modelo, cpu, ram, ram_total,
                         disco_c, disco_c_total, disco_d, disco_d_total,
                         rede, viloes, battery_status, carregador,
                         uptime, boot_time, localidade, ultima_atualizacao,
                         os_version, usuario, ip_address, departamento,
                         health_score, defender_ativo, defender_produto,
                         updates_pendentes, ultimo_windows_update,
                         net_kbps_up, net_kbps_down, servicos_parados,
                         temperatura_cpu, reboot_pendente, bitlocker_ativo,
                         latencia_gateway_ms, latencia_internet_ms, disco_latencia_ms,
                         monitores_count, resolucao_principal,
                         pasta_uso, portas_abertas,
                         defender_ultima_def, defender_scan_dias,
                         firewall_domain, firewall_private, firewall_public,
                         admins_locais, smart_ok, tela_bloqueada, idle_minutos,
                         gpu_modelo, gpu_memoria_mb, discos_fisicos, bios_versao,
                         conexoes_externas, dns_servidores,
                         rdp_habilitado, uac_habilitado, rede_tipo, reboot_inesperado,
                         tem_bateria, bateria_descricao, usuarios_locais)
                    VALUES (
                        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
                        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
                        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
                        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
                        %s,%s,%s,%s,%s,%s,%s
                    )
                    ON CONFLICT (hostname) DO UPDATE SET
                        modelo=EXCLUDED.modelo, cpu_modelo=EXCLUDED.cpu_modelo,
                        cpu=EXCLUDED.cpu, ram=EXCLUDED.ram, ram_total=EXCLUDED.ram_total,
                        disco_c=EXCLUDED.disco_c, disco_c_total=EXCLUDED.disco_c_total,
                        disco_d=EXCLUDED.disco_d, disco_d_total=EXCLUDED.disco_d_total,
                        rede=EXCLUDED.rede, viloes=EXCLUDED.viloes,
                        battery_status=EXCLUDED.battery_status,
                        carregador=EXCLUDED.carregador, uptime=EXCLUDED.uptime,
                        boot_time=COALESCE(EXCLUDED.boot_time, maquinas_v6.boot_time),
                        ultima_atualizacao=EXCLUDED.ultima_atualizacao,
                        os_version=COALESCE(EXCLUDED.os_version, maquinas_v6.os_version),
                        usuario=COALESCE(EXCLUDED.usuario, maquinas_v6.usuario),
                        ip_address=COALESCE(EXCLUDED.ip_address, maquinas_v6.ip_address),
                        localidade=CASE WHEN maquinas_v6.meta_manual
                                        THEN maquinas_v6.localidade
                                        ELSE EXCLUDED.localidade END,
                        departamento=CASE WHEN maquinas_v6.meta_manual
                                          THEN maquinas_v6.departamento
                                          ELSE EXCLUDED.departamento END,
                        health_score=EXCLUDED.health_score,
                        defender_ativo=COALESCE(EXCLUDED.defender_ativo,maquinas_v6.defender_ativo),
                        defender_produto=COALESCE(EXCLUDED.defender_produto,maquinas_v6.defender_produto),
                        updates_pendentes=COALESCE(EXCLUDED.updates_pendentes,maquinas_v6.updates_pendentes),
                        ultimo_windows_update=COALESCE(EXCLUDED.ultimo_windows_update,
                                                       maquinas_v6.ultimo_windows_update),
                        net_kbps_up=EXCLUDED.net_kbps_up,
                        net_kbps_down=EXCLUDED.net_kbps_down,
                        servicos_parados=EXCLUDED.servicos_parados,
                        temperatura_cpu=COALESCE(EXCLUDED.temperatura_cpu,maquinas_v6.temperatura_cpu),
                        reboot_pendente=COALESCE(EXCLUDED.reboot_pendente,maquinas_v6.reboot_pendente),
                        bitlocker_ativo=COALESCE(EXCLUDED.bitlocker_ativo,maquinas_v6.bitlocker_ativo),
                        latencia_gateway_ms=EXCLUDED.latencia_gateway_ms,
                        latencia_internet_ms=EXCLUDED.latencia_internet_ms,
                        disco_latencia_ms=EXCLUDED.disco_latencia_ms,
                        monitores_count=COALESCE(EXCLUDED.monitores_count,maquinas_v6.monitores_count),
                        resolucao_principal=COALESCE(EXCLUDED.resolucao_principal,
                                                     maquinas_v6.resolucao_principal),
                        pasta_uso=COALESCE(EXCLUDED.pasta_uso, maquinas_v6.pasta_uso),
                        portas_abertas=COALESCE(EXCLUDED.portas_abertas, maquinas_v6.portas_abertas),
                        defender_ultima_def=COALESCE(EXCLUDED.defender_ultima_def,
                                                     maquinas_v6.defender_ultima_def),
                        defender_scan_dias=COALESCE(EXCLUDED.defender_scan_dias,
                                                    maquinas_v6.defender_scan_dias),
                        firewall_domain=EXCLUDED.firewall_domain,
                        firewall_private=EXCLUDED.firewall_private,
                        firewall_public=EXCLUDED.firewall_public,
                        admins_locais=COALESCE(EXCLUDED.admins_locais, maquinas_v6.admins_locais),
                        smart_ok=COALESCE(EXCLUDED.smart_ok, maquinas_v6.smart_ok),
                        tela_bloqueada=EXCLUDED.tela_bloqueada,
                        idle_minutos=EXCLUDED.idle_minutos,
                        gpu_modelo=COALESCE(EXCLUDED.gpu_modelo, maquinas_v6.gpu_modelo),
                        gpu_memoria_mb=COALESCE(EXCLUDED.gpu_memoria_mb, maquinas_v6.gpu_memoria_mb),
                        discos_fisicos=COALESCE(EXCLUDED.discos_fisicos, maquinas_v6.discos_fisicos),
                        bios_versao=COALESCE(EXCLUDED.bios_versao, maquinas_v6.bios_versao),
                        conexoes_externas=EXCLUDED.conexoes_externas,
                        dns_servidores=COALESCE(EXCLUDED.dns_servidores, maquinas_v6.dns_servidores),
                        rdp_habilitado=EXCLUDED.rdp_habilitado,
                        uac_habilitado=EXCLUDED.uac_habilitado,
                        rede_tipo=EXCLUDED.rede_tipo,
                        reboot_inesperado=EXCLUDED.reboot_inesperado,
                        tem_bateria=EXCLUDED.tem_bateria,
                        bateria_descricao=EXCLUDED.bateria_descricao,
                        usuarios_locais=COALESCE(EXCLUDED.usuarios_locais, maquinas_v6.usuarios_locais)
                """, (
                    hostname, dados["modelo"], dados["cpu_modelo"],
                    cpu, ram, int(dados["ram_total"]),
                    disco_c, int(dados["disco_c_total"]),
                    disco_d, int(dados["disco_d_total"]),
                    dados["rede"], str(dados["viloes"]),
                    int(dados["bateria_status"]), carregador_str,
                    dados["uptime"], boot_time, localidade, agora,
                    dados.get("os_version"), dados.get("usuario"),
                    dados.get("ip_address"), dados.get("departamento", "Geral"),
                    health, defender_ativo, defender_produto,
                    updates_pend_v3 if updates_pend_v3 is not None else updates_pend,
                    ultimo_wu, net_up, net_down, servicos_parados,
                    temperatura_cpu, reboot_pendente, bitlocker_ativo,
                    latencia_gw, latencia_inet, disco_lat,
                    monitores_count, resolucao_principal,
                    pasta_uso_json, portas_json,
                    defender_ult_def, defender_scan_dias,
                    firewall_domain, firewall_private, firewall_public,
                    admins_locais_json, smart_ok, tela_bloqueada, idle_minutos,
                    gpu_modelo, gpu_memoria_mb, discos_fis_json, bios_versao,
                    conexoes_ext_json, dns_serv_json,
                    rdp_habilitado, uac_habilitado, rede_tipo, reboot_inesperado,
                    tem_bateria, bateria_descricao, usuarios_locais_json,
                ))

                c.execute("""
                    INSERT INTO historico_v6 (hostname, cpu, ram, disco_c, disco_d, timestamp)
                    VALUES (%s, %s, %s, %s, %s, %s)
                """, (hostname, cpu, ram, disco_c, disco_d, agora))

                # Eventos do Windows Event Log
                for ev in (dados.get("eventos") or [])[:20]:
                    try:
                        ev_ts = datetime.fromisoformat(ev["timestamp"]) if ev.get("timestamp") else agora
                    except Exception:
                        ev_ts = agora
                    c.execute("""
                        INSERT INTO eventos_windows
                            (hostname, timestamp, nivel, fonte, event_id, mensagem, log_name)
                        VALUES (%s,%s,%s,%s,%s,%s,%s)
                    """, (hostname, ev_ts, ev.get("nivel"), ev.get("fonte"),
                          ev.get("event_id"), (ev.get("mensagem") or "")[:500],
                          ev.get("log_name")))

                # Processos com CPU% — limpa snapshot anterior e insere novo
                if dados.get("processos"):
                    c.execute(
                        "DELETE FROM processos_top WHERE hostname=%s AND timestamp < NOW() - INTERVAL '25 hours'",
                        (hostname,)
                    )
                    for proc in dados["processos"][:15]:
                        c.execute("""
                            INSERT INTO processos_top
                                (hostname, timestamp, nome, ram_mb, pid, cpu_pct)
                            VALUES (%s,%s,%s,%s,%s,%s)
                        """, (hostname, agora, proc.get("nome"),
                              proc.get("ram_mb"), proc.get("pid"),
                              proc.get("cpu_pct")))

                # Logins/Logoffs do Security EventLog
                for login in (dados.get("logins") or [])[:20]:
                    try:
                        ev_ts = datetime.fromisoformat(login["timestamp"]) if login.get("timestamp") else agora
                    except Exception:
                        ev_ts = agora
                    c.execute("""
                        INSERT INTO login_historico
                            (hostname, timestamp_evento, tipo, usuario, event_id)
                        VALUES (%s,%s,%s,%s,%s)
                    """, (hostname, ev_ts, login.get("tipo"),
                          login.get("usuario"), login.get("event_id")))

                # Software instalado (apenas quando o agente envia lista não-vazia)
                sw_list = dados.get("software") or []
                if sw_list:
                    c.execute(
                        "DELETE FROM software_instalado WHERE hostname=%s", (hostname,)
                    )
                    for sw in sw_list[:150]:
                        c.execute("""
                            INSERT INTO software_instalado
                                (hostname, nome, versao, publisher, instalado)
                            VALUES (%s,%s,%s,%s,%s)
                        """, (hostname, sw.get("nome"), sw.get("versao"),
                              sw.get("publisher"), sw.get("instalado")))

    except Exception as e:
        log.error("Erro ao persistir [%s]: %s", hostname, e)
        return jsonify({"status": "erro_banco"}), 500

    return jsonify({"status": "sucesso"}), 200
