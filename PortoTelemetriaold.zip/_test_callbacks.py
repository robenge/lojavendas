import sys, traceback
sys.path.insert(0, '.')

import pandas as pd
from datetime import datetime
from database import get_conn
from config import get_limiares
import plotly.express as px
import plotly.graph_objects as go

print("=== TESTE PAINEL (overview) ===")
try:
    lim = get_limiares()
    with get_conn() as conn:
        with conn.cursor() as c:
            c.execute("SELECT * FROM maquinas_v6 ORDER BY hostname")
            rows = c.fetchall()
            cols = [d[0] for d in c.description]
            c.execute("""
                SELECT hostname, cpu, ram
                FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY hostname ORDER BY id DESC) rn
                      FROM historico_v6 WHERE timestamp > NOW() - INTERVAL '2 hours') t
                WHERE rn <= 2
            """)
            trend_rows = c.fetchall()

    df = pd.DataFrame(rows, columns=cols)
    agora = datetime.now()
    print(f"  ultima_atualizacao dtype: {df['ultima_atualizacao'].dtype}")
    print(f"  sample value: {df['ultima_atualizacao'].iloc[0] if len(df) else 'N/A'}")
    df["diff"] = (agora - df["ultima_atualizacao"]).dt.total_seconds()
    print(f"  DB: {len(rows)} maquinas, {len(trend_rows)} trend rows")

    # KPIs
    ativos  = len(df[df["diff"] <= 720])
    offline = len(df[df["diff"] > 720])
    print(f"  Ativos: {ativos}, Offline: {offline}")

    # pizza
    loc_counts = df[df["diff"] <= 720]["localidade"].value_counts().reset_index()
    loc_counts.columns = ["localidade", "total"]
    pizza = px.pie(loc_counts, names="localidade", values="total")
    pizza.update_layout(autosize=True)
    print("  Pizza: OK")

    # top5
    top5 = df[df["diff"] <= 720].nlargest(5, "cpu")[["hostname", "cpu"]].copy()
    top5["cor"] = top5["cpu"].apply(lambda x: "#ef4444" if x > lim["cpu"] else "#06b6d4")
    bar = go.Figure(go.Bar(x=top5["cpu"], y=top5["hostname"], orientation="h",
                           marker_color=top5["cor"].tolist(),
                           text=top5["cpu"].apply(lambda x: f"{x}%"),
                           textposition="inside"))
    bar.update_layout(autosize=True, xaxis={"range": [0, 105]}, yaxis={"autorange": "reversed"})
    print("  Bar: OK")

    # table records
    style_cond = []
    registros = []
    for i, row in df.iterrows():
        diff = row["diff"]
        if diff > 720:
            rec = {"STATUS": "Offline", "HOSTNAME": row["hostname"],
                   "CPU": "-", "RAM": "-", "DISCO C": "-",
                   "REDE": row.get("rede", "-"), "LOCALIDADE": row.get("localidade", "-"),
                   "UPTIME": "-", "DEPTO": row.get("departamento", "Geral"),
                   "REPORT": str(row["ultima_atualizacao"])}
        else:
            cpuv = row["cpu"]; ramv = row["ram"]
            status = "Online" if diff <= 120 else "Alerta"
            rec = {
                "STATUS": status, "HOSTNAME": row["hostname"],
                "CPU": f"{cpuv}%", "RAM": f"{ramv}% ({row['ram_total']}GB)",
                "DISCO C": f"{row['disco_c']}% ({row['disco_c_total']}GB)",
                "REDE": row.get("rede", "-"), "LOCALIDADE": row.get("localidade", "-"),
                "UPTIME": row.get("uptime", "-"), "DEPTO": row.get("departamento", "Geral"),
                "REPORT": str(row["ultima_atualizacao"]),
            }
        registros.append(rec)
    print(f"  Tabela: {len(registros)} registros - OK")
    print("  PAINEL: TUDO OK")

except Exception as e:
    print(f"  ERRO NO PAINEL: {e}")
    traceback.print_exc()

print()
print("=== TESTE INVENTARIO ===")
try:
    with get_conn() as conn:
        with conn.cursor() as c:
            c.execute("""
                SELECT hostname, modelo, cpu_modelo, ram_total,
                       disco_c_total, disco_d_total, os_version,
                       usuario, ip_address, departamento, localidade,
                       ativo_fisico, centro_custo, boot_time, ultima_atualizacao
                FROM maquinas_v6 ORDER BY hostname
            """)
            rows = c.fetchall()
            cols = [d[0] for d in c.description]

    df = pd.DataFrame(rows, columns=cols)
    agora = datetime.now()
    df["diff"] = (agora - df["ultima_atualizacao"]).dt.total_seconds()

    # localidade opts (nova logica)
    locais_unicos = df["localidade"].dropna().unique()
    local_opts = [{"label": l, "value": l} for l in sorted(locais_unicos)]
    print(f"  Localidades: {local_opts}")

    deptos_unicos = df["departamento"].dropna().unique()
    depto_opts = [{"label": d, "value": d} for d in sorted(deptos_unicos)]
    print(f"  Departamentos: {depto_opts}")
    print("  INVENTARIO: TUDO OK")

except Exception as e:
    print(f"  ERRO NO INVENTARIO: {e}")
    traceback.print_exc()

print()
print("=== TESTE RELATORIO ===")
try:
    from dashboard.pages.relatorio import _query, _gerar_csv, _gerar_excel, _gerar_pdf, _gerar_html
    df = _query()
    print(f"  Query: {len(df)} registros")
    csv = _gerar_csv(df)
    print(f"  CSV: {len(csv)} chars - OK")
    xls = _gerar_excel(df)
    print(f"  Excel: {len(xls)} bytes - OK")
    htm = _gerar_html(df)
    print(f"  HTML: {len(htm)} chars - OK")
    pdf = _gerar_pdf(df)
    print(f"  PDF: {len(pdf)} bytes - OK")
    print("  RELATORIO: TUDO OK")
except Exception as e:
    print(f"  ERRO NO RELATORIO: {e}")
    traceback.print_exc()
