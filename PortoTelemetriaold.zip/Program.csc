using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace TelemetriaAgent
{
    class Program
    {
        // Configuração via variáveis de ambiente:
        //   TELEMETRIA_SERVER_URL  — URL do servidor (opcional, usa localhost por padrão)
        //   TELEMETRIA_TOKEN       — Bearer token de autenticação (obrigatório)
        private static readonly string ServerUrl =
            Environment.GetEnvironmentVariable("TELEMETRIA_SERVER_URL")
            ?? "http://localhost:8090/api/telemetry";

        private static readonly string TokenSecreto =
            Environment.GetEnvironmentVariable("TELEMETRIA_TOKEN")
            ?? throw new InvalidOperationException("Variável de ambiente TELEMETRIA_TOKEN não configurada.");

        private static readonly HttpClient _httpClient;
        private static readonly Random _rng = new Random();

        #region ESTRUTURAS NATIVAS WINDOWS (P/INVOKE) - ZERO NUGET
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetSystemPowerStatus(out SystemPowerStatus sps);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX lpBuffer);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetSystemTimes(out FILETIME lpIdleTime, out FILETIME lpKernelTime, out FILETIME lpUserTime);

        private struct SystemPowerStatus
        {
            public byte ACLineStatus;
            public byte BatteryFlag;
            public byte BatteryLifePercent;
            public byte Reserved1;
            public uint BatteryLifeTime;
            public uint BatteryFullLifeTime;
        }

        private struct MEMORYSTATUSEX
        {
            public uint dwLength;
            public uint dwMemoryLoad;
            public ulong ullTotalPhys;
            public ulong ullAvailPhys;
            public ulong ullTotalPageFile;
            public ulong ullAvailPageFile;
            public ulong ullTotalVirtual;
            public ulong ullAvailVirtual;
            public uint dwAvailExtendedVirtual;
        }

        private struct FILETIME
        {
            public uint dwLowDateTime;
            public uint dwHighDateTime;
        }
        #endregion

        static Program()
        {
            var handler = new HttpClientHandler { UseProxy = false, Proxy = null };
            _httpClient = new HttpClient(handler)
            {
                Timeout = TimeSpan.FromSeconds(30)
            };
            _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {TokenSecreto}");
        }

        static async Task Main(string[] args)
        {
            using var cts = new CancellationTokenSource();
            Console.CancelKeyPress += (_, e) =>
            {
                e.Cancel = true;
                cts.Cancel();
            };

            Console.WriteLine("Iniciando o coletor corporativo offline em C#...");

            while (!cts.Token.IsCancellationRequested)
            {
                try
                {
                    await EnviarTelemetria(cts.Token);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro no loop: {ex.Message}");
                }

                // Jitter entre 0 e 20 s para evitar thundering herd em escala
                int jitter = _rng.Next(0, 20_000);
                try
                {
                    await Task.Delay(300_000 + jitter, cts.Token);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
            }

            Console.WriteLine("Agente encerrado.");
        }

        private static async Task EnviarTelemetria(CancellationToken ct)
        {
            double cpu    = GetCpuUsageNative();
            double ram    = GetRamUsageNative();
            string viloes = cpu > 80 ? GetTopProcesses() : "Normal";
            GetBatteryStatus(out int bateriaStatus, out bool carregador);
            GetDiskDetails("C", out double discoCUso, out int discoCTotal);
            GetDiskDetails("D", out double discoDUso, out int discoDTotal);

            if (cpu > 85 || ram > 90 || discoCUso > 90 || (discoDTotal > 0 && discoDUso > 90))
            {
                string alerta =
                    $"[ALERTA] CPU: {cpu}% (Vilões: {viloes})" +
                    $" | RAM: {ram}% ({GetRamTotalGb()} GB)" +
                    $" | Disco C: {discoCUso}% ({discoCTotal} GB)" +
                    (discoDTotal > 0 ? $" | Disco D: {discoDUso}% ({discoDTotal} GB)" : "");

                GravarLogNoWindows(alerta, "WARNING");
            }

            var dados = new
            {
                hostname       = Environment.MachineName,
                modelo         = GetModel(),
                cpu_modelo     = GetCpuModel(),
                cpu            = cpu,
                ram            = ram,
                ram_total      = GetRamTotalGb(),
                disco_c        = discoCUso,
                disco_c_total  = discoCTotal,
                disco_d        = discoDUso,
                disco_d_total  = discoDTotal,
                rede           = GetNetworkDetailsNative(),
                viloes         = viloes,
                bateria_status = bateriaStatus,
                carregador     = carregador,
                uptime         = GetUptime(),
            };

            try
            {
                var response = await _httpClient.PostAsJsonAsync(ServerUrl, dados, ct);
                if (response.IsSuccessStatusCode)
                    Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Dados enviados com sucesso.");
                else
                    Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Servidor retornou: {(int)response.StatusCode} {response.ReasonPhrase}");
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Falha de conexão: {ex.Message}");
                GravarLogNoWindows($"Falha ao conectar ao servidor de telemetria: {ex.Message}", "ERROR");
            }
        }

        private static string GetUptime()
        {
            try
            {
                TimeSpan ts = TimeSpan.FromMilliseconds(Environment.TickCount64);
                return ts.Days > 0
                    ? $"{ts.Days}d {ts.Hours}h {ts.Minutes}m"
                    : $"{ts.Hours}h {ts.Minutes}m";
            }
            catch { return "Desconhecido"; }
        }

        private static string GetModel()
        {
            try
            {
                using var key = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\BIOS");
                return key?.GetValue("SystemProductName")?.ToString()?.Trim() ?? "Desconhecido";
            }
            catch { return "Desconhecido"; }
        }

        private static string GetCpuModel()
        {
            try
            {
                using var key = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0");
                return key?.GetValue("ProcessorNameString")?.ToString()?.Trim() ?? "Desconhecido";
            }
            catch { return "Desconhecido"; }
        }

        private static double GetCpuUsageNative()
        {
            try
            {
                GetSystemTimes(out var idle1, out var kernel1, out var user1);
                Thread.Sleep(1000); // amostragem de 1 s exigida pela API GetSystemTimes
                GetSystemTimes(out var idle2, out var kernel2, out var user2);

                ulong ToUlong(FILETIME ft) => ((ulong)ft.dwHighDateTime << 32) | ft.dwLowDateTime;

                ulong sys  = (ToUlong(kernel2) - ToUlong(kernel1)) + (ToUlong(user2) - ToUlong(user1));
                ulong idle = ToUlong(idle2) - ToUlong(idle1);

                return sys == 0 ? 0.0 : Math.Round((double)(sys - idle) * 100.0 / sys, 1);
            }
            catch { return 0.0; }
        }

        private static double GetRamUsageNative()
        {
            var mem = new MEMORYSTATUSEX { dwLength = (uint)Marshal.SizeOf<MEMORYSTATUSEX>() };
            return GlobalMemoryStatusEx(ref mem) ? mem.dwMemoryLoad : 0.0;
        }

        private static int GetRamTotalGb()
        {
            var mem = new MEMORYSTATUSEX { dwLength = (uint)Marshal.SizeOf<MEMORYSTATUSEX>() };
            return GlobalMemoryStatusEx(ref mem)
                ? (int)Math.Round((double)mem.ullTotalPhys / 1024 / 1024 / 1024)
                : 0;
        }

        private static void GetDiskDetails(string driveLetter, out double usoPercent, out int totalGb)
        {
            usoPercent = 0.0;
            totalGb    = 0;
            try
            {
                var drive = new DriveInfo(driveLetter);
                if (!drive.IsReady) return;

                double total = drive.TotalSize;
                usoPercent   = Math.Round(((total - drive.AvailableFreeSpace) / total) * 100, 1);
                totalGb      = (int)(total / 1024 / 1024 / 1024);
            }
            catch { }
        }

        private static string GetNetworkDetailsNative()
        {
            try
            {
                using var process = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName               = "netsh",
                        Arguments              = "wlan show interfaces",
                        RedirectStandardOutput = true,
                        UseShellExecute        = false,
                        CreateNoWindow         = true,
                    }
                };
                process.Start();
                string output = process.StandardOutput.ReadToEnd();
                process.WaitForExit();

                if (output.Contains("conectado", StringComparison.OrdinalIgnoreCase) ||
                    output.Contains("connected",  StringComparison.OrdinalIgnoreCase))
                {
                    var ssid   = Regex.Match(output, @"\bSSID\s*:\s*([^\r\n]+)");
                    var signal = Regex.Match(output, @"(?:Sinal|Signal)\s*:\s*(\d+)%");
                    string ssidVal   = ssid.Success   ? ssid.Groups[1].Value.Trim()  : "Oculta";
                    string signalVal = signal.Success ? $"{signal.Groups[1].Value}%" : "100%";
                    return $"📶 Wi-Fi: {ssidVal} ({signalVal})";
                }
            }
            catch { }

            try
            {
                foreach (var ni in NetworkInterface.GetAllNetworkInterfaces()
                    .Where(ni =>
                        ni.OperationalStatus == OperationalStatus.Up &&
                        ni.NetworkInterfaceType != NetworkInterfaceType.Loopback &&
                        !ni.Description.Contains("virtual", StringComparison.OrdinalIgnoreCase) &&
                        !ni.Description.Contains("vpn",     StringComparison.OrdinalIgnoreCase)))
                {
                    long bps = ni.Speed;
                    if (bps >= 1_000_000_000) return "🔌 Cabo (Giga - 1Gbps)";
                    if (bps > 0)              return $"🔌 Cabo (Fast - {bps / 1_000_000}Mbps)";
                }
            }
            catch { }

            return "❓ Desconhecido";
        }

        private static string GetTopProcesses()
        {
            // Ordena por TotalProcessorTime (CPU acumulado) — mais relevante quando CPU está alta
            var processes = Process.GetProcesses();
            try
            {
                return string.Join(", ", processes
                    .Where(p  => { try { return p.WorkingSet64 > 10 * 1024 * 1024; } catch { return false; } })
                    .OrderByDescending(p => { try { return p.TotalProcessorTime.TotalMilliseconds; } catch { return 0.0; } })
                    .Take(3)
                    .Select(p  => { try { return $"{p.ProcessName} ({p.WorkingSet64 / 1024 / 1024}MB)"; } catch { return p.ProcessName; } }));
            }
            catch { return "Erro ao mapear"; }
            finally
            {
                foreach (var p in processes)
                    try { p.Dispose(); } catch { }
            }
        }

        private static void GetBatteryStatus(out int percent, out bool charging)
        {
            percent  = 100;
            charging = true;
            if (GetSystemPowerStatus(out SystemPowerStatus sps))
            {
                percent  = sps.BatteryLifePercent == 255 ? 100 : sps.BatteryLifePercent;
                charging = sps.ACLineStatus == 1;
            }
        }

        private static void GravarLogNoWindows(string mensagem, string tipo)
        {
            try
            {
                if (mensagem.Length > 1000)
                    mensagem = mensagem[..1000];

                using var process = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName        = "eventcreate",
                        UseShellExecute = false,
                        CreateNoWindow  = true,
                    }
                };
                // ArgumentList escapa os argumentos corretamente — sem risco de injeção via conteúdo da mensagem
                process.StartInfo.ArgumentList.Add("/L");
                process.StartInfo.ArgumentList.Add("APPLICATION");
                process.StartInfo.ArgumentList.Add("/T");
                process.StartInfo.ArgumentList.Add(tipo);
                process.StartInfo.ArgumentList.Add("/ID");
                process.StartInfo.ArgumentList.Add("1001");
                process.StartInfo.ArgumentList.Add("/D");
                process.StartInfo.ArgumentList.Add(mensagem);
                process.Start();
                process.WaitForExit();
            }
            catch { }
        }
    }
}
