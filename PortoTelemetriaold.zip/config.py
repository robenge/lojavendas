import logging
import os
import urllib.parse
from threading import Lock

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

# ── Database ──────────────────────────────────────────────────────────────────
DB_HOST = os.getenv("POSTGRES_HOST") or "localhost"
DB_PORT = os.getenv("POSTGRES_PORT") or "5432"
DB_USER = os.getenv("POSTGRES_USER") or "postgres"
DB_PASS = os.getenv("POSTGRES_PASSWORD") or "3Kt#}2Edr2Y%"
_enc           = urllib.parse.quote(DB_PASS, safe="")
DB_URI         = f"postgresql://{DB_USER}:{_enc}@{DB_HOST}:{DB_PORT}/telemetria"
DB_URI_DEFAULT = f"postgresql://{DB_USER}:{_enc}@{DB_HOST}:{DB_PORT}/postgres"

# ── Auth ──────────────────────────────────────────────────────────────────────
API_TOKEN  = os.getenv("API_TOKEN")      or "Tk8_mQ9!zP2#vX7_wK5@jL3$mR9*fB2!xY8_dE4%qZ1#vW6_sN3"
ADMIN_USER = os.getenv("ADMIN_USER")     or "admin"
ADMIN_PASS = os.getenv("ADMIN_PASSWORD") or "telemetria2026"

# ── Alertas ───────────────────────────────────────────────────────────────────
GOOGLE_CHAT_WEBHOOK = os.getenv("GOOGLE_CHAT_WEBHOOK") or ""
ALERT_COOLDOWN      = int(os.getenv("ALERT_COOLDOWN") or "900")

EMAIL_HOST = os.getenv("EMAIL_HOST") or ""
EMAIL_PORT = int(os.getenv("EMAIL_PORT") or "587")
EMAIL_USER = os.getenv("EMAIL_USER") or ""
EMAIL_PASS = os.getenv("EMAIL_PASS") or ""
EMAIL_FROM = os.getenv("EMAIL_FROM") or ""
EMAIL_TO   = os.getenv("EMAIL_TO")   or ""

# ── Pool de conexões ──────────────────────────────────────────────────────────
DB_POOL_MIN = int(os.getenv("DB_POOL_MIN") or "5")
DB_POOL_MAX = int(os.getenv("DB_POOL_MAX") or "50")

# ── App ───────────────────────────────────────────────────────────────────────
APP_HOST    = "0.0.0.0"
APP_PORT    = 8090
APP_THREADS = int(os.getenv("APP_THREADS") or "16")

# ── Limiares de alerta (editáveis via dashboard, thread-safe) ─────────────────
_lim_lock = Lock()
_limiares  = {"cpu": 85.0, "ram": 90.0, "disco": 90.0}


def get_limiares() -> dict:
    with _lim_lock:
        return dict(_limiares)


def set_limiares(cpu=None, ram=None, disco=None) -> None:
    with _lim_lock:
        if cpu   is not None: _limiares["cpu"]   = float(cpu)
        if ram   is not None: _limiares["ram"]   = float(ram)
        if disco is not None: _limiares["disco"] = float(disco)
