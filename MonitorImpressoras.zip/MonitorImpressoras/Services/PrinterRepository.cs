using System.Collections.Concurrent;
using MonitorImpressoras.Models;

namespace MonitorImpressoras.Services;

public class PrinterRepository
{
    public ConcurrentDictionary<string, PrinterStatus> Devices { get; } = new();
    private readonly string _filePath = "ips.txt";

    public void LoadIpsFromFile()
    {
        if (!File.Exists(_filePath)) return;

        var lines = File.ReadAllLines(_filePath);
        foreach (var line in lines)
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            
            var parts = line.Split(';');
            var ip = parts[0].Trim();
            var local = parts.Length > 1 ? parts[1].Trim() : "Sem Local";

            Devices.TryAdd(ip, new PrinterStatus { IP = ip, Local = local });
        }
    }

    public bool AddIp(string ip, string local)
    {
        ip = ip.Trim();
        if (Devices.TryAdd(ip, new PrinterStatus { IP = ip, Local = local.Trim() }))
        {
            SaveToTxt();
            return true;
        }
        return false;
    }

    public void RemoveIp(string ip)
    {
        if (Devices.TryRemove(ip, out _))
        {
            SaveToTxt();
        }
    }

    private void SaveToTxt()
    {
        var lines = Devices.Values.Select(p => $"{p.IP};{p.Local}");
        File.WriteAllLines(_filePath, lines);
    }
}