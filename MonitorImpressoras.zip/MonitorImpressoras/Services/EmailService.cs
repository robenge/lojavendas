using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using Microsoft.Extensions.Configuration;

namespace MonitorImpressoras.Services;

public class EmailService
{
    private readonly IConfiguration _config;
    private readonly ILogger<EmailService> _logger;
    private static readonly SemaphoreSlim _semaphore = new SemaphoreSlim(1, 1);

    public EmailService(IConfiguration config, ILogger<EmailService> logger)
    {
        _config = config;
        _logger = logger;
    }

    public async Task EnviarAlertaAsync(string ip, string assunto, string mensagem, bool resolvido = false)
    {
        await _semaphore.WaitAsync();
        
        try
        {
            // Lê os dados direto do arquivo na exata hora do disparo
            string remetente = _config["EmailConfig:Remetente"] ?? "";
            string senhaApp = _config["EmailConfig:SenhaApp"] ?? "";
            string destinatarios = _config["EmailConfig:Destinatarios"] ?? "";

            var email = new MimeMessage();
            email.From.Add(new MailboxAddress("Monitor TI", remetente));
            
            var listaEmails = destinatarios.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var dest in listaEmails)
            {
                email.To.Add(new MailboxAddress("", dest.Trim()));
            }

            string icone = resolvido ? "✅" : "⚠️";
            email.Subject = $"{icone} [Impressora {ip}] - {assunto}";

            string cor = resolvido ? "#28a745" : "#dc3545";
            email.Body = new TextPart(MimeKit.Text.TextFormat.Html)
            {
                Text = $@"
                    <div style='font-family: Arial; border: 1px solid #ddd; padding: 20px; border-radius: 5px;'>
                        <h2 style='color: {cor};'>{icone} Alerta de Monitoramento</h2>
                        <p><strong>Equipamento:</strong> Impressora {ip}</p>
                        <p><strong>Status:</strong> {mensagem}</p>
                        <p><strong>Data/Hora:</strong> {DateTime.Now:dd/MM/yyyy HH:mm:ss}</p>
                    </div>"
            };

            using var smtp = new SmtpClient();
            await smtp.ConnectAsync("smtp.gmail.com", 465, SecureSocketOptions.SslOnConnect);
            
            // Usando as variáveis locais novas (sem o underline)
            await smtp.AuthenticateAsync(remetente, senhaApp);
            
            await smtp.SendAsync(email);
            await smtp.DisconnectAsync(true);

            _logger.LogInformation($"Alerta de e-mail enviado para {ip} - {assunto}");
        }
        catch (Exception ex)
        {
            _logger.LogError($"Falha ao enviar e-mail para {ip}: {ex.Message}");
        }
        finally
        {
            _semaphore.Release();
        }
    }
}