using System.Net;
using System.Net.NetworkInformation;
using Lextm.SharpSnmpLib;
using Lextm.SharpSnmpLib.Messaging;
using MonitorImpressoras.Models;

namespace MonitorImpressoras.Services;

public class MonitorService : BackgroundService
{
    private readonly PrinterRepository _repository;
    private readonly EmailService _emailService;
    private readonly ILogger<MonitorService> _logger;
    private const string SnmpCommunity = "public";
    private const int SnmpPort = 161;

    public MonitorService(PrinterRepository repository, EmailService emailService, ILogger<MonitorService> logger)
    {
        _repository = repository;
        _emailService = emailService;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _repository.LoadIpsFromFile();

        while (!stoppingToken.IsCancellationRequested)
        {
            _logger.LogInformation("Iniciando ciclo de verificação...");

            var tasks = _repository.Devices.Values.Select(p => CheckPrinterAsync(p)).ToArray();
            await Task.WhenAll(tasks);

            await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
        }
    }

    private async Task CheckPrinterAsync(PrinterStatus printer)
    {
        try
        {
            using var ping = new Ping();
            var reply = await ping.SendPingAsync(printer.IP, 2000);

            printer.IsOnline = reply.Status == IPStatus.Success;
            printer.LastUpdate = DateTime.Now;

            if (printer.IsOnline)
            {
                await FetchSnmpDataAsync(printer);
            }
            else
            {
                printer.TonerLevel = 0;
                printer.PaperState = "Desconhecido (Offline)";
                printer.ScannerFaulty = false;
            }

            await AvaliarAlertasAsync(printer);
            
            printer.WasOnline = printer.IsOnline; 
        }
        catch (Exception ex)
        {
            printer.IsOnline = false;
            await AvaliarAlertasAsync(printer);
            _logger.LogError($"Erro ao verificar IP {printer.IP}: {ex.Message}");
        }
    }

    private async Task FetchSnmpDataAsync(PrinterStatus printer)
    {
        try
        {
            var target = new IPEndPoint(IPAddress.Parse(printer.IP), SnmpPort);
            
            var oids = new List<Variable>
            {
                new Variable(new ObjectIdentifier("1.3.6.1.2.1.43.11.1.1.8.1.1")),
                new Variable(new ObjectIdentifier("1.3.6.1.2.1.43.11.1.1.9.1.1")),
                new Variable(new ObjectIdentifier("1.3.6.1.2.1.25.3.5.1.2.1"))
            };

            var result = await Task.Run(() => 
                Messenger.Get(VersionCode.V2, target, new OctetString(SnmpCommunity), oids, 2000)
            );

            if (result != null && result.Count >= 3)
            {
                int tonerMax = ParseInt(result[0].Data);
                int tonerCurrent = ParseInt(result[1].Data);
                
                if (tonerMax > 0 && tonerCurrent >= 0)
                {
                    printer.TonerLevel = (tonerCurrent * 100) / tonerMax;
                }
                else
                {
                    printer.TonerLevel = 0;
                }

                ParsePrinterErrors(result[2].Data, printer);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning($"Falha na requisição SNMP para {printer.IP}: {ex.Message}");
        }
    }

    private async Task AvaliarAlertasAsync(PrinterStatus printer)
    {
        string infoDispositivo = $"{printer.IP} ({printer.Local})";

        if (!printer.IsOnline && !printer.AlertOfflineSent)
        {
            await _emailService.EnviarAlertaAsync(printer.IP, "OFFLINE", $"A impressora {infoDispositivo} parou de responder ao Ping de rede.");
            printer.AlertOfflineSent = true;
        }
        else if (printer.IsOnline && printer.AlertOfflineSent)
        {
            await _emailService.EnviarAlertaAsync(printer.IP, "ONLINE", $"A impressora {infoDispositivo} voltou a responder na rede.", true);
            printer.AlertOfflineSent = false;
        }

        if (!printer.IsOnline) return;

        if (printer.TonerLevel <= 15 && !printer.AlertTonerSent)
        {
            await _emailService.EnviarAlertaAsync(printer.IP, "Toner Baixo", $"O toner da impressora {infoDispositivo} atingiu {printer.TonerLevel}%. Considere providenciar a troca.");
            printer.AlertTonerSent = true;
        }
        else if (printer.TonerLevel > 15 && printer.AlertTonerSent)
        {
            await _emailService.EnviarAlertaAsync(printer.IP, "Toner Trocado", $"O nível de toner em {infoDispositivo} está normalizado ({printer.TonerLevel}%).", true);
            printer.AlertTonerSent = false;
        }

        if (printer.PaperState != "OK" && !printer.AlertPaperSent)
        {
            await _emailService.EnviarAlertaAsync(printer.IP, $"Problema com Papel: {printer.PaperState}", $"A impressora {infoDispositivo} reportou: {printer.PaperState}. Verifique a bandeja.");
            printer.AlertPaperSent = true;
        }
        else if (printer.PaperState == "OK" && printer.AlertPaperSent)
        {
            await _emailService.EnviarAlertaAsync(printer.IP, "Papel Normalizado", $"O problema com o papel em {infoDispositivo} foi resolvido.", true);
            printer.AlertPaperSent = false;
        }

        if (printer.ScannerFaulty && !printer.AlertScannerSent)
        {
            await _emailService.EnviarAlertaAsync(printer.IP, "Falha no Scanner", $"A impressora {infoDispositivo} reportou uma falha de subsistema/scanner.");
            printer.AlertScannerSent = true;
        }
        else if (!printer.ScannerFaulty && printer.AlertScannerSent)
        {
            await _emailService.EnviarAlertaAsync(printer.IP, "Scanner Normalizado", $"O subsistema em {infoDispositivo} está respondendo normalmente.", true);
            printer.AlertScannerSent = false;
        }
    }

    private int ParseInt(ISnmpData data)
    {
        if (data is Integer32 intData) return intData.ToInt32();
        if (int.TryParse(data?.ToString(), out int val)) return val;
        return 0;
    }

    private void ParsePrinterErrors(ISnmpData data, PrinterStatus printer)
    {
        if (data == null || string.IsNullOrEmpty(data.ToString()) || data.ToString() == "00")
        {
            printer.PaperState = "OK";
            printer.ScannerFaulty = false;
            return;
        }

        byte[] bytes = data.ToBytes();
        
        if (bytes.Length > 0)
        {
            byte errorByte = bytes[0];

            bool lowPaper = (errorByte & 0x80) != 0; 
            bool noPaper = (errorByte & 0x40) != 0;
            bool paperJam = (errorByte & 0x20) != 0;
            
            if (paperJam) printer.PaperState = "Papel Atolado";
            else if (noPaper) printer.PaperState = "Sem Papel";
            else if (lowPaper) printer.PaperState = "Papel Baixo";
            else printer.PaperState = "OK";

            bool hardwareError = (errorByte & 0x04) != 0 || (errorByte & 0x02) != 0;
            printer.ScannerFaulty = hardwareError;
        }
    }
}