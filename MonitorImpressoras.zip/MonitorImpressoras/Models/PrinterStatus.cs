namespace MonitorImpressoras.Models;

public class PrinterStatus
{
    public string IP { get; set; } = string.Empty;
    public string Local { get; set; } = "Desconhecido";
    public bool IsOnline { get; set; }
    public bool WasOnline { get; set; }
    public int TonerLevel { get; set; }
    public string PaperState { get; set; } = "OK";
    public bool ScannerFaulty { get; set; }
    public DateTime LastUpdate { get; set; }

    public bool AlertOfflineSent { get; set; }
    public bool AlertTonerSent { get; set; }
    public bool AlertPaperSent { get; set; }
    public bool AlertScannerSent { get; set; }
}