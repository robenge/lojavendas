using MonitorImpressoras.Components;

var builder = WebApplication.CreateBuilder(args);

// Ensina o sistema a rodar como um Serviço do Windows nativo
builder.Host.UseWindowsService();

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// ====================================================================
// REGISTRO DOS NOSSOS SERVIÇOS (Sempre antes do builder.Build!)
// ====================================================================
builder.Services.AddSingleton<MonitorImpressoras.Services.PrinterRepository>();
builder.Services.AddHostedService<MonitorImpressoras.Services.MonitorService>();
builder.Services.AddSingleton<MonitorImpressoras.Services.EmailService>();
// ====================================================================

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();