import requests
import time
import json
import socket
import psutil
import uuid
import platform
import getpass
import os
from datetime import datetime

CONFIG_FILE = "config.json"
BUFFER_FILE = "buffer.json"

# =========================
# 📥 CONFIG
# =========================
def load_config():
    try:
        with open(CONFIG_FILE) as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"❌ Arquivo {CONFIG_FILE} não encontrado!")
        return {}

config = load_config()

SERVER = config.get("server", "http://localhost:5000/update")
INTERVAL = config.get("interval", 5)
TOKEN = config.get("token", "")
MACHINE_NAME = config.get("machine_name", "")
OPERATOR_NAME = config.get("operator_name", "")
OPERATOR_ID = config.get("operator_id", "")

# =========================
# 👤 USUÁRIO
# =========================
def get_logged_user():
    """Obtém o usuário logado no sistema"""
    try:
        if platform.system() == "Windows":
            return os.environ.get('USERNAME', getpass.getuser())
        else:
            return os.environ.get('USER', getpass.getuser())
    except:
        return "desconhecido"

def get_computer_name():
    """Obtém o nome do computador"""
    try:
        return socket.gethostname()
    except:
        return "unknown"

def get_domain_user():
    """Tenta obter usuário com domínio (Windows)"""
    try:
        if platform.system() == "Windows":
            import ctypes
            import ctypes.wintypes
            
            GetUserNameEx = ctypes.windll.secur32.GetUserNameExW
            NameSamCompatible = 2  # DOMAIN\User
            
            size = ctypes.wintypes.DWORD(0)
            GetUserNameEx(NameSamCompatible, None, ctypes.byref(size))
            
            if size.value > 0:
                buffer = ctypes.create_unicode_buffer(size.value)
                if GetUserNameEx(NameSamCompatible, buffer, ctypes.byref(size)):
                    return buffer.value
    except:
        pass
    return get_logged_user()

# =========================
# 🖥️ MACHINE INFO
# =========================
def get_machine_id():
    return str(uuid.getnode())

def get_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        try:
            return socket.gethostbyname(socket.gethostname())
        except:
            return "0.0.0.0"

def get_uptime():
    return int(time.time() - psutil.boot_time())

def get_os_info():
    return f"{platform.system()} {platform.release()}"

# =========================
# 📡 WIFI INFO (adicional)
# =========================
def get_wifi_info():
    """Obtém informações do WiFi"""
    wifi_info = {
        "ssid": None,
        "signal": None,
        "quality": None
    }
    
    try:
        if platform.system() == "Windows":
            import subprocess
            import re
            result = subprocess.run(
                ["netsh", "wlan", "show", "interfaces"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            for line in result.stdout.split('\n'):
                if "SSID" in line and "BSSID" not in line:
                    wifi_info["ssid"] = line.split(":")[1].strip()
                elif "Sinal" in line:
                    signal = line.split(":")[1].strip()
                    wifi_info["signal"] = signal
                    signal_map = {"Excelente": 100, "Bom": 75, "Médio": 50, "Ruim": 25}
                    wifi_info["quality"] = signal_map.get(signal, 0)
    except:
        pass
    
    return wifi_info

def get_connection_type():
    """Detecta tipo de conexão (WiFi ou Cabo)"""
    try:
        import psutil
        for iface, stats in psutil.net_if_stats().items():
            if stats.isup:
                if "wlan" in iface.lower() or "wi-fi" in iface.lower() or "wireless" in iface.lower():
                    return "wifi"
                elif "eth" in iface.lower() or "enp" in iface.lower() or "以太网" in iface:
                    return "ethernet"
        return "desconhecido"
    except:
        return "desconhecido"

# =========================
# 📊 COLETA
# =========================
def collect():
    # Nome da máquina
    hostname = MACHINE_NAME if MACHINE_NAME else get_computer_name()
    
    # Usuário logado
    logged_user = get_logged_user()
    domain_user = get_domain_user()
    
    # Nome do operador (prioriza config, depois usuário logado)
    operator = OPERATOR_NAME if OPERATOR_NAME else logged_user
    
    # Informações de rede
    wifi_info = get_wifi_info()
    connection_type = get_connection_type()
    
    return {
        # Informações da máquina
        "hostname": hostname,
        "machine_id": get_machine_id(),
        "ip": get_ip(),
        "os": get_os_info(),
        "uptime": get_uptime(),
        
        # 👤 Informações do usuário (NOVO!)
        "username": logged_user,
        "domain_user": domain_user,
        "operator_name": operator,
        "operator_id": OPERATOR_ID,
        
        # Recursos
        "cpu": psutil.cpu_percent(interval=1),
        "memory": psutil.virtual_memory().percent,
        "disk": psutil.disk_usage('/').percent,
        
        # Rede
        "connection_type": connection_type,
        "wifi": wifi_info,
        
        # Timestamp
        "timestamp": datetime.now().isoformat(),
        "token": TOKEN
    }

# =========================
# 📤 ENVIO
# =========================
def send(data):
    try:
        send_data = data.copy()
        send_data.pop("token", None)
        
        response = requests.post(SERVER, json=send_data, timeout=5)
        return response.status_code == 200
    except Exception as e:
        return False

def print_status(data, success):
    status_icon = "✅" if success else "❌"
    
    print(f"\n{'='*50}")
    print(f"🖥️ {data['hostname']} - {status_icon}")
    print(f"👤 Operador: {data['operator_name']} ({data['username']})")
    print(f"{'='*50}")
    print(f"💻 CPU: {data['cpu']}% | RAM: {data['memory']}% | DISK: {data['disk']}%")
    print(f"🌐 IP: {data['ip']} | Tipo: {data['connection_type']}")
    
    if data.get('wifi', {}).get('ssid'):
        print(f"📶 WiFi: {data['wifi']['ssid']} (Sinal: {data['wifi']['quality']}%)")
    
    print(f"⏱️ Uptime: {data['uptime'] // 3600}h {(data['uptime'] % 3600) // 60}m")
    print(f"{'='*50}")

# =========================
# 🧠 LOOP PRINCIPAL
# =========================
def run():
    print(f"""
╔════════════════════════════════════════════════╗
║     📡 AGENTE DE MONITORAMENTO                 ║
╠════════════════════════════════════════════════╣
║ Servidor: {SERVER[:45]}
║ Máquina:   {MACHINE_NAME or socket.gethostname()}
║ Operador:  {OPERATOR_NAME or get_logged_user()}
╚════════════════════════════════════════════════╝
    """)
    
    buffer = []
    
    while True:
        try:
            data = collect()
            success = send(data)
            print_status(data, success)
            
            if not success:
                buffer.append(data)
                if len(buffer) > 100:
                    buffer = buffer[-100:]
            
            time.sleep(INTERVAL)
            
        except KeyboardInterrupt:
            print("\n🛑 Agente finalizado")
            break
        except Exception as e:
            print(f"❌ Erro: {e}")
            time.sleep(INTERVAL)

if __name__ == "__main__":
    run()