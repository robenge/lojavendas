# Monitoramento de Máquinas

## 🚀 Rodar servidor

cd server
pip install -r requirements.txt
python app.py

Acesse:
http://localhost:5000

---

## 🖥️ Rodar agente

cd agent
pip install -r requirements.txt
python agent.py

---

## ⚠️ Importante

- Alterar IP do servidor no agent.py
- Configurar email em email_alert.py