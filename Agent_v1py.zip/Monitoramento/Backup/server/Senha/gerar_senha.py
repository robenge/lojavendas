from cryptography.fernet import Fernet

key = Fernet.generate_key()
f = Fernet(key)

senha = "dqmn okpi whlh rrph"
enc = f.encrypt(senha.encode())

print("KEY =", key.decode())
print("ENC =", enc.decode())