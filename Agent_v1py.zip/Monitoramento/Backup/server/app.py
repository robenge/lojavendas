import json
import threading
import time
from datetime import datetime, timedelta
from functools import wraps
import sqlite3
from contextlib import contextmanager

from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from flask_socketio import SocketIO
import smtplib
from email.mime.text import MIMEText
import keyring
import hashlib
import secrets
from collections import deque

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)
socketio = SocketIO(app, cors_allowed_origins="*")

# =========================
# 📥 CONFIG
# =========================
with open("config.json", "r") as f:
    config = json.load(f)

EMAIL_FROM = config["email"]["from"]
EMAIL_TO = config["email"]["to"]
SMTP_SERVER = config["email"].get("smtp_server", "smtp.gmail.com")
SMTP_PORT = config["email"].get("smtp_port", 587)

CPU_LIMIT = config["alerts"]["cpu"]
MEM_LIMIT = config["alerts"]["memory"]
DISK_LIMIT = config["alerts"]["disk"]

OFFLINE_THRESHOLD = config.get("monitor", {}).get("offline_threshold", 30)
INTERVAL = config.get("monitor", {}).get("interval", 5)
CLEANUP_DAYS = config.get("monitor", {}).get("cleanup_days", 7)

ADMIN_USERNAME = config.get("auth", {}).get("username", "admin")
ADMIN_PASSWORD_HASH = hashlib.sha256(
    config.get("auth", {}).get("password", "admin123").encode()
).hexdigest()

EMAIL_PASSWORD = keyring.get_password("monitor_app", "email_password")

# =========================
# 💾 DATABASE SETUP
# =========================
DB_NAME = "monitor.db"

@contextmanager
def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def init_db():
    """Inicializa o banco de dados"""
    with get_db() as conn:
        # Tabela de máquinas
        conn.execute('''
            CREATE TABLE IF NOT EXISTS machines (
                hostname TEXT PRIMARY KEY,
                ip TEXT,
                cpu REAL,
                memory REAL,
                disk REAL,
                status TEXT,
                last_seen TEXT,
                uptime INTEGER,
                os TEXT,
                last_update TEXT
            )
        ''')
        
        # Tabela de histórico
        conn.execute('''
            CREATE TABLE IF NOT EXISTS history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hostname TEXT,
                cpu REAL,
                memory REAL,
                disk REAL,
                timestamp TEXT,
                FOREIGN KEY (hostname) REFERENCES machines (hostname)
            )
        ''')
        
        # Tabela de eventos
        conn.execute('''
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                message TEXT,
                hostname TEXT
            )
        ''')
        
        # Índices para melhor performance
        conn.execute('CREATE INDEX IF NOT EXISTS idx_history_hostname ON history(hostname)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_history_timestamp ON history(timestamp)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp)')
        
        print("✅ Banco de dados inicializado")

# =========================
# 📊 STORAGE (em memória + banco)
# =========================
machines = {}  # Cache em memória
offline_alert_sent = {}

# =========================
# 💾 FUNÇÕES DE PERSISTÊNCIA
# =========================
def save_machine_to_db(data):
    """Salva ou atualiza máquina no banco"""
    with get_db() as conn:
        conn.execute('''
            INSERT OR REPLACE INTO machines 
            (hostname, ip, cpu, memory, disk, status, last_seen, uptime, os, last_update)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            data['hostname'],
            data.get('ip', ''),
            data.get('cpu', 0),
            data.get('memory', 0),
            data.get('disk', 0),
            data.get('status', 'online'),
            data.get('last_seen', datetime.now().isoformat()),
            data.get('uptime', 0),
            data.get('os', ''),
            datetime.now().isoformat()
        ))

def save_history_to_db(hostname, cpu, memory, disk):
    """Salva ponto histórico"""
    with get_db() as conn:
        conn.execute('''
            INSERT INTO history (hostname, cpu, memory, disk, timestamp)
            VALUES (?, ?, ?, ?, ?)
        ''', (hostname, cpu, memory, disk, datetime.now().isoformat()))
        
        # Remove histórico antigo (mais de 7 dias)
        week_ago = (datetime.now() - timedelta(days=7)).isoformat()
        conn.execute('DELETE FROM history WHERE timestamp < ?', (week_ago,))

def save_event_to_db(message, hostname=None):
    """Salva evento no banco"""
    with get_db() as conn:
        conn.execute('''
            INSERT INTO events (timestamp, message, hostname)
            VALUES (?, ?, ?)
        ''', (datetime.now().isoformat(), message, hostname))
        
        # Mantém apenas últimos 1000 eventos
        conn.execute('''
            DELETE FROM events WHERE id NOT IN (
                SELECT id FROM events ORDER BY timestamp DESC LIMIT 1000
            )
        ''')

def load_all_machines():
    """Carrega todas as máquinas do banco"""
    with get_db() as conn:
        rows = conn.execute('SELECT * FROM machines').fetchall()
        machines_data = {}
        for row in rows:
            machines_data[row['hostname']] = {
                'hostname': row['hostname'],
                'ip': row['ip'],
                'cpu': row['cpu'],
                'memory': row['memory'],
                'disk': row['disk'],
                'status': row['status'],
                'last_seen': row['last_seen'],
                'uptime': row['uptime'],
                'os': row['os']
            }
        return machines_data

def load_events_from_db(limit=100):
    """Carrega eventos do banco"""
    with get_db() as conn:
        rows = conn.execute('''
            SELECT timestamp, message, hostname 
            FROM events 
            ORDER BY timestamp DESC 
            LIMIT ?
        ''', (limit,)).fetchall()
        
        events = []
        for row in rows:
            events.append({
                'time': datetime.fromisoformat(row['timestamp']).strftime('%H:%M:%S'),
                'timestamp': row['timestamp'],
                'message': row['message'],
                'hostname': row['hostname']
            })
        return events

def load_history_from_db(hostname, limit=100):
    """Carrega histórico de uma máquina"""
    with get_db() as conn:
        rows = conn.execute('''
            SELECT cpu, memory, disk, timestamp 
            FROM history 
            WHERE hostname = ? 
            ORDER BY timestamp DESC 
            LIMIT ?
        ''', (hostname, limit)).fetchall()
        
        history = []
        for row in reversed(rows):  # Ordem cronológica
            history.append({
                'cpu': row['cpu'],
                'memory': row['memory'],
                'disk': row['disk'],
                'timestamp': row['timestamp']
            })
        return history

# =========================
# 🔐 DECORATOR DE AUTENTICAÇÃO
# =========================
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# =========================
# 📧 EMAIL
# =========================
def send_email(subject, body):
    try:
        if not EMAIL_PASSWORD:
            print("[EMAIL] Senha não encontrada no keyring")
            return

        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = EMAIL_FROM
        msg["To"] = ", ".join(EMAIL_TO)

        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as s:
            s.starttls()
            s.login(EMAIL_FROM, EMAIL_PASSWORD)
            s.send_message(msg)

        print("[EMAIL] Enviado:", subject)

    except Exception as e:
        print("[EMAIL ERROR]", e)

# =========================
# 📜 LOG EVENTOS
# =========================
def log_event(message, hostname=None):
    event = {
        "time": datetime.now().strftime("%H:%M:%S"),
        "timestamp": datetime.now().isoformat(),
        "message": message,
        "hostname": hostname
    }
    
    # Salvar no banco
    save_event_to_db(message, hostname)
    
    # Manter em memória para acesso rápido
    if not hasattr(app, 'events_cache'):
        app.events_cache = []
    app.events_cache.append(event)
    if len(app.events_cache) > 1000:
        app.events_cache.pop(0)
    
    print("[EVENT]", message)

# =========================
# 🚨 ALERTAS
# =========================
def check_alerts(hostname, data):
    if data["cpu"] > CPU_LIMIT:
        msg = f"{hostname} CPU alta: {data['cpu']}%"
        log_event(msg, hostname)
        send_email("ALERTA CPU", msg)

    if data["memory"] > MEM_LIMIT:
        msg = f"{hostname} RAM alta: {data['memory']}%"
        log_event(msg, hostname)
        send_email("ALERTA MEMORIA", msg)

    if data["disk"] > DISK_LIMIT:
        msg = f"{hostname} Disco alto: {data['disk']}%"
        log_event(msg, hostname)
        send_email("ALERTA DISCO", msg)

# =========================
# 📥 RECEBE DADOS DO AGENT
# =========================
@app.route("/update", methods=["POST"])
def update():
    try:
        data = request.json
        hostname = data["hostname"]

        # Garantir campos obrigatórios
        data.setdefault("cpu", 0)
        data.setdefault("memory", 0)
        data.setdefault("disk", 0)
        data.setdefault("ip", "")
        data.setdefault("os", "")
        data.setdefault("uptime", 0)
        data["last_seen"] = datetime.now().isoformat()
        data["status"] = "online"
        
        # Salvar no banco de dados
        save_machine_to_db(data)
        save_history_to_db(hostname, data["cpu"], data["memory"], data["disk"])
        
        # Atualizar cache em memória
        machines[hostname] = data

        print(f"[UPDATE] {hostname}: CPU={data['cpu']}% RAM={data['memory']}% DISK={data['disk']}%")

        # Se estava offline e voltou, enviar notificação
        if hostname in offline_alert_sent and offline_alert_sent[hostname]:
            msg = f"{hostname} voltou a ficar ONLINE"
            log_event(msg, hostname)
            send_email("MONITOR ONLINE", msg)
            offline_alert_sent[hostname] = False

        check_alerts(hostname, data)

        return jsonify({"status": "ok"})

    except Exception as e:
        print("[ERRO UPDATE]", e)
        return jsonify({"status": "error"}), 500

# =========================
# 🔍 MONITOR ONLINE/OFFLINE
# =========================
def monitor():
    while True:
        now = datetime.now()
        changed = False

        for host, data in list(machines.items()):
            try:
                last = datetime.fromisoformat(data["last_seen"])
                diff = (now - last).total_seconds()

                if diff <= OFFLINE_THRESHOLD:
                    new_status = "online"
                else:
                    new_status = "offline"

                if data.get("status") != new_status:
                    changed = True
                    data["status"] = new_status
                    log_event(f"{host} ficou {new_status.upper()}", host)
                    
                    # Atualizar status no banco
                    with get_db() as conn:
                        conn.execute('''
                            UPDATE machines SET status = ?, last_update = ?
                            WHERE hostname = ?
                        ''', (new_status, datetime.now().isoformat(), host))

                    if new_status == "offline":
                        if not offline_alert_sent.get(host, False):
                            msg = f"{host} está OFFLINE há mais de {OFFLINE_THRESHOLD}s"
                            send_email("ALERTA OFFLINE", msg)
                            offline_alert_sent[host] = True
                    else:
                        offline_alert_sent[host] = False

            except Exception as e:
                print(f"[ERRO MONITOR] {host}:", e)

        cleanup_dead_machines(now)

        if changed or True:
            socketio.emit("update", machines)

        time.sleep(INTERVAL)

def cleanup_dead_machines(now):
    """Remove máquinas inativas do banco"""
    to_remove = []
    for host, data in machines.items():
        try:
            last_seen = datetime.fromisoformat(data["last_seen"])
            days_inactive = (now - last_seen).total_seconds() / 86400
            if days_inactive > CLEANUP_DAYS:
                to_remove.append(host)
        except:
            pass

    for host in to_remove:
        log_event(f"Removendo máquina inativa: {host}")
        with get_db() as conn:
            conn.execute('DELETE FROM machines WHERE hostname = ?', (host,))
            # Mantém histórico para relatórios
        del machines[host]

# =========================
# 🌐 ROTAS WEB
# =========================
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        if username == ADMIN_USERNAME and password_hash == ADMIN_PASSWORD_HASH:
            session['logged_in'] = True
            session['username'] = username
            return redirect(url_for('index'))
        else:
            return render_template("login.html", error="Credenciais inválidas!")
    
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route("/")
@login_required
def index():
    return render_template("dashboard.html")

@app.route("/api/machines")
@login_required
def api_machines():
    return jsonify(machines)

@app.route("/api/events")
@login_required
def api_events():
    events = load_events_from_db(100)
    return jsonify(events)

@app.route("/api/history/<hostname>")
@login_required
def api_history(hostname):
    history = load_history_from_db(hostname, 100)
    return jsonify(history)

@app.route("/api/history/all")
@login_required
def api_history_all():
    with get_db() as conn:
        rows = conn.execute('''
            SELECT hostname, cpu, memory, disk, timestamp 
            FROM history 
            ORDER BY timestamp DESC
        ''').fetchall()
        
        history = {}
        for row in rows:
            if row['hostname'] not in history:
                history[row['hostname']] = []
            history[row['hostname']].append({
                'cpu': row['cpu'],
                'memory': row['memory'],
                'disk': row['disk'],
                'timestamp': row['timestamp']
            })
        
        # Limitar a 100 por máquina
        for host in history:
            history[host] = history[host][-100:]
        
        return jsonify(history)

@app.route("/api/export/csv")
@login_required
def export_csv():
    import csv
    import io
    from flask import Response
    
    output = io.StringIO()
    writer = csv.writer(output)
    
    writer.writerow(['Hostname', 'Status', 'CPU (%)', 'Memory (%)', 'Disk (%)', 'Last Seen', 'IP', 'OS'])
    
    for hostname, data in machines.items():
        writer.writerow([
            hostname,
            data.get('status', 'unknown'),
            data.get('cpu', 0),
            data.get('memory', 0),
            data.get('disk', 0),
            data.get('last_seen', ''),
            data.get('ip', ''),
            data.get('os', '')
        ])
    
    output.seek(0)
    return Response(
        output,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=monitor_report.csv"}
    )

@app.route("/api/export/events/csv")
@login_required
def export_events_csv():
    import csv
    import io
    from flask import Response
    
    output = io.StringIO()
    writer = csv.writer(output)
    
    writer.writerow(['Timestamp', 'Message', 'Hostname'])
    
    events = load_events_from_db(10000)
    for event in events:
        writer.writerow([
            event.get('timestamp', event.get('time', '')),
            event.get('message', ''),
            event.get('hostname', '')
        ])
    
    output.seek(0)
    return Response(
        output,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=events_report.csv"}
    )

@app.route("/api/stats")
@login_required
def api_stats():
    with get_db() as conn:
        # Total de máquinas
        total = conn.execute('SELECT COUNT(*) as count FROM machines').fetchone()['count']
        
        # Online/Offline
        online = conn.execute('SELECT COUNT(*) as count FROM machines WHERE status = "online"').fetchone()['count']
        offline = total - online
        
        # Alertas nas últimas 24h
        day_ago = (datetime.now() - timedelta(days=1)).isoformat()
        alerts = conn.execute('''
            SELECT COUNT(*) as count FROM events 
            WHERE timestamp > ? AND (message LIKE "%alta%" OR message LIKE "%OFFLINE%")
        ''', (day_ago,)).fetchone()['count']
        
        return jsonify({
            'total': total,
            'online': online,
            'offline': offline,
            'alerts': alerts
        })

# =========================
# 🚀 START
# =========================
if __name__ == "__main__":
    # Inicializar banco de dados
    init_db()
    
    # Carregar dados existentes
    machines.update(load_all_machines())
    print(f"📦 Carregadas {len(machines)} máquinas do banco de dados")
    
    # Iniciar monitor
    thread = threading.Thread(target=monitor)
    thread.daemon = True
    thread.start()
    
    socketio.run(app, host="0.0.0.0", port=5000, debug=True)