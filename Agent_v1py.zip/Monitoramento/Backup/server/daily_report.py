import sqlite3
from datetime import datetime, timedelta

def daily_report():
    conn = sqlite3.connect('monitor.db')
    cursor = conn.cursor()
    
    hoje = datetime.now().strftime('%Y-%m-%d')
    ontem = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    
    print(f"\n📊 RELATÓRIO DIÁRIO - {hoje}")
    print("="*50)
    
    # Máquinas ativas hoje
    cursor.execute("""
        SELECT COUNT(DISTINCT hostname) 
        FROM history 
        WHERE DATE(timestamp) = ?
    """, (hoje,))
    ativas = cursor.fetchone()[0]
    print(f"✅ Máquinas ativas hoje: {ativas}")
    
    # Novas máquinas
    cursor.execute("""
        SELECT COUNT(*) 
        FROM machines 
        WHERE DATE(last_update) = ?
    """, (hoje,))
    novas = cursor.fetchone()[0]
    print(f"🆕 Novas máquinas hoje: {novas}")
    
    # Alertas do dia
    cursor.execute("""
        SELECT COUNT(*) 
        FROM events 
        WHERE DATE(timestamp) = ?
    """, (hoje,))
    alertas = cursor.fetchone()[0]
    print(f"🚨 Alertas hoje: {alertas}")
    
    # Máquinas com problema
    cursor.execute("""
        SELECT hostname, cpu, memory, disk
        FROM machines
        WHERE cpu > 80 OR memory > 80 OR disk > 90
    """)
    problemas = cursor.fetchall()
    
    if problemas:
        print(f"\n⚠️ MÁQUINAS COM PROBLEMAS:")
        for p in problemas:
            print(f"   - {p[0]}: CPU={p[1]}% MEM={p[2]}% DISK={p[3]}%")
    
    conn.close()

if __name__ == "__main__":
    daily_report()