@echo off

echo Configurando credencial segura...

set KEY="JFZzfpS8nGPP-Fp-dS7TCSWmqJtLKpf4Wo2NzqpVSp8="
set ENC="gAAAAABp7WpkszC-7UEd9hDSZlZZeKr80lkKfAFtPTA7pnJq7-i9U1UAtxmyI3AB8bL0ICr2bSSMXZLVEX65-B9wOrWJyk4hP6-SElFR23ZWCjvrOkzVy18="

python -c "from cryptography.fernet import Fernet; import keyring; f=Fernet(b'%KEY%'); senha=f.decrypt(b'%ENC%').decode(); keyring.set_password('monitor_app','email_password', senha)"

echo Credencial salva no Windows com sucesso!
pause