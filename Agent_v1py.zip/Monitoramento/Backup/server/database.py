import sqlite3

def init_db():
    conn = sqlite3.connect("monitor.db")
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS metrics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hostname TEXT,
        cpu REAL,
        memory REAL,
        disk REAL,
        timestamp TEXT
    )
    """)

    conn.commit()
    conn.close()


def insert_metric(hostname, cpu, memory, disk, timestamp):
    conn = sqlite3.connect("monitor.db")
    c = conn.cursor()

    c.execute("""
    INSERT INTO metrics (hostname, cpu, memory, disk, timestamp)
    VALUES (?, ?, ?, ?, ?)
    """, (hostname, cpu, memory, disk, timestamp))

    conn.commit()
    conn.close()


def get_history(hostname):
    conn = sqlite3.connect("monitor.db")
    c = conn.cursor()

    c.execute("""
    SELECT cpu, memory, disk, timestamp
    FROM metrics
    WHERE hostname = ?
    ORDER BY timestamp DESC
    LIMIT 20
    """)

    data = c.fetchall()
    conn.close()

    return list(reversed(data))