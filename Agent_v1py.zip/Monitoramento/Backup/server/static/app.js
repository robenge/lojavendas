// static/app.js
const socket = io();

// Variáveis globais
let machinesData = {};
let eventsData = [];
let updateInterval = null;

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    console.log('✅ App inicializado');
    loadInitialData();
    startAutoRefresh();
});

// Carregar dados iniciais
async function loadInitialData() {
    await loadMachines();
    await loadEvents();
}

// Carregar máquinas via API
async function loadMachines() {
    try {
        const response = await fetch('/api/machines');
        const data = await response.json();
        machinesData = data;
        renderMachines();
        updateStats();
    } catch (error) {
        console.error('Erro ao carregar máquinas:', error);
    }
}

// Carregar eventos via API
async function loadEvents() {
    try {
        const response = await fetch('/api/events');
        const data = await response.json();
        eventsData = data;
        renderEvents();
    } catch (error) {
        console.error('Erro ao carregar eventos:', error);
    }
}

// Renderizar máquinas
function renderMachines() {
    const container = document.getElementById('machines');
    if (!container) return;
    
    if (Object.keys(machinesData).length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div style="font-size: 3em;">🤖</div>
                <h3>Nenhuma máquina conectada</h3>
                <p>Aguardando dados dos agentes...</p>
            </div>
        `;
        return;
    }
    
    let html = '<div class="machines-grid">';
    
    for (const [hostname, data] of Object.entries(machinesData)) {
        const statusClass = data.status === 'online' ? 'status-online' : 'status-offline';
        const statusText = data.status === 'online' ? '🟢 ONLINE' : '🔴 OFFLINE';
        
        // Cores baseadas nos limites
        const cpuColor = getColorByValue(data.cpu, 75);
        const memColor = getColorByValue(data.memory, 70);
        const diskColor = getColorByValue(data.disk, 75);
        
        const lastSeen = data.last_seen ? new Date(data.last_seen).toLocaleString() : 'Nunca';
        const ip = data.ip || 'IP não disponível';
        
        html += `
            <div class="machine-card" onclick="showMachineDetails('${hostname}')">
                <div class="machine-header">
                    <div class="machine-name">
                        <strong>${escapeHtml(hostname)}</strong><br>
                        <small style="font-size: 0.8em; color: #666;">${escapeHtml(ip)}</small>
                    </div>
                    <div class="status ${statusClass}">${statusText}</div>
                </div>
                
                <div class="machine-stats">
                    <div>
                        <div class="stat-item">
                            <span class="stat-label">💻 CPU</span>
                            <span class="stat-value" style="color: ${cpuColor}">${data.cpu || 0}%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${data.cpu || 0}%; background: ${cpuColor}"></div>
                        </div>
                    </div>
                    
                    <div>
                        <div class="stat-item">
                            <span class="stat-label">🧠 RAM</span>
                            <span class="stat-value" style="color: ${memColor}">${data.memory || 0}%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${data.memory || 0}%; background: ${memColor}"></div>
                        </div>
                    </div>
                    
                    <div>
                        <div class="stat-item">
                            <span class="stat-label">💾 DISCO</span>
                            <span class="stat-value" style="color: ${diskColor}">${data.disk || 0}%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${data.disk || 0}%; background: ${diskColor}"></div>
                        </div>
                    </div>
                </div>
                
                <div class="last-seen">
                    📅 ${lastSeen}
                </div>
            </div>
        `;
    }
    
    html += '</div>';
    container.innerHTML = html;
}

// Renderizar eventos
function renderEvents() {
    const container = document.getElementById('events');
    if (!container) return;
    
    if (eventsData.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div style="font-size: 3em;">📭</div>
                <h3>Nenhum evento registrado</h3>
                <p>Eventos aparecerão aqui quando ocorrerem alertas</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    eventsData.slice().reverse().forEach(event => {
        let icon = 'ℹ️';
        let borderColor = '#667eea';
        
        if (event.message.includes('CPU')) {
            icon = '⚠️';
            borderColor = '#dc3545';
        }
        if (event.message.includes('RAM') || event.message.includes('MEMORIA')) {
            icon = '⚠️';
            borderColor = '#dc3545';
        }
        if (event.message.includes('DISCO')) {
            icon = '⚠️';
            borderColor = '#dc3545';
        }
        if (event.message.includes('ONLINE')) {
            icon = '✅';
            borderColor = '#28a745';
        }
        if (event.message.includes('OFFLINE')) {
            icon = '❌';
            borderColor = '#dc3545';
        }
        
        html += `
            <div class="event-item" style="border-left-color: ${borderColor}">
                <div class="event-time">${icon} ${event.time || event.timestamp}</div>
                <div class="event-message">${escapeHtml(event.message)}</div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// Atualizar estatísticas
function updateStats() {
    const totalSpan = document.getElementById('totalMachines');
    const onlineSpan = document.getElementById('onlineMachines');
    const offlineSpan = document.getElementById('offlineMachines');
    const alertSpan = document.getElementById('alertCount');
    
    if (!totalSpan) return;
    
    const total = Object.keys(machinesData).length;
    let online = 0;
    let offline = 0;
    let alerts = 0;
    
    Object.values(machinesData).forEach(machine => {
        if (machine.status === 'online') online++;
        else offline++;
        
        if (machine.cpu > 75) alerts++;
        if (machine.memory > 70) alerts++;
        if (machine.disk > 75) alerts++;
    });
    
    totalSpan.textContent = total;
    onlineSpan.textContent = online;
    offlineSpan.textContent = offline;
    alertSpan.textContent = alerts;
}

// Mostrar detalhes da máquina (modal)
function showMachineDetails(hostname) {
    const machine = machinesData[hostname];
    if (!machine) return;
    
    const modal = document.getElementById('modal');
    const modalBody = document.getElementById('modalBody');
    
    if (!modal || !modalBody) return;
    
    const statusClass = machine.status === 'online' ? 'status-online' : 'status-offline';
    const statusText = machine.status === 'online' ? '🟢 ONLINE' : '🔴 OFFLINE';
    const lastSeen = machine.last_seen ? new Date(machine.last_seen).toLocaleString() : 'Nunca';
    
    modalBody.innerHTML = `
        <h3>${escapeHtml(hostname)}</h3>
        <p><strong>IP:</strong> ${escapeHtml(machine.ip || 'N/A')}</p>
        <p><strong>Status:</strong> <span class="status ${statusClass}">${statusText}</span></p>
        <p><strong>CPU:</strong> ${machine.cpu || 0}%</p>
        <p><strong>Memória RAM:</strong> ${machine.memory || 0}%</p>
        <p><strong>Disco:</strong> ${machine.disk || 0}%</p>
        <p><strong>Última atualização:</strong> ${lastSeen}</p>
        <hr>
        <button class="btn btn-primary" onclick="closeModal()">Fechar</button>
    `;
    
    modal.classList.add('active');
}

// Fechar modal
function closeModal() {
    const modal = document.getElementById('modal');
    if (modal) {
        modal.classList.remove('active');
    }
}

// Alternar abas
function switchTab(tabName) {
    // Atualizar botões
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    if (event && event.target) {
        event.target.classList.add('active');
    }
    
    // Atualizar conteúdos
    const machinesTab = document.getElementById('machinesTab');
    const chartsTab = document.getElementById('chartsTab');
    const eventsTab = document.getElementById('eventsTab');
    
    if (machinesTab) machinesTab.classList.remove('active');
    if (chartsTab) chartsTab.classList.remove('active');
    if (eventsTab) eventsTab.classList.remove('active');
    
    if (tabName === 'machines' && machinesTab) {
        machinesTab.classList.add('active');
        renderMachines();
    } else if (tabName === 'charts' && chartsTab) {
        chartsTab.classList.add('active');
        if (typeof updateChart === 'function') updateChart();
    } else if (tabName === 'events' && eventsTab) {
        eventsTab.classList.add('active');
        renderEvents();
    }
}

// Exportar CSV
async function exportCSV() {
    window.location.href = '/api/export/csv';
}

async function exportEventsCSV() {
    window.location.href = '/api/export/events/csv';
}

// Refresh manual
async function refreshData() {
    await loadMachines();
    await loadEvents();
    showNotification('Dados atualizados!', 'success');
}

// Logout
function logout() {
    window.location.href = '/logout';
}

// Mostrar notificação
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 20px;
        background: ${type === 'success' ? '#28a745' : '#17a2b8'};
        color: white;
        border-radius: 8px;
        z-index: 9999;
        animation: slideIn 0.3s ease;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Função auxiliar: cor baseada no valor
function getColorByValue(value, limit) {
    if (value > limit) return '#dc3545';
    if (value > limit * 0.7) return '#ffc107';
    return '#28a745';
}

// Escapar HTML
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Auto-refresh
function startAutoRefresh() {
    if (updateInterval) clearInterval(updateInterval);
    updateInterval = setInterval(() => {
        loadMachines();
        loadEvents();
    }, 10000);
}

// Socket.IO eventos
socket.on('connect', () => {
    console.log('✅ Conectado ao servidor WebSocket');
});

socket.on('update', (data) => {
    machinesData = data;
    renderMachines();
    updateStats();
});

// Inicializar modal (fechar ao clicar fora)
window.onclick = function(event) {
    const modal = document.getElementById('modal');
    if (event.target === modal) {
        closeModal();
    }
};

// Adicionar CSS para animação
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
`;
document.head.appendChild(style);