import smtplib
from email.mime.text import MIMEText

def send_email(subject, message):
    sender = "seuemail@gmail.com"
    password = "SENHA_APP"
    receiver = "destino@email.com"

    msg = MIMEText(message)
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = receiver

    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login(sender, password)
            server.send_message(msg)
    except Exception as e:
        print("Erro ao enviar email:", e)