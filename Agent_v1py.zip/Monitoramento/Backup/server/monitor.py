from datetime import datetime, timedelta
import time
from email_alert import send_email

TIMEOUT = 15  # segundos

def monitor_loop(machines):
    while True:
        now = datetime.now()

        for host, info in machines.items():
            # Detectar OFFLINE
            if info["online"] and now - info["last_seen"] > timedelta(seconds=TIMEOUT):
                info["online"] = False
                send_email(
                    "🚨 Máquina OFFLINE",
                    f"{host} perdeu conexão em {now}"
                )

            # Detectar reconexão
            if not info["online"] and now - info["last_seen"] <= timedelta(seconds=TIMEOUT):
                info["online"] = True
                send_email(
                    "✅ Máquina ONLINE",
                    f"{host} reconectou em {now}"
                )

        time.sleep(5)