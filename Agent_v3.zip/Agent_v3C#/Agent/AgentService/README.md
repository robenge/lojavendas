# 📞 VoIP Monitor Enterprise

Sistema de monitoramento Enterprise para ambientes de Contact Center, VoIP, Google Meet, Zoom e NICE CXOne.

O projeto é composto por:

- 🖥️ Agent Windows (.NET Worker Service)
- 🚀 API Backend (FastAPI)
- 📊 Dashboard Web (Bootstrap 5 + Chart.js)
- 🧠 QoE Engine (Quality of Experience)
- 📞 NICE CXOne Monitoring
- 🌐 Internet Monitoring
- 🎧 Audio Device Monitoring

---

# 🚀 Principais Recursos

## 🌐 Monitoramento de Internet

- Ping
- Jitter
- Packet Loss
- Status Online/Offline

---

## 📞 Monitoramento NICE CXOne

- RTT NICE
- DNS Check
- WebSocket Check
- TURN Check
- RTP Check
- Região São Paulo
- Região Rio de Janeiro

---

## 🎧 Monitoramento de Áudio

- Headset conectado
- Headset desconectado
- Microfone ativo
- Dispositivo de saída
- Dispositivo de entrada
- Status mute

Compatível com:

- Plantronics
- Poly
- Jabra
- USB Headsets

---

## 📡 Plataformas de Comunicação

Detecção automática:

- Google Meet
- NICE CXOne
- Zoom

---

## 🖥️ Telemetria do Sistema

- CPU
- RAM
- Disco
- Uptime

---

## 🧠 Processos

Top processos por consumo de memória.

Exemplo:

```text
chrome.exe
explorer.exe
Teams.exe
📊 Dashboard Enterprise
Multi-Machine

Visualização simultânea de múltiplos computadores.

Machine Details

Ao clicar em uma máquina:

Informações detalhadas
Histórico
Gráficos
Alertas
Plataformas
📈 Gráficos
NICE RTT

Histórico de latência.

VoIP Quality

Score de qualidade da chamada.

CPU Usage

Histórico de CPU.

Memory Usage

Histórico de memória.

🏗️ Arquitetura
+----------------+
| Windows Agent  |
+----------------+
        |
        |
        v
+----------------+
| FastAPI Backend|
+----------------+
        |
        |
        v
+----------------+
| SQLite         |
+----------------+
        |
        |
        v
+----------------+
| Dashboard      |
+----------------+
📂 Estrutura
Projeto

├── AgentService
│
├── Services
│   ├── ApiService.cs
│   ├── AudioService.cs
│   ├── NetworkService.cs
│   ├── NiceNetworkService.cs
│   ├── WebRtcServer.cs
│
├── Models
│   ├── Metrics.cs
│
├── Back
│   ├── main.py
│   ├── dashboard.html
│   ├── metrics.db
│
└── Extension
    ├── manifest.json
    ├── content.js
⚙️ Instalação Backend
Python

Instalar dependências:

pip install fastapi uvicorn

Executar:

python main.py

Backend:

http://localhost:8000
⚙️ Instalação Agent
.NET 8

Instalar dependências:

dotnet add package NAudio

Compilar:

dotnet build

Executar:

dotnet run
⚙️ Configuração
appsettings.json
{
  "Api": {
    "Url": "http://localhost:8000",
    "Token": "123"
  },
  "Agent": {
    "IntervalSeconds": 5
  }
}
📞 NICE CXOne Endpoints
São Paulo
is-wrtc-sprwrr.cxonevoice.com
Rio de Janeiro
is-wrtc-riowrr.cxonevoice.com
🔒 Segurança

O sistema NÃO armazena:

URLs completas das reuniões
Tokens de autenticação
Conteúdo das chamadas
Áudio
Vídeo

Apenas métricas operacionais são coletadas.

📊 QoE Score

O sistema gera automaticamente um score de qualidade.

Exemplo:

Score	Status
95-100	Excelente
85-94	Bom
70-84	Atenção
<70	Crítico
🚨 Alertas

Alertas automáticos para:

Headset desconectado
Alta latência
Packet loss
CPU elevada
RAM elevada
NICE indisponível
🛣️ Roadmap
V2
 PostgreSQL
 InfluxDB
 Grafana
 WebSocket Live Update
 Windows Service Installer
 Auto Update Agent
V3
 Remote Diagnostics
 Remote Reboot
 Remote Commands
 Remote Support
V4
 AI QoE Engine
 Predictive Monitoring
 Capacity Planning
 Voice Analytics
📜 Licença

MIT License

👨‍💻 Autor

Robson Oliveira

VoIP Monitor Enterprise Project

Brasil 🇧🇷


Esse README já está no padrão de projeto open-source profissional para publicar no GitHub, com arquitetura, recursos, roadmap e instruções de instalação.