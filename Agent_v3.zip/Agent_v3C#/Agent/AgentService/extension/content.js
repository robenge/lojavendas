console.log("[VOIP EXTENSION] LOADED");

// =====================================================
// INJECT SCRIPT
// =====================================================

const script =
    document.createElement("script");

script.src =
    chrome.runtime.getURL(
        "injected.js"
    );

script.onload = function()
{
    this.remove();
};

(document.head || document.documentElement)
    .appendChild(script);

// =====================================================
// RECEIVE PAGE DATA
// =====================================================

window.addEventListener(
    "message",

    async (event) =>
    {
        if (
            event.source != window
        )
        {
            return;
        }

        if (
            event.data.type
            !== "WEBRTC_STATS"
        )
        {
            return;
        }

        console.log(
            "[WEBRTC STATS]",
            event.data.data
        );

        try
        {
            await fetch(
                "http://localhost:9876/webrtc",
                {
                    method: "POST",

                    headers:
                    {
                        "Content-Type":
                            "application/json"
                    },

                    body:
                        JSON.stringify(
                            event.data.data
                        )
                }
            );
        }
        catch (e)
        {
            console.log(
                "[EXT ERROR]",
                e
            );
        }
    }
);