console.log("[WEBRTC INJECTED] STARTED");

// =====================================================
// STORE PEERS
// =====================================================

window.__peerConnections = [];

// =====================================================
// HOOK
// =====================================================

const OriginalRTCPeerConnection =
    window.RTCPeerConnection;

window.RTCPeerConnection =
    function(...args)
{
    const pc =
        new OriginalRTCPeerConnection(...args);

    console.log(
        "[WEBRTC] PEER CREATED"
    );

    window.__peerConnections.push(pc);

    return pc;
};

// =====================================================
// STATS LOOP
// =====================================================

async function collectStats()
{
    let result =
    {
        platform: "Google Meet",

        active: true,

        inCall: false,

        muted: false,

        webrtc_rtt: 0,

        webrtc_jitter: 0,

        webrtc_packet_loss: 0,

        webrtc_bitrate: 0,

        webrtc_codec: ""
    };

    try
    {
        for (
            const pc of
            window.__peerConnections
        )
        {
            const stats =
                await pc.getStats();

            stats.forEach(report =>
            {
                // =============================
                // RTT
                // =============================

                if (
                    report.type ===
                    "candidate-pair"
                )
                {
                    if (
                        report.currentRoundTripTime
                    )
                    {
                        result.webrtc_rtt =
                            Math.round(
                                report
                                .currentRoundTripTime
                                * 1000
                            );
                    }
                }

                // =============================
                // RTP
                // =============================

                if (
                    report.type ===
                    "inbound-rtp"
                )
                {
                    result.inCall = true;

                    if (
                        report.jitter
                    )
                    {
                        result.webrtc_jitter =
                            Math.round(
                                report.jitter
                                * 1000
                            );
                    }

                    if (
                        report.packetsLost
                    )
                    {
                        result.webrtc_packet_loss =
                            report.packetsLost;
                    }

                    if (
                        report.bytesReceived
                    )
                    {
                        result.webrtc_bitrate =
                            report.bytesReceived;
                    }

                    if (
                        report.codecId
                    )
                    {
                        result.webrtc_codec =
                            report.codecId;
                    }
                }
            });
        }

        window.postMessage(
            {
                type: "WEBRTC_STATS",
                data: result
            },
            "*"
        );
    }
    catch (e)
    {
        console.log(
            "[WEBRTC ERROR]",
            e
        );
    }
}

// =====================================================
// LOOP
// =====================================================

setInterval(
    collectStats,
    5000
);