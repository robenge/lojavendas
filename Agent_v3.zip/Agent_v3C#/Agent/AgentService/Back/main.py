from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel

import sqlite3
import json
import jwt
from datetime import datetime, timedelta

# =====================================================
# CONFIGURAÇÕES DE SEGURANÇA (JWT)
# =====================================================
SECRET_KEY = "sua_chave_secreta_super_complexa_aqui"  # Mude em produção
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 120

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# Em um cenário real, isso viria do banco de dados com a senha em hash
USERS_DB = {
    "sysadmin": {
        "username": "sysadmin",
        "password": "123"  # A senha que o usuário vai digitar
    }
}

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Credenciais inválidas ou token expirado",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except jwt.PyJWTError:
        raise credentials_exception
        
    if username not in USERS_DB:
        raise credentials_exception
    return username

# =====================================================
# FASTAPI
# =====================================================
app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")

# =====================================================
# DATABASE & CACHE
# =====================================================
conn = sqlite3.connect("metrics.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS metrics_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    machine TEXT,
    timestamp TEXT,
    voip_score INTEGER,
    nice_latency INTEGER,
    packet_loss REAL,
    cpu REAL,
    memory REAL,
    internet_status TEXT,
    nice_status TEXT,
    json TEXT
)
""")
conn.commit()

latest_metrics = {}
selected_region = "São Paulo"

# =====================================================
# MODEL
# =====================================================
class Metrics(BaseModel):
    MachineName: str
    Username: str
    Cpu: float
    Memory: float
    Disk: float
    Uptime: float
    InternetStatus: str
    Ping: int
    Jitter: float
    PacketLoss: float
    WebrtcRtt: float = 0
    WebrtcJitter: float = 0
    WebrtcPacketLoss: float = 0
    WebrtcBitrate: float = 0
    WebrtcCodec: str = ""
    NiceStatus: str
    NiceLatency: int
    NicePacketLoss: float
    NiceDnsOk: bool
    NiceWebSocketOk: bool
    NiceTurnOk: bool
    NiceRtpOk: bool
    NiceRegion: str
    VoipScore: int
    InCall: bool
    Muted: bool
    HeadsetConnected: bool
    HeadsetName: str
    InputDevice: str = ""
    OutputDevice: str = ""
    CommunicationPlatform: str
    CommunicationActive: bool
    GoogleMeetRunning: bool
    NiceCxOneRunning: bool
    ZoomRunning: bool
    Manufacturer: str
    Model: str
    Serial: str
    WindowsVersion: str
    Anomaly: str
    Alerts: list
    Processes: list
    Timestamp: str

# =====================================================
# AUTENTICAÇÃO E DASHBOARD
# =====================================================

@app.post("/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = USERS_DB.get(form_data.username)
    if not user or user["password"] != form_data.password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuário ou senha incorretos",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token = create_access_token(data={"sub": user["username"]})
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    with open("dashboard.html", "r", encoding="utf-8") as f:
        return f.read()

# =====================================================
# ROTAS PROTEGIDAS (Adicionado: Depends(get_current_user))
# =====================================================

@app.post("/region/{region}")
async def set_region(region: str, current_user: str = Depends(get_current_user)):
    global selected_region
    selected_region = region
    return {"status": "ok", "region": region}

@app.get("/region")
async def get_region(current_user: str = Depends(get_current_user)):
    return {"region": selected_region}

@app.post("/metrics")
async def receive_metrics(data: Metrics):
    # Nota: A rota que RECEBE métricas do Agente geralmente usa uma API Key em vez de JWT de usuário.
    # Por enquanto mantive aberta, mas você pode protegê-la com um token estático depois.
    latest_metrics[data.MachineName] = data.dict()
    cursor.execute("""
    INSERT INTO metrics_history (machine, timestamp, voip_score, nice_latency, packet_loss, cpu, memory, internet_status, nice_status, json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (data.MachineName, data.Timestamp, data.VoipScore, data.NiceLatency, data.PacketLoss, data.Cpu, data.Memory, data.InternetStatus, data.NiceStatus, json.dumps(data.dict())))
    conn.commit()
    return {"status": "ok"}

@app.get("/metrics")
async def get_metrics(current_user: str = Depends(get_current_user)):
    return latest_metrics

@app.get("/history/{machine}")
async def history(machine: str, current_user: str = Depends(get_current_user)):
    cursor.execute("""
    SELECT timestamp, voip_score, nice_latency, packet_loss, cpu, memory
    FROM metrics_history WHERE machine = ? ORDER BY id DESC LIMIT 100
    """, (machine,))
    rows = cursor.fetchall()
    result = []
    for row in rows:
        result.append({
            "timestamp": row[0], "voip_score": row[1], "nice_latency": row[2],
            "packet_loss": row[3], "cpu": row[4], "memory": row[5]
        })
    return result

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)