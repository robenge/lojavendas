using System;
using System.IO;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

public class WebRtcServer
{
    private HttpListener? listener;

    public WebRtcData LastData
    {
        get;
        private set;
    } = new WebRtcData();

    public void Start()
    {
        try
        {
            listener = new HttpListener();

            listener.Prefixes.Add(
                "http://localhost:9876/"
            );

            listener.Start();

            Console.WriteLine(
                "[WEBRTC] SERVER STARTED"
            );

            Task.Run(async () =>
            {
                while (true)
                {
                    try
                    {
                        var context =
                            await listener
                            .GetContextAsync();

                        var request =
                            context.Request;

                        var response =
                            context.Response;

                        // =====================================
                        // CORS
                        // =====================================

                        response.Headers.Add(
                            "Access-Control-Allow-Origin",
                            "*"
                        );

                        response.Headers.Add(
                            "Access-Control-Allow-Headers",
                            "*"
                        );

                        response.Headers.Add(
                            "Access-Control-Allow-Methods",
                            "*"
                        );

                        // =====================================
                        // OPTIONS
                        // =====================================

                        if (
                            request.HttpMethod
                            == "OPTIONS"
                        )
                        {
                            response.StatusCode = 200;

                            response.Close();

                            continue;
                        }

                        // =====================================
                        // POST /webrtc
                        // =====================================

                        if (
                            request.HttpMethod
                            == "POST"
                            &&
                            request.Url != null
                            &&
                            request.Url.AbsolutePath
                            == "/webrtc"
                        )
                        {
                            using var reader =
                                new StreamReader(
                                    request.InputStream
                                );

                            string body =
                                await reader
                                .ReadToEndAsync();

                            try
                            {
                                var data =
                                    JsonSerializer
                                    .Deserialize
                                    <WebRtcData>(

                                        body,

                                        new JsonSerializerOptions
                                        {
                                            PropertyNameCaseInsensitive = true
                                        }

                                    );

                                if (data != null)
                                {
                                    LastData = data;

                                    Console.WriteLine(

                                        $"[WEBRTC] " +

                                        $"PLATFORM: " +

                                        $"{data.Platform} " +

                                        $"ACTIVE: " +

                                        $"{data.Active}"

                                    );
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(

                                    $"[WEBRTC JSON ERROR] " +

                                    $"{ex.Message}"

                                );
                            }

                            response.StatusCode = 200;
                        }
                        else
                        {
                            response.StatusCode = 200;
                        }

                        // =====================================
                        // RESPONSE
                        // =====================================

                        byte[] buffer =
                            Encoding.UTF8.GetBytes(
                                "OK"
                            );

                        response.OutputStream.Write(
                            buffer,
                            0,
                            buffer.Length
                        );

                        response.OutputStream.Close();

                        response.Close();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(

                            $"[WEBRTC SERVER ERROR] " +

                            $"{ex.Message}"

                        );
                    }
                }
            });
        }
        catch (Exception ex)
        {
            Console.WriteLine(

                $"[WEBRTC START ERROR] " +

                $"{ex.Message}"

            );
        }
    }
}