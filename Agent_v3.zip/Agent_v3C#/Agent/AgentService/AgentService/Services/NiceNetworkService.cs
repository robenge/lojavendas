using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;

public class NiceNetworkService
{
    private string currentServer =
        "is-wrtc-sprwrr.cxonevoice.com";

    // =====================================================
    // REGION
    // =====================================================

    public void SetRegion(string region)
    {
        if (
            region == "Rio de Janeiro"
        )
        {
            currentServer =
                "is-wrtc-riowrr.cxonevoice.com";
        }
        else
        {
            currentServer =
                "is-wrtc-sprwrr.cxonevoice.com";
        }
    }

    // =====================================================
    // RTT
    // =====================================================

    public int GetLatency()
    {
        try
        {
            using var ping =
                new Ping();

            var reply =
                ping.Send(
                    currentServer,
                    1000
                );

            if (
                reply.Status
                == IPStatus.Success
            )
            {
                return
                    (int)reply.RoundtripTime;
            }

            return -1;
        }
        catch
        {
            return -1;
        }
    }

    // =====================================================
    // LOSS
    // =====================================================

    public double GetPacketLoss()
    {
        int fail = 0;

        try
        {
            using var ping =
                new Ping();

            for (int i = 0; i < 5; i++)
            {
                var reply =
                    ping.Send(
                        currentServer,
                        1000
                    );

                if (
                    reply.Status
                    != IPStatus.Success
                )
                {
                    fail++;
                }
            }

            return fail * 20;
        }
        catch
        {
            return 100;
        }
    }

    // =====================================================
    // DNS
    // =====================================================

    public bool ResolveDns()
    {
        try
        {
            Dns.GetHostEntry(
                currentServer
            );

            return true;
        }
        catch
        {
            return false;
        }
    }

    // =====================================================
    // TURN
    // =====================================================

    public bool TestTurn()
    {
        try
        {
            using UdpClient udp =
                new UdpClient();

            udp.Connect(
                currentServer,
                3478
            );

            return true;
        }
        catch
        {
            return false;
        }
    }

    // =====================================================
    // RTP
    // =====================================================

    public bool TestRtp()
    {
        try
        {
            using UdpClient udp =
                new UdpClient();

            udp.Connect(
                currentServer,
                10000
            );

            return true;
        }
        catch
        {
            return false;
        }
    }

    // =====================================================
    // WEBSOCKET
    // =====================================================

    public bool TestWebSocket()
    {
        try
        {
            using TcpClient tcp =
                new TcpClient();

            var task =
                tcp.ConnectAsync(
                    "cxagent.nicecxone.com",
                    443
                );

            bool ok =
                task.Wait(2000);

            return ok;
        }
        catch
        {
            return false;
        }
    }

    // =====================================================
    // REGION
    // =====================================================

    public string GetRegion()
    {
        if (
            currentServer.Contains("rio")
        )
        {
            return "Rio de Janeiro";
        }

        return "São Paulo";
    }
}