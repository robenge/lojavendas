﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Net.NetworkInformation;

public class NetworkService
{
    private readonly Ping ping =
        new();

    public int GetPing()
    {
        try
        {
            var reply =
                ping.Send("8.8.8.8");

            return reply.Status ==
                IPStatus.Success

                ? (int)reply.RoundtripTime

                : 999;
        }
        catch
        {
            return 999;
        }
    }

    public double GetJitter()
    {
        try
        {
            List<long> values = new();

            for (int i = 0; i < 5; i++)
            {
                var reply =
                    ping.Send("8.8.8.8");

                if (
                    reply.Status ==
                    IPStatus.Success
                )
                {
                    values.Add(
                        reply.RoundtripTime
                    );
                }

                Thread.Sleep(100);
            }

            if (values.Count < 2)
                return 0;

            double total = 0;

            for (int i = 1; i < values.Count; i++)
            {
                total += Math.Abs(
                    values[i] - values[i - 1]
                );
            }

            return Math.Round(
                total / (values.Count - 1),
                2
            );
        }
        catch
        {
            return 0;
        }
    }

    public double GetPacketLoss()
    {
        try
        {
            int sent = 10;

            int success = 0;

            for (int i = 0; i < sent; i++)
            {
                var reply =
                    ping.Send("8.8.8.8");

                if (
                    reply.Status ==
                    IPStatus.Success
                )
                {
                    success++;
                }

                Thread.Sleep(100);
            }

            return Math.Round(
                (double)(sent - success)
                / sent * 100,
                2
            );
        }
        catch
        {
            return 100;
        }
    }
}