using System.Management;

public class InventoryService
{
    public string GetManufacturer()
    {
        return GetWmi(
            "Win32_ComputerSystem",
            "Manufacturer"
        );
    }

    public string GetModel()
    {
        return GetWmi(
            "Win32_ComputerSystem",
            "Model"
        );
    }

    public string GetSerial()
    {
        return GetWmi(
            "Win32_BIOS",
            "SerialNumber"
        );
    }

    public string GetWindowsVersion()
    {
        return GetWmi(
            "Win32_OperatingSystem",
            "Caption"
        );
    }

    private string GetWmi(
        string path,
        string property
    )
    {
        try
        {
            using var searcher =
                new ManagementObjectSearcher(
                    $"SELECT {property} FROM {path}"
                );

            foreach (ManagementObject obj in searcher.Get())
            {
                return obj[property]?.ToString()
                    ?? "";
            }
        }
        catch {}

        return "";
    }
}