using NAudio.CoreAudioApi;

public class AudioService
{
    private MMDeviceEnumerator enumerator =
        new MMDeviceEnumerator();

    // =====================================================
    // OUTPUT DEVICE
    // =====================================================

    public string GetOutputDevice()
    {
        try
        {
            var device =
                enumerator.GetDefaultAudioEndpoint(
                    DataFlow.Render,
                    Role.Multimedia
                );

            return device.FriendlyName;
        }
        catch
        {
            return "Unknown";
        }
    }

    // =====================================================
    // INPUT DEVICE
    // =====================================================

    public string GetInputDevice()
    {
        try
        {
            var device =
                enumerator.GetDefaultAudioEndpoint(
                    DataFlow.Capture,
                    Role.Multimedia
                );

            return device.FriendlyName;
        }
        catch
        {
            return "Unknown";
        }
    }

    // =====================================================
    // MUTE
    // =====================================================

    public bool IsMuted()
    {
        try
        {
            var device =
                enumerator.GetDefaultAudioEndpoint(
                    DataFlow.Capture,
                    Role.Multimedia
                );

            return
                device.AudioEndpointVolume.Mute;
        }
        catch
        {
            return false;
        }
    }

    // =====================================================
    // HEADSET DETECTION (SMART FILTER)
    // =====================================================

    public bool IsHeadsetConnected()
    {
        string output =
            GetOutputDevice()
            .ToLower();

        // 1. Marcas e identificadores de Headsets Profissionais (USB/Bluetooth)
        bool isProfessionalHeadset =
            output.Contains("head") ||
            output.Contains("plantronics") ||
            output.Contains("jabra") ||
            output.Contains("usb") ||
            output.Contains("logitech") ||
            output.Contains("hyperx") ||
            output.Contains("corsair") ||
            output.Contains("razer") ||
            output.Contains("jbl") ||
            output.Contains("bluetooth") ||
            output.Contains("airpods");

        // 2. Problema dos Drivers Genéricos (Realtek Combo Jack P2)
        // Se o nome contiver "alto falante" ou "speaker", o Windows está a usar 
        // a saída partilhada do PC (mesmo que tenha a palavra "fones" lá no meio).
        bool isGenericSpeaker = 
            output.Contains("alto falante") || 
            output.Contains("alto-falante") || 
            output.Contains("speaker");

        if (isGenericSpeaker)
        {
            // Se for a placa genérica partilhada, não podemos confiar na palavra "fone".
            // Só aceitamos se tiver indicação explícita de USB, Bluetooth ou uma marca conhecida.
            return isProfessionalHeadset;
        }

        // 3. Se for um dispositivo dedicado que tenha apenas "fone" no nome, aceitamos.
        return isProfessionalHeadset || output.Contains("fone");
    }

    // =====================================================
    // HEADSET NAME
    // =====================================================

    public string GetHeadsetName()
    {
        return GetOutputDevice();
    }
}