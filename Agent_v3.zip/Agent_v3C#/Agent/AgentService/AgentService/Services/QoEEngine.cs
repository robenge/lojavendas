using System.Collections.Generic;

public class QoEEngine
{
    public string Analyze(
        Metrics data,
        out List<string> alerts
    )
    {
        alerts = new List<string>();

        string status = "NORMAL";

        // =========================================
        // ROBOTIC VOICE
        // =========================================
        if (data.WebrtcJitter > 30)
        {
            alerts.Add("VOICE ROBOTIC");
            status = "VOICE ROBOTIC";
        }

        // =========================================
        // PACKET LOSS
        // =========================================
        if (data.WebrtcPacketLoss > 2)
        {
            alerts.Add("PACKET LOSS");
            status = "PACKET LOSS";
        }

        // =========================================
        // HIGH LATENCY
        // =========================================
        if (data.WebrtcRtt > 250)
        {
            alerts.Add("HIGH LATENCY");
            status = "LATENCY";
        }

        // =========================================
        // HEADSET
        // =========================================
        if (!data.HeadsetConnected)
        {
            alerts.Add("HEADSET DISCONNECTED");
        }

        // =========================================
        // NO CALL AUDIO
        // =========================================
        if (data.InCall && data.WebrtcBitrate <= 0)
        {
            alerts.Add("NO AUDIO TRAFFIC");
        }
        
        // Exemplo de regra adicional que podes usar:
        // if (data.Cpu > 90)
        // {
        //     alerts.Add("CPU OVERLOAD");
        // }

        return status;
    }
}