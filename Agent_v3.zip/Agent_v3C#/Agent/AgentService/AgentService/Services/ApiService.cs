﻿using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

public class ApiService
{
    private readonly string _apiUrl;

    private readonly string _token;

    private readonly HttpClient _http =
        new HttpClient();

    public ApiService(
        string apiUrl,
        string token
    )
    {
        _apiUrl = apiUrl;

        _token = token;
    }

    // =====================================================
    // SEND METRICS
    // =====================================================

    public async Task Send(Metrics data)
    {
        try
        {
            string json =
                JsonSerializer.Serialize(data);

            var content =
                new StringContent(

                    json,

                    Encoding.UTF8,

                    "application/json"

                );

            _http.DefaultRequestHeaders.Clear();

            _http.DefaultRequestHeaders.Add(
                "Authorization",
                $"Bearer {_token}"
            );

            var response =
                await _http.PostAsync(

                    $"{_apiUrl}/metrics",

                    content

                );

            Console.WriteLine(

                $"[API] Status: " +

                $"{response.IsSuccessStatusCode}"

            );
        }
        catch (Exception ex)
        {
            Console.WriteLine(

                $"[API ERROR] " +

                $"{ex.Message}"

            );
        }
    }

    // =====================================================
    // GET REGION
    // =====================================================

    public string GetRegion()
    {
        try
        {
            var response =
                _http.GetStringAsync(

                    $"{_apiUrl}/region"

                ).Result;

            using JsonDocument doc =
                JsonDocument.Parse(response);

            return

                doc.RootElement
                   .GetProperty("region")
                   .GetString()

                ??

                "São Paulo";
        }
        catch
        {
            return "São Paulo";
        }
    }
}