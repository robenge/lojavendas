using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting.WindowsServices;

namespace VoipMonitorAgent
{
    class Program
    {
        static void Main(string[] args)
        {
            // O Program.cs agora é apenas o configurador do Serviço Windows.
            // Toda a lógica de monitorização contínua está dentro do Worker.cs
            
            Host.CreateDefaultBuilder(args)
                .UseWindowsService() // Permite que a app corra como um Serviço do Windows nativo
                .ConfigureServices(services =>
                {
                    // Regista a classe Worker como o serviço de background principal
                    services.AddHostedService<Worker>();
                })
                .Build()
                .Run();
        }
    }
}