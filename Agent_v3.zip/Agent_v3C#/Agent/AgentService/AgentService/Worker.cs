using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;

public class Worker : BackgroundService
{
    private readonly IConfiguration _config;
    private string _jwtToken = "";

    public Worker(IConfiguration config)
    {
        _config = config;
    }

    // =====================================================
    // AUTENTICAÇÃO JWT
    // =====================================================
    private async Task AuthenticateAsync(string url, string user, string pass)
    {
        try
        {
            using var client = new HttpClient();
            var content = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("username", user),
                new KeyValuePair<string, string>("password", pass)
            });

            var response = await client.PostAsync($"{url}/login", content);

            if (response.IsSuccessStatusCode)
            {
                var responseString = await response.Content.ReadAsStringAsync();
                using JsonDocument doc = JsonDocument.Parse(responseString);
                _jwtToken = doc.RootElement.GetProperty("access_token").GetString() ?? "";
                
                Console.WriteLine("[AUTH] Login efetuado! Token JWT dinâmico gerado.");
            }
            else
            {
                Console.WriteLine("[AUTH ERROR] Falha na autenticação. Verifica utilizador/senha.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[AUTH CRITICAL] Backend offline? Erro: {ex.Message}");
        }
    }

    protected override async Task ExecuteAsync(
        CancellationToken stoppingToken
    )
    {
        // 1. CARREGAR CONFIGURAÇÕES
        string apiUrl = _config["Api:Url"] ?? "http://localhost:8000";
        string apiUser = _config["Api:Username"] ?? "sysadmin";
        string apiPass = _config["Api:Password"] ?? "123";
        int intervalSeconds = int.Parse(_config["Agent:IntervalSeconds"] ?? "5");

        // 2. OBTER TOKEN JWT ANTES DE INICIAR O LOOP
        await AuthenticateAsync(apiUrl, apiUser, apiPass);

        // 3. INSTANCIAR SERVIÇOS
        var sys = new SystemService();
        var net = new NetworkService();
        var audio = new AudioService();
        var nice = new NiceNetworkService();
        var qoe = new QoEEngine(); 
        var inventory = new InventoryService(); 
        var buffer = new BufferService(); // Adicionado o teu serviço de Logs
        
        var api = new ApiService(apiUrl, _jwtToken);
        
        var webrtc = new WebRtcServer();
        webrtc.Start();

        // Variáveis de controlo de estado para evitar spam no ficheiro de log
        bool wasOffline = false;
        bool wasLowQuality = false;
        bool wasHeadsetDisconnected = false;

        // 4. LOOP PRINCIPAL
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                // =================================================
                // REGION
                // =================================================
                string region = api.GetRegion();
                nice.SetRegion(region);

                // =================================================
                // AUDIO
                // =================================================
                bool headset = audio.IsHeadsetConnected();
                bool muted = audio.IsMuted();

                // =================================================
                // REDE & NICE CXONE (CORREÇÃO OFFLINE)
                // =================================================
                int pingGeral = net.GetPing();
                string internetStatus = pingGeral < 999 ? "ONLINE" : "OFFLINE";

                int niceLatency = nice.GetLatency();
                double niceLoss = nice.GetPacketLoss();
                bool niceDns = nice.ResolveDns();
                bool niceTurn = nice.TestTurn();
                bool niceRtp = nice.TestRtp();
                bool niceWs = nice.TestWebSocket();

                // Lógica corrigida para lidar com a latência de -1ms (falha de rede)
                string niceStatus = "ONLINE";
                if (niceLatency < 0 || internetStatus == "OFFLINE")
                {
                    niceStatus = "OFFLINE";
                    niceLatency = 0; // Evita enviar -1 para o gráfico
                }
                else if (niceLatency > 150)
                {
                    niceStatus = "HIGH LATENCY";
                }

                // =================================================
                // METRICS MASTER OBJECT
                // =================================================
                var data = new Metrics
                {
                    MachineName = Environment.MachineName,
                    Username = Environment.UserName,

                    Manufacturer = inventory.GetManufacturer(),
                    Model = inventory.GetModel(),
                    Serial = inventory.GetSerial(),
                    WindowsVersion = inventory.GetWindowsVersion(),

                    Cpu = sys.GetCpu(),
                    Memory = sys.GetMemory(),
                    Disk = sys.GetDisk(),
                    Uptime = sys.GetUptime(),

                    InternetStatus = internetStatus,
                    Ping = pingGeral,
                    Jitter = net.GetJitter(),
                    PacketLoss = net.GetPacketLoss(),

                    NiceStatus = niceStatus,
                    NiceLatency = niceLatency,
                    NicePacketLoss = niceLoss,
                    NiceDnsOk = niceDns,
                    NiceTurnOk = niceTurn,
                    NiceRtpOk = niceRtp,
                    NiceWebSocketOk = niceWs,
                    NiceRegion = nice.GetRegion(),

                    HeadsetConnected = headset,
                    HeadsetName = audio.GetHeadsetName(),
                    InputDevice = audio.GetInputDevice(),
                    OutputDevice = audio.GetOutputDevice(),
                    Muted = muted,

                    CommunicationPlatform = webrtc.LastData?.Platform ?? "",
                    CommunicationActive = webrtc.LastData?.Active ?? false,
                    GoogleMeetRunning = webrtc.LastData?.Platform == "Google Meet",
                    NiceCxOneRunning = webrtc.LastData?.Platform == "NICE CXOne",
                    ZoomRunning = webrtc.LastData?.Platform == "Zoom",
                    
                    WebrtcRtt = webrtc.LastData?.WebrtcRtt ?? 0,
                    WebrtcJitter = webrtc.LastData?.WebrtcJitter ?? 0,
                    WebrtcPacketLoss = webrtc.LastData?.WebrtcPacketLoss ?? 0,
                    WebrtcBitrate = webrtc.LastData?.WebrtcBitrate ?? 0,
                    InCall = webrtc.LastData?.InCall ?? false,

                    Processes = sys.GetTopProcesses(),
                    Timestamp = DateTime.Now
                };

                // =================================================
                // QOE & SCORE AI (CORREÇÃO DE PENALIZAÇÃO)
                // =================================================
                data.Anomaly = qoe.Analyze(data, out List<string> alerts);
                
                // Forçar alerta de Offline se a internet cair
                if (internetStatus == "OFFLINE") 
                {
                    alerts.Add("NO INTERNET CONNECTION");
                    data.Anomaly = "CRITICAL OFFLINE";
                }
                
                data.Alerts = alerts;

                // Score dinâmico
                int score = 100;
                
                // Se estiver sem internet, o score vai diretamente a zero
                if (internetStatus == "OFFLINE" || niceStatus == "OFFLINE")
                {
                    score = 0;
                }
                else
                {
                    if (data.NiceLatency > 150) score -= 15;
                    if (!data.HeadsetConnected) score -= 10;
                    if (data.Muted) score -= 5;
                    score -= (data.Alerts.Count * 10);
                }
                
                data.VoipScore = Math.Max(0, score); // Garante que não desce abaixo de 0

                // =================================================
                // LOGS LOCAIS DE ALARMES (BUFFER)
                // =================================================
                string timeNow = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                // 1. Alarme de Conexão
                bool isOffline = (internetStatus == "OFFLINE" || niceStatus == "OFFLINE");
                if (isOffline && !wasOffline) 
                {
                    buffer.Save($"[{timeNow}] [ALARM] CONEXÃO CAIU! Internet: {internetStatus} | NICE: {niceStatus}");
                } 
                else if (!isOffline && wasOffline) 
                {
                    buffer.Save($"[{timeNow}] [RECOVERY] Conexão restabelecida com sucesso!");
                }
                wasOffline = isOffline;

                // 2. Alarme de Qualidade Baixa (Score < 70)
                bool isLowQuality = (data.VoipScore < 70 && !isOffline);
                if (isLowQuality && !wasLowQuality) 
                {
                    string reasons = string.Join(", ", data.Alerts);
                    buffer.Save($"[{timeNow}] [ALARM] QUALIDADE BAIXA! Score: {data.VoipScore} | Motivo: {reasons}");
                } 
                else if (!isLowQuality && wasLowQuality && !isOffline) 
                {
                    buffer.Save($"[{timeNow}] [RECOVERY] Qualidade de chamada estabilizada. Score atual: {data.VoipScore}");
                }
                wasLowQuality = isLowQuality;

                // 3. Alarme de Headset
                if (!headset && !wasHeadsetDisconnected) 
                {
                    buffer.Save($"[{timeNow}] [ALARM] HEADSET DESCONECTADO! Dispositivo atual: {data.OutputDevice}");
                } 
                else if (headset && wasHeadsetDisconnected) 
                {
                    buffer.Save($"[{timeNow}] [RECOVERY] Headset conectado novamente.");
                }
                wasHeadsetDisconnected = !headset;


                // =================================================
                // CONSOLE & API SEND
                // =================================================
                Console.WriteLine(
                    $"[AGENT] " +
                    $"NICE:{data.NiceRegion} " +
                    $"STATUS:{data.NiceStatus} " +
                    $"HEADSET:{data.HeadsetConnected} " +
                    $"SCORE:{data.VoipScore}"
                );

                await api.Send(data);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ERROR] {ex.Message}");
            }

            await Task.Delay(intervalSeconds * 1000, stoppingToken);
        }
    }
}