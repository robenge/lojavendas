public class WebRtcData
{
    // =====================================================
    // BASIC
    // =====================================================

    public string Platform
    {
        get;
        set;
    } = "";

    public bool Active
    {
        get;
        set;
    }

    // =====================================================
    // WEBRTC
    // =====================================================

    public double WebrtcRtt
    {
        get;
        set;
    }

    public double WebrtcJitter
    {
        get;
        set;
    }

    public double WebrtcPacketLoss
    {
        get;
        set;
    }

    public double WebrtcBitrate
    {
        get;
        set;
    }

    public string WebrtcCodec
    {
        get;
        set;
    } = "";

    // =====================================================
    // AUDIO
    // =====================================================

    public bool Muted
    {
        get;
        set;
    }

    public bool InCall
    {
        get;
        set;
    }
}