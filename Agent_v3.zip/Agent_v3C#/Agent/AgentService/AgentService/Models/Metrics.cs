﻿using System;
using System.Collections.Generic;

public class Metrics
{
    // =====================================================
    // BASIC
    // =====================================================

    public string MachineName { get; set; } = "";

    public string Username { get; set; } = "";

    // =====================================================
    // SYSTEM
    // =====================================================

    public double Cpu { get; set; }

    public double Memory { get; set; }

    public double Disk { get; set; }

    public double Uptime { get; set; }

    // =====================================================
    // INTERNET
    // =====================================================

    public string InternetStatus { get; set; } = "ONLINE";

    public int Ping { get; set; }

    public double Jitter { get; set; }

    public double PacketLoss { get; set; }

    // =====================================================
    // WEBRTC
    // =====================================================

    public double WebrtcRtt { get; set; }

    public double WebrtcJitter { get; set; }

    public double WebrtcPacketLoss { get; set; }

    public double WebrtcBitrate { get; set; }

    public string WebrtcCodec { get; set; } = "";

    // =====================================================
    // NICE
    // =====================================================

    public string NiceStatus { get; set; } = "ONLINE";

    public int NiceLatency { get; set; }

    public double NicePacketLoss { get; set; }

    public bool NiceDnsOk { get; set; }

    public bool NiceWebSocketOk { get; set; }

    public bool NiceTurnOk { get; set; }

    public bool NiceRtpOk { get; set; }

    public string NiceRegion { get; set; } = "";

    // =====================================================
    // VOIP
    // =====================================================

    public int VoipScore { get; set; }

    public bool InCall { get; set; }

    public bool Muted { get; set; }

    // =====================================================
    // AUDIO
    // =====================================================

    public bool HeadsetConnected { get; set; }

    public string HeadsetName { get; set; } = "";

    public string InputDevice { get; set; } = "";

    public string OutputDevice { get; set; } = "";

    // =====================================================
    // COMMUNICATION
    // =====================================================

    public string CommunicationPlatform { get; set; } = "";

    public bool CommunicationActive { get; set; }

    public bool GoogleMeetRunning { get; set; }

    public bool NiceCxOneRunning { get; set; }

    public bool ZoomRunning { get; set; }

    // =====================================================
    // INVENTORY
    // =====================================================

    public string Manufacturer { get; set; } = "";

    public string Model { get; set; } = "";

    public string Serial { get; set; } = "";

    public string WindowsVersion { get; set; } = "";

    // =====================================================
    // AI
    // =====================================================

    public string Anomaly { get; set; } = "NORMAL";

    public List<string> Alerts { get; set; } = new();

    // =====================================================
    // PROCESS
    // =====================================================

    public List<ProcessInfo> Processes { get; set; } = new();

    // =====================================================
    // DATE
    // =====================================================

    public DateTime Timestamp { get; set; }
}