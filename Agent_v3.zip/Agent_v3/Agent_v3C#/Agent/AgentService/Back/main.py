from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
import sqlite3
import json
import jwt
from datetime import datetime, timedelta

# =====================================================
# CONFIGURAÇÕES DE SEGURANÇA (JWT)
# =====================================================
SECRET_KEY = "infra_secret_key_super_secure"  # Mude em produção
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 240

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

USERS_DB = {
    "sysadmin": {
        "username": "sysadmin",
        "password": "123"
    }
}

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Credenciais inválidas ou token expirado",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except jwt.PyJWTError:
        raise credentials_exception
        
    if username not in USERS_DB:
        raise credentials_exception
    return username

# =====================================================
# FASTAPI & DATABASE
# =====================================================
app = FastAPI()

conn = sqlite3.connect("metrics.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS metrics_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    machine TEXT,
    timestamp TEXT,
    voip_score INTEGER,
    nice_latency INTEGER,
    nice_latency_rio INTEGER DEFAULT 0,
    packet_loss REAL,
    cpu REAL,
    memory REAL,
    internet_status TEXT,
    nice_status TEXT,
    json TEXT
)
""")
conn.commit()

try:
    cursor.execute("ALTER TABLE metrics_history ADD COLUMN nice_latency_rio INTEGER DEFAULT 0")
    conn.commit()
except:
    pass

latest_metrics = {}

# =====================================================
# MODEL
# =====================================================
class Metrics(BaseModel):
    MachineName: str
    Username: str
    Cpu: float
    Memory: float
    Disk: float
    Uptime: float
    InternetStatus: str
    Ping: int
    Jitter: float
    PacketLoss: float
    WebrtcRtt: float = 0
    WebrtcJitter: float = 0
    WebrtcPacketLoss: float = 0
    WebrtcBitrate: float = 0
    WebrtcCodec: str = ""
    NiceStatus: str
    NiceLatency: int
    NicePacketLoss: float
    NiceDnsOk: bool
    NiceWebSocketOk: bool
    NiceTurnOk: bool
    NiceRtpOk: bool
    NiceRegion: str
    NiceStatusRio: str = "ONLINE"
    NiceLatencyRio: int = 0
    VoipScore: int
    InCall: bool
    Muted: bool
    HeadsetConnected: bool
    HeadsetName: str
    InputDevice: str = ""
    OutputDevice: str = ""
    CommunicationPlatform: str
    CommunicationActive: bool
    GoogleMeetRunning: bool
    NiceCxOneRunning: bool
    ZoomRunning: bool
    Manufacturer: str
    Model: str
    Serial: str
    WindowsVersion: str
    Anomaly: str
    Alerts: list
    Processes: list
    Timestamp: str

# =====================================================
# ROTAS PÚBLICAS
# =====================================================
@app.post("/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = USERS_DB.get(form_data.username)
    if not user or user["password"] != form_data.password:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Usuário ou senha incorretos")
    access_token = create_access_token(data={"sub": user["username"]})
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    with open("dashboard.html", "r", encoding="utf-8") as f:
        return f.read()

# =====================================================
# ROTAS PROTEGIDAS
# =====================================================
@app.post("/metrics")
async def receive_metrics(data: Metrics):
    latest_metrics[data.MachineName] = data.model_dump() # model_dump() é o padrão do Pydantic V2
    
    cursor.execute("""
    INSERT INTO metrics_history (machine, timestamp, voip_score, nice_latency, nice_latency_rio, packet_loss, cpu, memory, internet_status, nice_status, json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (data.MachineName, data.Timestamp, data.VoipScore, data.NiceLatency, data.NiceLatencyRio, data.PacketLoss, data.Cpu, data.Memory, data.InternetStatus, data.NiceStatus, json.dumps(data.model_dump())))
    conn.commit()
    return {"status": "ok"}

@app.get("/metrics")
async def get_metrics(current_user: str = Depends(get_current_user)):
    return latest_metrics

@app.get("/history/{machine}")
async def history(machine: str, current_user: str = Depends(get_current_user)):
    cursor.execute("""
    SELECT timestamp, voip_score, nice_latency, nice_latency_rio, packet_loss, cpu, memory, json
    FROM metrics_history WHERE machine = ? ORDER BY id DESC LIMIT 100
    """, (machine,))
    
    rows = cursor.fetchall()
    result = []
    for row in rows:
        try:
            data_json = json.loads(row[7]) if row[7] else {}
            historico_alertas = data_json.get("Alerts", [])
        except:
            historico_alertas = []

        result.append({
            "timestamp": row[0], 
            "voip_score": row[1], 
            "nice_latency": row[2],
            "nice_latency_rio": row[3],
            "packet_loss": row[4], 
            "cpu": row[5], 
            "memory": row[6],
            "alerts": historico_alertas
        })
    return result

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)